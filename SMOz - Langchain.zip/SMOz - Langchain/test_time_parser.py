#!/usr/bin/env python3
"""
测试智能时间解析器
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'oz-server', 'src'))

from time_parser import IntelligentTimeParser, parse_time_expression
from datetime import datetime

def test_time_parser():
    """测试时间解析器的各种功能"""
    
    parser = IntelligentTimeParser()
    
    print("🔍 测试智能时间解析器")
    print("=" * 50)
    
    # 测试用例
    test_cases = [
        # 相对时间
        ("昨天", "birthday"),
        ("今天", "general"),
        ("明天", "appointment"),
        ("3天前", "event"),
        ("下周", "meeting"),
        ("上个月", "general"),
        
        # 绝对时间
        ("2025-05-29", "birthday"),
        ("12/25/2025", "event"),
        ("5月30日", "appointment"),
        ("January 15, 2025", "meeting"),
        
        # 模糊时间
        ("春天", "general"),
        ("圣诞节", "event"),
        ("早上", "appointment"),
        
        # 复杂表达式
        ("my birthday is tomorrow", "birthday"),
        ("I have a meeting next Tuesday", "meeting"),
        ("let's schedule this for 下周三", "appointment"),
    ]
    
    for time_text, context in test_cases:
        print(f"\n📅 测试: '{time_text}' (上下文: {context})")
        result = parser.parse_time_expression(time_text, context)
        
        print(f"  原文: {result['original_text']}")
        print(f"  解析日期: {result['parsed_date']}")
        print(f"  置信度: {result['confidence']:.2f}")
        print(f"  是否相对时间: {result['is_relative']}")
        
        if result['confidence'] > 0.7:
            print(f"  ✅ 高置信度解析")
        elif result['confidence'] > 0.5:
            print(f"  ⚠️ 中等置信度解析")
        else:
            print(f"  ❌ 低置信度解析")

def test_memory_integration():
    """测试与记忆系统的集成"""
    
    print("\n\n🧠 测试记忆系统时间处理集成")
    print("=" * 50)
    
    try:
        from memory_system_v2 import SMOzMemorySystem
        
        # 创建记忆系统实例
        memory = SMOzMemorySystem(user_id="time_test_user")
        
        # 测试对话
        test_conversations = [
            ("My birthday is tomorrow", "That's exciting! Happy early birthday!"),
            ("I have a meeting next Friday", "I'll remember that. Would you like me to remind you?"),
            ("Let's schedule lunch for 下周二", "Sounds great! I've noted that down."),
            ("I was born on 1990-03-15", "Thanks for sharing! I'll remember your birthday."),
        ]
        
        for user_msg, ai_response in test_conversations:
            print(f"\n💬 用户: {user_msg}")
            print(f"🤖 AI: {ai_response}")
            
            # 添加到记忆系统
            memory.add_conversation(user_msg, ai_response)
        
        # 检查用户档案中的时间信息
        profile = memory.get_user_profile()
        
        print("\n📊 用户档案中的时间信息:")
        
        # 个人详细信息
        personal_details = profile.get("personal_details", {})
        if personal_details:
            print(f"  个人信息: {personal_details}")
        
        # 时间信息
        temporal_info = profile.get("temporal_information", {})
        if temporal_info:
            print(f"  时间信息结构: {list(temporal_info.keys())}")
            
            # 即将到来的事件
            upcoming = temporal_info.get("upcoming_events", [])
            if upcoming:
                print(f"  即将到来的事件:")
                for event in upcoming:
                    print(f"    - {event['type']}: {event['parsed_date']} (置信度: {event['confidence']:.2f})")
            
            # 检测到的时间表达式
            expressions = temporal_info.get("detected_expressions", [])
            if expressions:
                print(f"  检测到的时间表达式:")
                for expr in expressions[-3:]:  # 只显示最近3个
                    print(f"    - '{expr['original']}' -> {expr['parsed_date']} (置信度: {expr['confidence']:.2f})")
        
        # 测试获取即将到来的事件
        upcoming_events = memory.get_upcoming_events()
        if upcoming_events:
            print(f"\n📅 即将到来的事件 ({len(upcoming_events)}个):")
            for event in upcoming_events:
                print(f"  - {event['type'].title()}: {event['parsed_date']}")
        
        # 测试时间相关上下文
        time_context = memory.get_time_related_context()
        print(f"\n🕐 时间相关上下文:")
        print(f"  个人日期: {time_context['personal_dates']}")
        print(f"  即将到来的事件数量: {len(time_context['upcoming_events'])}")
        print(f"  最近时间表达式数量: {len(time_context['recent_time_expressions'])}")
        
        # 保存记忆
        memory.save_all_memories()
        print(f"\n💾 记忆已保存到: {memory.storage_dir}")
        
    except Exception as e:
        print(f"❌ 记忆系统集成测试失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # 测试时间解析器
    test_time_parser()
    
    # 测试记忆系统集成
    test_memory_integration()
    
    print("\n✅ 测试完成！") 