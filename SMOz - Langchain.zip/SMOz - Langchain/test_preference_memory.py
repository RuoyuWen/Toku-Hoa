#!/usr/bin/env python3
"""
测试偏好记忆功能
"""

import sys
import os
sys.path.insert(0, os.path.join('oz-server', 'src'))

from memory_system_v2 import SMOzMemorySystem

def test_preference_memory():
    print("🧠 测试偏好记忆功能")
    print("=" * 50)
    
    # 创建记忆系统
    memory = SMOzMemorySystem(user_id='preference_test_user')
    
    print("\n📝 第一步：用户说出喜好")
    # 用户说出最喜欢的电影
    user_msg1 = "my favorite movie is ready player one"
    ai_response1 = "Great choice! Ready Player One is an amazing movie."
    memory.add_conversation(user_msg1, ai_response1)
    
    print("\n📋 检查用户档案中的偏好信息：")
    profile = memory.get_user_profile()
    if "preferences" in profile:
        print("偏好信息:", profile["preferences"])
    else:
        print("❌ 没有找到偏好信息")
    
    print("\n🔍 第二步：测试记忆检索")
    # 测试偏好查询
    query = "do you know my favorite movie"
    results = memory.search_memories(query)
    
    print(f"查询: '{query}'")
    print(f"找到 {len(results)} 条相关记忆:")
    
    for i, result in enumerate(results):
        print(f"  {i+1}. {result.get('user_message', '')}")
        if 'metadata' in result and 'preferences' in result['metadata']:
            print(f"     偏好: {result['metadata']['preferences']}")
    
    print("\n🤖 第三步：模拟AI回应")
    # 模拟AI询问最喜欢的电影
    user_msg2 = "hi, do you know my favorite movie?"
    
    # 获取相关记忆
    relevant_memories = memory.search_memories(user_msg2)
    
    if relevant_memories:
        print(f"✅ AI应该记住: {relevant_memories[0].get('user_message', '')}")
        print("✅ AI可以回答：是的，你最喜欢的电影是Ready Player One!")
    else:
        print("❌ AI没有找到相关记忆")
    
    print("\n📊 最终状态：")
    print(f"STM: {len(memory.short_term_memories)}")
    print(f"MTM: {len(memory.medium_term_memories)}")
    print(f"偏好记录: {len(profile.get('preferences', {}).get('favorites', {}))}")

if __name__ == "__main__":
    test_preference_memory() 