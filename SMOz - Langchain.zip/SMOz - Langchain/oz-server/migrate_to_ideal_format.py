#!/usr/bin/env python3
"""
记忆文档格式迁移脚本
将现有记忆文档转换为理想的标准化三层架构格式
"""

import os
import json
import glob
from datetime import datetime
from pathlib import Path
from typing import Dict, List
from collections import Counter

class MemoryFormatMigrator:
    """记忆格式迁移器"""
    
    def __init__(self, user_id: str = "default_user"):
        self.user_id = user_id
        self.storage_dir = self._get_storage_dir()
        
        print(f"🔄 开始迁移用户 {user_id} 的记忆文档到理想格式")
    
    def _get_storage_dir(self) -> str:
        """获取存储目录"""
        base_dir = Path(__file__).parent.parent / "sm-docker-local" / "data" / "memory"
        return str(base_dir / self.user_id)
    
    def migrate_all_memories(self):
        """迁移所有记忆文档"""
        
        # 1. 创建备份
        self._create_backup()
        
        # 2. 分析现有记忆
        existing_memories = self._analyze_existing_memories()
        
        # 3. 生成理想格式的记忆
        ideal_memories = self._convert_to_ideal_format(existing_memories)
        
        # 4. 保存理想格式的记忆
        self._save_ideal_format(ideal_memories)
        
        # 5. 验证迁移结果
        self._verify_migration()
        
        print("✅ 记忆格式迁移完成！")
    
    def _create_backup(self):
        """创建原始文件备份"""
        import shutil
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = Path(self.storage_dir) / f"migration_backup_{timestamp}"
        
        if Path(self.storage_dir).exists():
            shutil.copytree(self.storage_dir, backup_dir, 
                           ignore=shutil.ignore_patterns("migration_backup_*"))
            print(f"📦 创建备份: {backup_dir}")
    
    def _analyze_existing_memories(self) -> Dict:
        """分析现有记忆结构"""
        memories = {
            "short_term": [],
            "medium_term": [],
            "long_term": [],
            "metadata": None
        }
        
        # 读取短期记忆
        short_term_dir = Path(self.storage_dir) / "short_term"
        if short_term_dir.exists():
            for session_file in short_term_dir.glob("session_*.json"):
                try:
                    with open(session_file, 'r', encoding='utf-8') as f:
                        session_data = json.load(f)
                        memories["short_term"].extend(session_data if isinstance(session_data, list) else [session_data])
                except Exception as e:
                    print(f"⚠️ 读取短期记忆失败 {session_file}: {e}")
        
        # 读取中期记忆
        medium_file = Path(self.storage_dir) / "medium_term" / "important_memories.json"
        if medium_file.exists():
            try:
                with open(medium_file, 'r', encoding='utf-8') as f:
                    memories["medium_term"] = json.load(f)
            except Exception as e:
                print(f"⚠️ 读取中期记忆失败: {e}")
        
        # 读取长期记忆
        long_term_file = Path(self.storage_dir) / "long_term" / "insights_and_summaries.json"
        if long_term_file.exists():
            try:
                with open(long_term_file, 'r', encoding='utf-8') as f:
                    memories["long_term"] = json.load(f)
            except Exception as e:
                print(f"⚠️ 读取长期记忆失败: {e}")
        
        # 读取元数据
        metadata_file = Path(self.storage_dir) / "metadata" / "user_metadata.json"
        if metadata_file.exists():
            try:
                with open(metadata_file, 'r', encoding='utf-8') as f:
                    memories["metadata"] = json.load(f)
            except Exception as e:
                print(f"⚠️ 读取元数据失败: {e}")
        
        print(f"📊 分析完成 - STM: {len(memories['short_term'])}, MTM: {len(memories['medium_term'])}, LTM: {len(memories['long_term'])}")
        return memories
    
    def _convert_to_ideal_format(self, existing_memories: Dict) -> Dict:
        """转换为理想格式"""
        
        ideal_memories = {
            "short_term": [],
            "medium_term": [],
            "long_term": {}  # 改为结构化用户档案对象
        }
        
        # 1. 处理短期记忆 - 转换为标准STM格式
        for memory in existing_memories["short_term"]:
            stm_memory = self._convert_to_stm_format(memory)
            if stm_memory:
                ideal_memories["short_term"].append(stm_memory)
        
        # 2. 处理中期记忆 - 转换为标准MTM格式
        for memory in existing_memories["medium_term"]:
            mtm_memory = self._convert_to_mtm_format(memory)
            if mtm_memory:
                ideal_memories["medium_term"].append(mtm_memory)
        
        # 检查短期记忆中的重要对话，添加到中期记忆
        for stm_memory in ideal_memories["short_term"]:
            if stm_memory.get("importance", 0) > 0.5:
                mtm_memory = self._convert_stm_to_mtm(stm_memory)
                ideal_memories["medium_term"].append(mtm_memory)
        
        # 3. 处理长期记忆 - 转换为结构化用户档案
        ideal_memories["long_term"] = self._create_structured_user_profile(
            existing_memories, ideal_memories["short_term"]
        )
        
        # 限制记忆数量
        ideal_memories["short_term"] = ideal_memories["short_term"][-10:]  # 最近10条
        ideal_memories["medium_term"] = sorted(
            ideal_memories["medium_term"], 
            key=lambda x: x.get("importance", 0), 
            reverse=True
        )[:50]  # 最重要的50条
        
        return ideal_memories
    
    def _convert_to_stm_format(self, memory: Dict) -> Dict:
        """转换为STM格式"""
        try:
            metadata = memory.get("metadata", {})
            
            # 提取用户和AI消息
            user_message = metadata.get("user_message", "")
            ai_response = metadata.get("ai_response", "")
            
            # 如果没有直接的消息，从content中提取
            if not user_message or not ai_response:
                content = memory.get("content", "")
                if "User:" in content and "Lucy:" in content:
                    lines = content.split('\n')
                    for line in lines:
                        if line.startswith("User:"):
                            user_message = line.replace("User:", "").strip()
                        elif line.startswith("Lucy:"):
                            ai_response = line.replace("Lucy:", "").strip()
            
            if not user_message or not ai_response:
                return None
            
            # 转换话题格式
            topics = metadata.get("topics", [])
            if isinstance(topics, list):
                # 将中文话题转换为英文
                topic_mapping = {
                    "问候": "Greeting",
                    "周五近况": "Friday updates",
                    "工作": "Work",
                    "家庭": "Family",
                    "情感": "Emotions"
                }
                topics = [topic_mapping.get(topic, topic.title()) for topic in topics]
            else:
                topics = ["General"]
            
            # 转换情感格式
            emotions = metadata.get("emotions", [])
            if isinstance(emotions, list):
                emotion_mapping = {
                    "友好": "Friendly",
                    "积极": "Positive",
                    "消极": "Negative",
                    "中性": "Neutral"
                }
                emotions = [emotion_mapping.get(emotion, emotion.title()) for emotion in emotions]
            else:
                emotions = ["Neutral"]
            
            return {
                "timestamp": metadata.get("timestamp", datetime.now().isoformat()),
                "user": user_message,
                "ai": ai_response,
                "topics": topics,
                "emotions": emotions,
                "importance": metadata.get("importance", 0.1)
            }
            
        except Exception as e:
            print(f"⚠️ STM转换失败: {e}")
            return None
    
    def _convert_to_mtm_format(self, memory: Dict) -> Dict:
        """转换为MTM格式"""
        # 如果已经是MTM格式，直接返回
        if "conversation" in memory and "insight" in memory:
            return memory
        
        # 否则从其他格式转换
        return None
    
    def _convert_stm_to_mtm(self, stm_memory: Dict) -> Dict:
        """将STM记录转换为MTM格式"""
        return {
            "timestamp": stm_memory["timestamp"],
            "importance": stm_memory["importance"],
            "conversation": [
                {
                    "user": stm_memory["user"],
                    "ai": stm_memory["ai"]
                }
            ],
            "topics": stm_memory["topics"],
            "emotions": stm_memory["emotions"],
            "insight": f"Important conversation about {', '.join(stm_memory['topics'])} (importance: {stm_memory['importance']:.2f})"
        }
    
    def _create_structured_user_profile(self, existing_memories: Dict, stm_memories: List[Dict]) -> Dict:
        """创建结构化用户档案 (LTM)"""
        
        metadata = existing_memories.get("metadata", {})
        
        # 收集所有话题和情感
        all_topics = []
        all_emotions = []
        total_conversations = 0
        total_importance = 0
        
        for memory in stm_memories:
            all_topics.extend(memory.get("topics", []))
            all_emotions.extend(memory.get("emotions", []))
            total_conversations += 1
            total_importance += memory.get("importance", 0)
        
        # 统计话题和情感
        topic_stats = Counter(all_topics)
        emotion_stats = Counter(all_emotions)
        
        # 分析交流风格
        high_importance_count = sum(1 for m in stm_memories if m.get("importance", 0) > 0.6)
        
        if high_importance_count > total_conversations * 0.3:
            communication_style = "Open and sharing"
            info_sharing_tendency = "High"
        elif high_importance_count > 0:
            communication_style = "Cautiously sharing"
            info_sharing_tendency = "Medium"
        else:
            communication_style = "Reserved communicator"
            info_sharing_tendency = "Low"
        
        # 分析关系阶段
        if total_conversations <= 3:
            relationship_stage = "Initial contact"
        elif total_conversations <= 10:
            relationship_stage = "Building trust"
        elif total_conversations <= 25:
            relationship_stage = "Deep interaction"
        else:
            relationship_stage = "Long-term companion"
        
        # 分析活跃程度
        if total_conversations > 20:
            activity_level = "Highly active"
        elif total_conversations > 5:
            activity_level = "Regular interaction"
        else:
            activity_level = "Exploring phase"
        
        return {
            "user_id": self.user_id,
            "companion_start_date": metadata.get("companion_start_date", datetime.now().strftime("%Y-%m-%d")),
            "topics_of_interest": list(set(all_topics)),
            "emotional_tendencies": list(set(all_emotions)),
            "communication_style": communication_style,
            "relationship_stage": relationship_stage,
            "activity_level": activity_level,
            "information_sharing_tendency": info_sharing_tendency,
            "average_importance": total_importance / total_conversations if total_conversations > 0 else 0.0,
            "interaction_summary": {
                "total_conversations": total_conversations,
                "last_interaction": metadata.get("last_interaction")
            },
            "preferences": metadata.get("user_preferences", {}),
            "behavior_traits": [communication_style, f"{activity_level} user"],
            "summary_stats": {
                "most_discussed_topics": dict(topic_stats),
                "dominant_emotions": dict(emotion_stats),
                "relationship_duration_days": metadata.get("companion_days", 0)
            }
        }
    
    def _save_ideal_format(self, ideal_memories: Dict):
        """保存理想格式的记忆"""
        
        # 确保目录存在
        for subdir in ["short_term", "medium_term", "long_term"]:
            dir_path = Path(self.storage_dir) / subdir
            dir_path.mkdir(parents=True, exist_ok=True)
        
        # 保存STM
        if ideal_memories["short_term"]:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            stm_file = Path(self.storage_dir) / "short_term" / f"session_{timestamp}.json"
            with open(stm_file, 'w', encoding='utf-8') as f:
                json.dump(ideal_memories["short_term"], f, ensure_ascii=False, indent=2)
            print(f"💾 保存STM: {len(ideal_memories['short_term'])} 条记录")
        
        # 保存MTM
        if ideal_memories["medium_term"]:
            mtm_file = Path(self.storage_dir) / "medium_term" / "important_memories.json"
            with open(mtm_file, 'w', encoding='utf-8') as f:
                json.dump(ideal_memories["medium_term"], f, ensure_ascii=False, indent=2)
            print(f"💾 保存MTM: {len(ideal_memories['medium_term'])} 条记录")
        
        # 保存LTM (用户档案)
        ltm_file = Path(self.storage_dir) / "long_term" / "user_profile.json"
        with open(ltm_file, 'w', encoding='utf-8') as f:
            json.dump(ideal_memories["long_term"], f, ensure_ascii=False, indent=2)
        print("💾 保存LTM: 结构化用户档案")
        
        # 清理旧的长期记忆文件
        old_ltm_file = Path(self.storage_dir) / "long_term" / "insights_and_summaries.json"
        if old_ltm_file.exists():
            old_ltm_file.rename(old_ltm_file.with_suffix('.json.old'))
            print("🗂️ 旧LTM文件已重命名为 .old")
    
    def _verify_migration(self):
        """验证迁移结果"""
        print("\n🔍 验证迁移结果:")
        
        # 验证LTM格式
        ltm_file = Path(self.storage_dir) / "long_term" / "user_profile.json"
        if ltm_file.exists():
            with open(ltm_file, 'r', encoding='utf-8') as f:
                ltm_data = json.load(f)
            
            # 检查必需字段
            required_fields = [
                "user_id", "companion_start_date", "topics_of_interest", 
                "emotional_tendencies", "communication_style", "relationship_stage",
                "activity_level", "information_sharing_tendency", "average_importance",
                "interaction_summary", "preferences", "behavior_traits", "summary_stats"
            ]
            
            missing_fields = [field for field in required_fields if field not in ltm_data]
            if missing_fields:
                print(f"   ❌ LTM缺少字段: {missing_fields}")
            else:
                print("   ✅ LTM格式正确，包含所有必需字段")
            
            # 验证不包含对话内容
            ltm_str = json.dumps(ltm_data, ensure_ascii=False)
            contains_dialogue = '"user":' in ltm_str and '"ai":' in ltm_str
            if contains_dialogue:
                print("   ❌ LTM包含对话内容")
            else:
                print("   ✅ LTM不包含对话内容")
        
        # 验证MTM格式
        mtm_file = Path(self.storage_dir) / "medium_term" / "important_memories.json"
        if mtm_file.exists():
            with open(mtm_file, 'r', encoding='utf-8') as f:
                mtm_data = json.load(f)
            
            if mtm_data and isinstance(mtm_data, list):
                sample = mtm_data[0]
                mtm_fields = ["timestamp", "importance", "conversation", "topics", "emotions", "insight"]
                missing_mtm_fields = [field for field in mtm_fields if field not in sample]
                
                if missing_mtm_fields:
                    print(f"   ❌ MTM缺少字段: {missing_mtm_fields}")
                else:
                    print(f"   ✅ MTM格式正确，包含 {len(mtm_data)} 条重要对话")
        
        # 验证STM格式
        stm_dir = Path(self.storage_dir) / "short_term"
        stm_files = list(stm_dir.glob("session_*.json"))
        if stm_files:
            latest_file = max(stm_files, key=lambda x: x.stat().st_mtime)
            with open(latest_file, 'r', encoding='utf-8') as f:
                stm_data = json.load(f)
            
            if stm_data and isinstance(stm_data, list):
                sample = stm_data[0]
                stm_fields = ["timestamp", "user", "ai", "topics", "emotions", "importance"]
                missing_stm_fields = [field for field in stm_fields if field not in sample]
                
                if missing_stm_fields:
                    print(f"   ❌ STM缺少字段: {missing_stm_fields}")
                else:
                    print(f"   ✅ STM格式正确，包含 {len(stm_data)} 条对话")
        
        print("\n✅ 迁移验证完成！")


def main():
    """主函数"""
    print("🚀 开始记忆文档格式迁移")
    print("目标: 转换为理想的标准化三层架构格式")
    print("="*60)
    
    # 创建迁移器并执行迁移
    migrator = MemoryFormatMigrator(user_id="default_user")
    migrator.migrate_all_memories()
    
    print("\n🎉 迁移完成！现有记忆文档已转换为理想格式")


if __name__ == "__main__":
    main() 