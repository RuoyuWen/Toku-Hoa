#!/usr/bin/env python3
"""
SMOz Memory System V2.0 测试脚本
验证新的三层记忆架构
"""

import sys
import os
import json
from datetime import datetime

# 添加src目录到路径
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from memory_system_v2 import SMOzMemorySystem

def test_memory_system():
    """测试新的记忆系统"""
    
    print("🚀 开始测试 SMOz Memory System V2.0")
    print("="*60)
    
    # 1. 初始化记忆系统
    print("\n1️⃣ 初始化记忆系统")
    memory = SMOzMemorySystem(user_id="test_user_v2")
    
    # 2. 添加多种类型的对话
    print("\n2️⃣ 添加测试对话")
    
    conversations = [
        # 普通问候 (低重要性)
        ("Hi there!", "Hello! Nice to see you again. How are you doing today?"),
        
        # 个人信息分享 (高重要性)
        ("I'm Sarah, and I work as a software engineer", "Nice to meet you, Sarah! Software engineering sounds fascinating. What kind of projects do you work on?"),
        
        # 情感表达 (中等重要性)
        ("I'm feeling really stressed about my upcoming presentation", "I can understand why you'd feel stressed about that. Presentations can be nerve-wracking. Would you like to talk about what's worrying you most?"),
        
        # 兴趣爱好 (中等重要性)
        ("I love reading science fiction novels", "That's awesome! Science fiction has such imaginative worlds. Do you have a favorite author or series?"),
        
        # 家庭话题 (高重要性)
        ("My mom is visiting this weekend and I'm excited", "How wonderful! Family visits are always special. Do you have any plans for her visit?"),
        
        # 工作压力 (高重要性)
        ("Work has been overwhelming lately with all these deadlines", "That sounds really challenging. Having multiple deadlines can definitely feel overwhelming. Are you able to prioritize or get any support?"),
        
        # 健康话题 (高重要性)
        ("I haven't been sleeping well and I'm worried about it", "I'm sorry to hear you're having trouble sleeping. That can really affect how you feel during the day. Have you tried any strategies to improve your sleep?"),
        
        # 简单问候 (低重要性)
        ("How's your day going?", "My day is going well, thank you for asking! I'm here and ready to chat with you. What would you like to talk about?")
    ]
    
    for i, (user_msg, ai_response) in enumerate(conversations, 1):
        print(f"   添加对话 {i}: {user_msg[:30]}...")
        memory.add_conversation(user_msg, ai_response)
    
    # 3. 检查记忆分布
    print("\n3️⃣ 检查记忆分布")
    stats = memory.get_memory_stats()
    print(f"   短期记忆: {stats['short_term_count']} 条")
    print(f"   中期记忆: {stats['medium_term_count']} 条")
    print(f"   总对话数: {stats['total_conversations']} 次")
    print(f"   关系阶段: {stats['relationship_stage']}")
    print(f"   交流风格: {stats['communication_style']}")
    print(f"   平均重要性: {stats['average_importance']:.3f}")
    
    # 4. 检查用户档案 (LTM)
    print("\n4️⃣ 检查用户档案 (LTM)")
    profile = memory.get_user_profile()
    print(f"   话题兴趣: {profile['topics_of_interest']}")
    print(f"   情感倾向: {profile['emotional_tendencies']}")
    print(f"   交流倾向: {profile['information_sharing_tendency']}")
    print(f"   活跃程度: {profile['activity_level']}")
    
    # 验证LTM不包含对话内容
    profile_str = json.dumps(profile, ensure_ascii=False)
    has_dialogue = any(keyword in profile_str.lower() for keyword in ["hi there", "sarah", "stressed", "presentation"])
    print(f"   ✅ LTM不包含对话内容: {not has_dialogue}")
    
    # 5. 检查重要对话 (MTM)
    print("\n5️⃣ 检查重要对话 (MTM)")
    important_convs = memory.get_important_conversations()
    print(f"   重要对话数量: {len(important_convs)}")
    for i, conv in enumerate(important_convs, 1):
        print(f"   {i}. 重要性: {conv['importance']:.2f}, 话题: {conv['topics']}, 情感: {conv['emotions']}")
        print(f"      洞察: {conv['insight']}")
    
    # 6. 检查最近对话 (STM)
    print("\n6️⃣ 检查最近对话 (STM)")
    recent_convs = memory.get_recent_conversations()
    print(f"   最近对话数量: {len(recent_convs)}")
    for i, conv in enumerate(recent_convs[-3:], 1):  # 显示最后3条
        print(f"   {i}. 用户: {conv['user'][:50]}...")
        print(f"      重要性: {conv['importance']:.2f}, 话题: {conv['topics']}")
    
    # 7. 测试搜索功能
    print("\n7️⃣ 测试记忆搜索")
    
    # 搜索工作相关
    work_results = memory.search_memories("work")
    print(f"   搜索'work': 找到 {len(work_results)} 条记忆")
    
    # 搜索情感相关
    stress_results = memory.search_memories("stress")
    print(f"   搜索'stress': 找到 {len(stress_results)} 条记忆")
    
    # 只搜索LTM
    ltm_results = memory.search_memories("engineer", memory_types=["long_term"])
    print(f"   在LTM搜索'engineer': 找到 {len(ltm_results)} 条记忆")
    
    # 8. 保存记忆
    print("\n8️⃣ 保存记忆到文件")
    memory.save_all_memories()
    
    # 9. 创建备份
    print("\n9️⃣ 创建备份")
    backup_path = memory.create_backup()
    
    # 10. 验证文件结构
    print("\n🔟 验证文件结构")
    storage_dir = memory.storage_dir
    
    # 检查LTM文件
    ltm_file = os.path.join(storage_dir, "long_term", "user_profile.json")
    if os.path.exists(ltm_file):
        with open(ltm_file, 'r', encoding='utf-8') as f:
            ltm_data = json.load(f)
        print(f"   ✅ LTM文件存在，包含用户档案结构")
        
        # 验证不包含对话内容
        ltm_str = json.dumps(ltm_data, ensure_ascii=False).lower()
        contains_dialogue = any(phrase in ltm_str for phrase in ["hi there", "software engineer", "stressed about"])
        print(f"   ✅ LTM不包含具体对话内容: {not contains_dialogue}")
    
    # 检查MTM文件
    mtm_file = os.path.join(storage_dir, "medium_term", "important_memories.json")
    if os.path.exists(mtm_file):
        with open(mtm_file, 'r', encoding='utf-8') as f:
            mtm_data = json.load(f)
        print(f"   ✅ MTM文件存在，包含 {len(mtm_data)} 条重要对话")
    
    # 检查STM文件
    stm_dir = os.path.join(storage_dir, "short_term")
    stm_files = [f for f in os.listdir(stm_dir) if f.startswith("session_")]
    if stm_files:
        print(f"   ✅ STM文件存在，共 {len(stm_files)} 个会话文件")
    
    print("\n" + "="*60)
    print("✅ SMOz Memory System V2.0 测试完成！")
    
    # 11. 输出最终统计
    print("\n📊 最终统计结果")
    final_stats = memory.get_memory_stats()
    print(json.dumps(final_stats, indent=2, ensure_ascii=False))

def test_file_formats():
    """测试文件格式是否符合理想设计"""
    print("\n🔍 验证文件格式符合理想设计")
    
    storage_dir = "sm-docker-local/data/memory/test_user_v2"
    
    # 1. 验证LTM格式
    ltm_file = os.path.join(storage_dir, "long_term", "user_profile.json")
    if os.path.exists(ltm_file):
        with open(ltm_file, 'r', encoding='utf-8') as f:
            ltm_data = json.load(f)
        
        print("✅ LTM格式验证:")
        print(f"   - 包含user_id: {'user_id' in ltm_data}")
        print(f"   - 包含topics_of_interest: {'topics_of_interest' in ltm_data}")
        print(f"   - 包含emotional_tendencies: {'emotional_tendencies' in ltm_data}")
        print(f"   - 包含communication_style: {'communication_style' in ltm_data}")
        print(f"   - 包含interaction_summary: {'interaction_summary' in ltm_data}")
        
        # 确认不包含对话内容
        ltm_str = json.dumps(ltm_data, ensure_ascii=False)
        contains_user_ai = '"user":' in ltm_str and '"ai":' in ltm_str
        print(f"   - 不包含对话结构: {not contains_user_ai}")
    
    # 2. 验证MTM格式
    mtm_file = os.path.join(storage_dir, "medium_term", "important_memories.json")
    if os.path.exists(mtm_file):
        with open(mtm_file, 'r', encoding='utf-8') as f:
            mtm_data = json.load(f)
        
        print("✅ MTM格式验证:")
        if mtm_data:
            sample = mtm_data[0]
            print(f"   - 包含timestamp: {'timestamp' in sample}")
            print(f"   - 包含importance: {'importance' in sample}")
            print(f"   - 包含conversation数组: {'conversation' in sample}")
            print(f"   - 包含topics: {'topics' in sample}")
            print(f"   - 包含emotions: {'emotions' in sample}")
            print(f"   - 包含insight: {'insight' in sample}")
    
    # 3. 验证STM格式
    stm_dir = os.path.join(storage_dir, "short_term")
    if os.path.exists(stm_dir):
        stm_files = [f for f in os.listdir(stm_dir) if f.startswith("session_")]
        if stm_files:
            latest_file = os.path.join(stm_dir, stm_files[-1])
            with open(latest_file, 'r', encoding='utf-8') as f:
                stm_data = json.load(f)
            
            print("✅ STM格式验证:")
            if stm_data:
                sample = stm_data[0]
                print(f"   - 包含timestamp: {'timestamp' in sample}")
                print(f"   - 包含user: {'user' in sample}")
                print(f"   - 包含ai: {'ai' in sample}")
                print(f"   - 包含topics: {'topics' in sample}")
                print(f"   - 包含emotions: {'emotions' in sample}")
                print(f"   - 包含importance: {'importance' in sample}")

if __name__ == "__main__":
    test_memory_system()
    test_file_formats() 