#!/usr/bin/env python3
"""
记忆文档清理脚本
删除无用的旧文档，只保留格式正确的标准化记忆文档
"""

import os
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Dict

class MemoryDocumentCleaner:
    """记忆文档清理器"""
    
    def __init__(self, user_id: str = "default_user"):
        self.user_id = user_id
        self.storage_dir = self._get_storage_dir()
        
        print(f"🧹 开始清理用户 {user_id} 的记忆文档")
    
    def _get_storage_dir(self) -> str:
        """获取存储目录"""
        base_dir = Path(__file__).parent.parent / "sm-docker-local" / "data" / "memory"
        return str(base_dir / self.user_id)
    
    def cleanup_all_documents(self):
        """清理所有无用文档"""
        print("🗂️ 开始全面清理记忆文档...")
        
        # 1. 创建清理前备份
        self._create_cleanup_backup()
        
        # 2. 验证当前格式正确的文档
        valid_documents = self._identify_valid_documents()
        
        # 3. 删除无用的备份和旧文档
        self._cleanup_backup_directories()
        
        # 4. 删除格式错误的文档
        self._cleanup_invalid_documents(valid_documents)
        
        # 5. 清理空目录
        self._cleanup_empty_directories()
        
        # 6. 优化目录结构
        self._optimize_directory_structure()
        
        print("✅ 记忆文档清理完成！")
    
    def _create_cleanup_backup(self):
        """创建清理前备份"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = Path(self.storage_dir) / f"final_cleanup_backup_{timestamp}"
        
        if Path(self.storage_dir).exists():
            # 只备份关键文件
            critical_files = [
                "long_term/user_profile.json",
                "short_term/session_*.json",
                "medium_term/important_memories.json",
                "metadata/user_metadata.json"
            ]
            
            backup_dir.mkdir(parents=True, exist_ok=True)
            
            for pattern in critical_files:
                source_path = Path(self.storage_dir)
                if "/" in pattern:
                    subdir = pattern.split("/")[0]
                    filename = pattern.split("/")[1]
                    
                    # 创建子目录
                    (backup_dir / subdir).mkdir(exist_ok=True)
                    
                    if "*" in filename:
                        # 处理通配符
                        source_subdir = source_path / subdir
                        if source_subdir.exists():
                            pattern_base = filename.replace("*", "")
                            for file in source_subdir.glob(f"*{pattern_base}*"):
                                if file.is_file():
                                    shutil.copy2(file, backup_dir / subdir / file.name)
                    else:
                        source_file = source_path / pattern
                        if source_file.exists():
                            shutil.copy2(source_file, backup_dir / pattern)
            
            print(f"📦 创建最终清理备份: {backup_dir}")
    
    def _identify_valid_documents(self) -> Dict[str, List[str]]:
        """识别格式正确的文档"""
        valid_docs = {
            "short_term": [],
            "medium_term": [],
            "long_term": [],
            "metadata": []
        }
        
        # 检查短期记忆
        stm_dir = Path(self.storage_dir) / "short_term"
        if stm_dir.exists():
            for file in stm_dir.glob("session_*.json"):
                if self._validate_stm_format(file):
                    valid_docs["short_term"].append(str(file))
        
        # 检查中期记忆
        mtm_file = Path(self.storage_dir) / "medium_term" / "important_memories.json"
        if mtm_file.exists() and self._validate_mtm_format(mtm_file):
            valid_docs["medium_term"].append(str(mtm_file))
        
        # 检查长期记忆（用户档案）
        ltm_file = Path(self.storage_dir) / "long_term" / "user_profile.json"
        if ltm_file.exists() and self._validate_ltm_format(ltm_file):
            valid_docs["long_term"].append(str(ltm_file))
        
        # 检查元数据
        metadata_file = Path(self.storage_dir) / "metadata" / "user_metadata.json"
        if metadata_file.exists():
            valid_docs["metadata"].append(str(metadata_file))
        
        total_valid = sum(len(docs) for docs in valid_docs.values())
        print(f"✅ 发现 {total_valid} 个格式正确的文档")
        return valid_docs
    
    def _validate_stm_format(self, file_path: Path) -> bool:
        """验证STM格式"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if not isinstance(data, list):
                return False
            
            if not data:  # 空列表也是有效的
                return True
            
            # 检查第一个条目的格式
            sample = data[0]
            required_fields = ["timestamp", "user", "ai", "topics", "emotions", "importance"]
            
            return all(field in sample for field in required_fields)
            
        except Exception:
            return False
    
    def _validate_mtm_format(self, file_path: Path) -> bool:
        """验证MTM格式"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if not isinstance(data, list):
                return False
            
            if not data:  # 空列表也是有效的
                return True
            
            # 检查第一个条目的格式
            sample = data[0]
            required_fields = ["timestamp", "importance", "conversation", "topics", "emotions", "insight"]
            
            return all(field in sample for field in required_fields)
            
        except Exception:
            return False
    
    def _validate_ltm_format(self, file_path: Path) -> bool:
        """验证LTM格式（用户档案）"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if not isinstance(data, dict):
                return False
            
            # 检查必需字段
            required_fields = [
                "user_id", "companion_start_date", "topics_of_interest", 
                "emotional_tendencies", "communication_style", "relationship_stage",
                "activity_level", "information_sharing_tendency", "average_importance",
                "interaction_summary", "preferences", "behavior_traits", "summary_stats"
            ]
            
            has_required_fields = all(field in data for field in required_fields)
            
            # 验证不包含对话内容
            data_str = json.dumps(data, ensure_ascii=False)
            contains_dialogue = '"user":' in data_str and '"ai":' in data_str
            
            return has_required_fields and not contains_dialogue
            
        except Exception:
            return False
    
    def _cleanup_backup_directories(self):
        """清理备份目录"""
        backup_patterns = [
            "backup_*",
            "migration_backup_*",
            "optimization_backup_*",
            "*_backup"
        ]
        
        deleted_count = 0
        for pattern in backup_patterns:
            for backup_dir in Path(self.storage_dir).glob(pattern):
                if backup_dir.is_dir():
                    try:
                        shutil.rmtree(backup_dir)
                        deleted_count += 1
                        print(f"🗑️ 删除备份目录: {backup_dir.name}")
                    except Exception as e:
                        print(f"⚠️ 删除备份目录失败 {backup_dir}: {e}")
        
        print(f"🧹 清理了 {deleted_count} 个备份目录")
    
    def _cleanup_invalid_documents(self, valid_documents: Dict[str, List[str]]):
        """清理格式错误的文档"""
        
        # 清理长期记忆中的旧文件
        ltm_dir = Path(self.storage_dir) / "long_term"
        if ltm_dir.exists():
            valid_ltm_files = {Path(f).name for f in valid_documents["long_term"]}
            
            for file in ltm_dir.glob("*.json"):
                if file.name not in valid_ltm_files:
                    try:
                        file.unlink()
                        print(f"🗑️ 删除无效LTM文件: {file.name}")
                    except Exception as e:
                        print(f"⚠️ 删除文件失败 {file}: {e}")
            
            # 删除 .old 文件
            for old_file in ltm_dir.glob("*.old"):
                try:
                    old_file.unlink()
                    print(f"🗑️ 删除备份文件: {old_file.name}")
                except Exception as e:
                    print(f"⚠️ 删除备份文件失败 {old_file}: {e}")
        
        # 清理短期记忆中的旧文件
        stm_dir = Path(self.storage_dir) / "short_term"
        if stm_dir.exists():
            valid_stm_files = {Path(f).name for f in valid_documents["short_term"]}
            
            for file in stm_dir.glob("*.json"):
                if file.name not in valid_stm_files:
                    try:
                        file.unlink()
                        print(f"🗑️ 删除无效STM文件: {file.name}")
                    except Exception as e:
                        print(f"⚠️ 删除文件失败 {file}: {e}")
        
        print("🧹 清理了格式错误的文档")
    
    def _cleanup_empty_directories(self):
        """清理空目录"""
        empty_dirs = []
        
        for root, dirs, files in os.walk(self.storage_dir, topdown=False):
            for dir_name in dirs:
                dir_path = Path(root) / dir_name
                try:
                    if not any(dir_path.iterdir()):
                        empty_dirs.append(dir_path)
                except PermissionError:
                    continue
        
        for empty_dir in empty_dirs:
            # 不删除标准目录结构
            if empty_dir.name not in ["short_term", "medium_term", "long_term", "metadata"]:
                try:
                    empty_dir.rmdir()
                    print(f"🗑️ 删除空目录: {empty_dir.name}")
                except Exception as e:
                    print(f"⚠️ 删除空目录失败 {empty_dir}: {e}")
        
        print(f"🧹 清理了 {len(empty_dirs)} 个空目录")
    
    def _optimize_directory_structure(self):
        """优化目录结构"""
        required_dirs = ["short_term", "medium_term", "long_term", "metadata"]
        
        for dir_name in required_dirs:
            dir_path = Path(self.storage_dir) / dir_name
            if not dir_path.exists():
                dir_path.mkdir(parents=True, exist_ok=True)
                print(f"📁 创建标准目录: {dir_name}")
        
        # 删除不需要的目录
        unnecessary_dirs = ["profiles", "user_profile", "daily_summaries", "sessions"]
        for dir_name in unnecessary_dirs:
            dir_path = Path(self.storage_dir) / dir_name
            if dir_path.exists() and dir_path.is_dir():
                try:
                    shutil.rmtree(dir_path)
                    print(f"🗑️ 删除不需要的目录: {dir_name}")
                except Exception as e:
                    print(f"⚠️ 删除目录失败 {dir_path}: {e}")
        
        print("📁 目录结构已优化")
    
    def get_cleanup_report(self) -> Dict:
        """生成清理报告"""
        report = {
            "user_id": self.user_id,
            "cleanup_time": datetime.now().isoformat(),
            "final_structure": {},
            "memory_stats": {}
        }
        
        # 统计最终文件结构
        for subdir in ["short_term", "medium_term", "long_term", "metadata"]:
            dir_path = Path(self.storage_dir) / subdir
            if dir_path.exists():
                files = list(dir_path.glob("*.json"))
                report["final_structure"][subdir] = {
                    "file_count": len(files),
                    "files": [f.name for f in files]
                }
            else:
                report["final_structure"][subdir] = {
                    "file_count": 0,
                    "files": []
                }
        
        # 验证记忆文档
        total_files = sum(info["file_count"] for info in report["final_structure"].values())
        
        report["memory_stats"] = {
            "total_files": total_files,
            "structure_valid": self._validate_final_structure(),
            "format_compliance": self._check_format_compliance()
        }
        
        return report
    
    def _validate_final_structure(self) -> bool:
        """验证最终结构"""
        required_dirs = ["short_term", "medium_term", "long_term", "metadata"]
        
        for dir_name in required_dirs:
            dir_path = Path(self.storage_dir) / dir_name
            if not dir_path.exists():
                return False
        
        return True
    
    def _check_format_compliance(self) -> Dict:
        """检查格式合规性"""
        compliance = {
            "stm_format_valid": False,
            "mtm_format_valid": False,
            "ltm_format_valid": False,
            "ltm_privacy_compliant": False
        }
        
        # 检查STM格式
        stm_files = list(Path(self.storage_dir).glob("short_term/session_*.json"))
        if stm_files:
            compliance["stm_format_valid"] = any(self._validate_stm_format(f) for f in stm_files)
        
        # 检查MTM格式
        mtm_file = Path(self.storage_dir) / "medium_term" / "important_memories.json"
        if mtm_file.exists():
            compliance["mtm_format_valid"] = self._validate_mtm_format(mtm_file)
        
        # 检查LTM格式和隐私合规
        ltm_file = Path(self.storage_dir) / "long_term" / "user_profile.json"
        if ltm_file.exists():
            compliance["ltm_format_valid"] = self._validate_ltm_format(ltm_file)
            
            # 验证隐私合规（不包含对话内容）
            try:
                with open(ltm_file, 'r', encoding='utf-8') as f:
                    data_str = f.read()
                compliance["ltm_privacy_compliant"] = '"user":' not in data_str or '"ai":' not in data_str
            except:
                compliance["ltm_privacy_compliant"] = False
        
        return compliance


def main():
    """主函数"""
    print("🧹 开始记忆文档清理")
    print("目标: 删除无用文档，只保留格式正确的标准化文档")
    print("="*60)
    
    # 创建清理器并执行清理
    cleaner = MemoryDocumentCleaner(user_id="default_user")
    cleaner.cleanup_all_documents()
    
    # 生成清理报告
    report = cleaner.get_cleanup_report()
    
    print("\n📊 清理报告:")
    print(f"总文件数: {report['memory_stats']['total_files']}")
    print(f"结构有效: {report['memory_stats']['structure_valid']}")
    print(f"格式合规: {report['memory_stats']['format_compliance']}")
    
    # 保存报告
    report_file = Path(cleaner.storage_dir) / "cleanup_report.json"
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    
    print(f"\n📄 清理报告已保存: {report_file}")
    print("\n🎉 记忆文档清理完成！现在只保留格式正确的标准化文档。")


if __name__ == "__main__":
    main() 