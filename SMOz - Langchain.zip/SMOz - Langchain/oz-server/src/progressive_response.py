"""
渐进式响应系统 - 延迟优化策略4
通过分阶段响应提供流畅的用户体验
"""

import asyncio
import time
import re
from typing import Dict, AsyncGenerator, List, Optional
from datetime import datetime
from openai import OpenAI
import json

class ProgressiveResponseSystem:
    """
    渐进式响应系统
    
    响应流程：
    1. 快速确认 (0.3s) - 立即表示理解，建立互动感
    2. 记忆提示 (1s) - 展示相关记忆，证明个性化
    3. 完整回复 (3s) - 深度分析和完整响应
    
    每个阶段都是独立的，前一阶段失败不影响后续阶段
    """
    
    def __init__(self):
        self.client = OpenAI()
        self.response_history = []
        
        # 快速确认模板
        self.quick_acknowledgments = {
            "question": [
                "Let me think about that...",
                "That's an interesting question...",
                "I want to give you a thoughtful answer...",
                "Hmm, let me consider this..."
            ],
            "emotional_positive": [
                "That sounds wonderful!",
                "I'm so glad to hear that!",
                "That's fantastic news!",
                "How exciting!"
            ],
            "emotional_negative": [
                "I hear you...",
                "That sounds difficult...",
                "I understand how you feel...",
                "I'm here for you..."
            ],
            "sharing": [
                "Thanks for sharing that with me...",
                "I appreciate you telling me...",
                "That's really interesting...",
                "I'm listening..."
            ],
            "greeting": [
                "Hi there!",
                "Great to see you!",
                "Hello!",
                "Hey!"
            ],
            "goodbye": [
                "Take care!",
                "See you soon!",
                "Goodbye!",
                "Until next time!"
            ],
            "default": [
                "I hear you...",
                "Let me process that...",
                "I'm thinking...",
                "Give me a moment..."
            ]
        }
        
        # 记忆提示模板
        self.memory_hint_templates = [
            "I remember we talked about {topic}...",
            "This reminds me of when you mentioned {detail}...",
            "Based on what you've shared before about {context}...",
            "I recall you saying {previous_info}...",
            "This connects to what you told me about {related_topic}..."
        ]
        
    async def generate_progressive_response(
        self, 
        user_input: str, 
        memory_system,
        complexity: str = "medium"
    ) -> AsyncGenerator[Dict, None]:
        """
        生成渐进式响应
        
        Yields:
        {
            "stage": str,           # "acknowledgment", "memory_hint", "full_response"
            "content": str,         # 响应内容
            "confidence": float,    # 置信度
            "elapsed_time": float,  # 经过时间
            "is_final": bool       # 是否为最终响应
        }
        """
        start_time = time.time()
        
        try:
            # 阶段1: 快速确认 (目标 < 0.5秒)
            acknowledgment = await self.generate_quick_acknowledgment(user_input)
            yield {
                "stage": "acknowledgment",
                "content": acknowledgment,
                "confidence": 0.9,
                "elapsed_time": time.time() - start_time,
                "is_final": False
            }
            
            # 异步启动记忆检索
            memory_task = asyncio.create_task(
                self.get_memory_hint(user_input, memory_system)
            )
            
            # 阶段2: 记忆提示 (目标 < 1.5秒)
            try:
                memory_hint = await asyncio.wait_for(memory_task, timeout=1.2)
                if memory_hint:
                    yield {
                        "stage": "memory_hint", 
                        "content": memory_hint,
                        "confidence": 0.8,
                        "elapsed_time": time.time() - start_time,
                        "is_final": False
                    }
            except asyncio.TimeoutError:
                print("记忆提示超时，跳过...")
                memory_task.cancel()
            
            # 阶段3: 完整响应 (目标 < 4秒)
            full_response_task = asyncio.create_task(
                self.generate_full_response(user_input, memory_system, complexity)
            )
            
            try:
                full_response = await asyncio.wait_for(full_response_task, timeout=3.5)
                yield {
                    "stage": "full_response",
                    "content": full_response,
                    "confidence": 1.0,
                    "elapsed_time": time.time() - start_time,
                    "is_final": True
                }
            except asyncio.TimeoutError:
                print("完整响应超时，提供备用回复...")
                full_response_task.cancel()
                
                fallback = await self.generate_fallback_response(user_input)
                yield {
                    "stage": "fallback",
                    "content": fallback,
                    "confidence": 0.6,
                    "elapsed_time": time.time() - start_time,
                    "is_final": True
                }
                
        except Exception as e:
            print(f"渐进式响应生成失败: {e}")
            
            # 紧急备用响应
            emergency_response = "I'm processing your message. Let me get back to you with a thoughtful response."
            yield {
                "stage": "emergency",
                "content": emergency_response,
                "confidence": 0.3,
                "elapsed_time": time.time() - start_time,
                "is_final": True
            }
    
    async def generate_quick_acknowledgment(self, user_input: str) -> str:
        """生成快速确认回复"""
        
        # 分类用户输入类型
        message_type = self.classify_message_type(user_input)
        
        # 选择合适的确认模板
        if message_type in self.quick_acknowledgments:
            templates = self.quick_acknowledgments[message_type]
        else:
            templates = self.quick_acknowledgments["default"]
        
        # 根据历史避免重复
        available_templates = [t for t in templates if t not in self.get_recent_acknowledgments()]
        if not available_templates:
            available_templates = templates  # 重置避免空列表
        
        import random
        selected = random.choice(available_templates)
        
        # 记录使用历史
        self.record_acknowledgment(selected)
        
        return selected
    
    def classify_message_type(self, text: str) -> str:
        """分类消息类型"""
        
        text_lower = text.lower().strip()
        
        # 问候
        if any(greeting in text_lower for greeting in ["hi", "hello", "hey", "good morning", "good evening"]):
            return "greeting"
        
        # 告别
        if any(goodbye in text_lower for goodbye in ["bye", "goodbye", "see you", "gotta go", "take care"]):
            return "goodbye"
        
        # 问题
        if text.endswith('?') or any(qword in text_lower for qword in ["what", "how", "why", "when", "where", "who"]):
            return "question"
        
        # 正面情绪
        positive_words = ["great", "wonderful", "amazing", "fantastic", "excellent", "happy", "excited", "good"]
        if any(word in text_lower for word in positive_words):
            return "emotional_positive"
        
        # 负面情绪
        negative_words = ["sad", "depressed", "worried", "anxious", "terrible", "awful", "bad", "upset"]
        if any(word in text_lower for word in negative_words):
            return "emotional_negative"
        
        # 分享类
        sharing_indicators = ["i", "my", "today i", "yesterday", "i feel", "i think", "i went"]
        if any(indicator in text_lower for indicator in sharing_indicators):
            return "sharing"
        
        return "default"
    
    async def get_memory_hint(self, user_input: str, memory_system) -> Optional[str]:
        """获取记忆提示"""
        
        try:
            # 快速记忆检索
            if hasattr(memory_system, 'get_contextual_memory'):
                relevant_memory = memory_system.get_contextual_memory(user_input)
                
                if relevant_memory and len(relevant_memory.strip()) > 10:
                    # 提取关键信息
                    memory_snippet = self.extract_memory_snippet(relevant_memory)
                    
                    if memory_snippet:
                        # 生成记忆提示
                        hint = self.format_memory_hint(memory_snippet)
                        return hint
            
            # 检查用户偏好
            if hasattr(memory_system, 'conversation_metadata'):
                prefs = memory_system.conversation_metadata.get("user_preferences", {})
                if prefs:
                    recent_pref = list(prefs.values())[-1]  # 最近的偏好
                    if len(recent_pref) > 15:
                        return f"Thinking about what you shared: {recent_pref[:50]}..."
            
            return None
            
        except Exception as e:
            print(f"记忆提示生成失败: {e}")
            return None
    
    def extract_memory_snippet(self, memory_text: str) -> Optional[str]:
        """提取记忆片段"""
        
        # 寻找有价值的信息
        sentences = memory_text.split('.')
        
        for sentence in sentences:
            sentence = sentence.strip()
            
            # 寻找包含个人信息的句子
            personal_indicators = ["name", "work", "like", "love", "family", "friend", "hobby"]
            if any(indicator in sentence.lower() for indicator in personal_indicators):
                if len(sentence) > 10 and len(sentence) < 100:
                    return sentence
        
        # 如果没找到，返回第一个合理长度的句子
        for sentence in sentences:
            sentence = sentence.strip()
            if 15 < len(sentence) < 80:
                return sentence
        
        return None
    
    def format_memory_hint(self, memory_snippet: str) -> str:
        """格式化记忆提示"""
        
        import random
        
        # 如果snippet包含具体信息，使用具体模板
        if any(word in memory_snippet.lower() for word in ["name", "work", "like"]):
            templates = [
                f"I remember: {memory_snippet[:40]}...",
                f"Based on what you've told me: {memory_snippet[:35]}...",
                f"Thinking about: {memory_snippet[:45]}..."
            ]
        else:
            templates = [
                f"This reminds me of our previous conversation...",
                f"I'm recalling what you shared before...",
                f"Building on what we discussed..."
            ]
        
        return random.choice(templates)
    
    async def generate_full_response(self, user_input: str, memory_system, complexity: str) -> str:
        """生成完整响应"""
        
        try:
            # 使用记忆系统生成完整回复
            if hasattr(memory_system, 'process_message'):
                return await memory_system.process_message(user_input)
            
            # 备用：直接使用LLM
            return await self.generate_direct_response(user_input, complexity)
            
        except Exception as e:
            print(f"完整响应生成失败: {e}")
            return await self.generate_fallback_response(user_input)
    
    async def generate_direct_response(self, user_input: str, complexity: str) -> str:
        """直接生成响应（无记忆系统）"""
        
        complexity_prompts = {
            "ultra_simple": "Respond very briefly (10-20 words) as Lucy.",
            "simple": "Respond naturally (20-40 words) as Lucy, a friendly AI companion.",
            "medium": "Respond thoughtfully (30-60 words) as Lucy, showing empathy and understanding.",
            "complex": "Respond comprehensively as Lucy, a psychologically aware AI companion. Show deep understanding."
        }
        
        prompt = complexity_prompts.get(complexity, complexity_prompts["medium"])
        
        try:
            response = await self.client.chat.completions.create(
                model="gpt-4.1-nano",
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": user_input}
                ],
                max_tokens=100,
                temperature=0.7,
                timeout=2.5
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            print(f"直接响应生成失败: {e}")
            return await self.generate_fallback_response(user_input)
    
    async def generate_fallback_response(self, user_input: str) -> str:
        """生成备用响应"""
        
        fallback_responses = [
            "I'm still processing your message. Let me give you a more complete response in just a moment.",
            "That's a thoughtful message. I want to give you a proper response - just give me a second.",
            "I'm thinking about what you've shared. Let me respond more fully in a moment.",
            "I appreciate you sharing that with me. I'm working on a thoughtful response.",
            "Thanks for your patience. I want to give you the response you deserve."
        ]
        
        import random
        return random.choice(fallback_responses)
    
    def get_recent_acknowledgments(self, count: int = 3) -> List[str]:
        """获取最近使用的确认回复"""
        
        recent = [entry.get("acknowledgment", "") for entry in self.response_history[-count:]]
        return [ack for ack in recent if ack]
    
    def record_acknowledgment(self, acknowledgment: str):
        """记录确认回复"""
        
        self.response_history.append({
            "acknowledgment": acknowledgment,
            "timestamp": datetime.now().isoformat()
        })
        
        # 保持历史记录大小
        if len(self.response_history) > 50:
            self.response_history = self.response_history[-50:]
    
    def get_performance_stats(self) -> Dict:
        """获取性能统计"""
        
        if not self.response_history:
            return {"message": "No progressive response data yet"}
        
        recent_responses = self.response_history[-20:]  # 最近20次
        
        acknowledgment_variety = len(set(
            entry.get("acknowledgment", "") for entry in recent_responses
        ))
        
        return {
            "total_progressive_responses": len(self.response_history),
            "recent_acknowledgment_variety": acknowledgment_variety,
            "acknowledgment_templates": len(sum(self.quick_acknowledgments.values(), [])),
            "memory_hint_templates": len(self.memory_hint_templates)
        }


# 使用示例和集成函数
class ProgressiveResponseHandler:
    """渐进式响应处理器 - WebSocket集成"""
    
    def __init__(self, websocket_manager=None):
        self.progressive_system = ProgressiveResponseSystem()
        self.websocket_manager = websocket_manager
        
    async def handle_progressive_response(self, user_input: str, memory_system, complexity: str = "medium"):
        """处理渐进式响应并通过WebSocket发送"""
        
        response_stages = []
        
        async for stage_response in self.progressive_system.generate_progressive_response(
            user_input, memory_system, complexity
        ):
            response_stages.append(stage_response)
            
            # 发送阶段响应到前端
            if self.websocket_manager:
                await self.websocket_manager.send_progressive_update(stage_response)
                
            # 如果是最终响应，结束流程
            if stage_response.get("is_final", False):
                break
        
        return response_stages
    
    async def send_progressive_update(self, stage_response: Dict):
        """发送渐进式更新到前端"""
        
        message = {
            "kind": "progressive_response",
            "stage": stage_response["stage"],
            "content": stage_response["content"],
            "confidence": stage_response["confidence"],
            "elapsed_time": round(stage_response["elapsed_time"], 2),
            "is_final": stage_response["is_final"],
            "timestamp": datetime.now().isoformat()
        }
        
        if self.websocket_manager:
            await self.websocket_manager.broadcast_json(message)


# 全局实例
progressive_system = ProgressiveResponseSystem()

# 导出函数
async def generate_progressive_response(user_input: str, memory_system, complexity: str = "medium"):
    """生成渐进式响应的主函数"""
    async for response in progressive_system.generate_progressive_response(user_input, memory_system, complexity):
        yield response

def get_progressive_stats():
    """获取渐进式响应统计"""
    return progressive_system.get_performance_stats() 