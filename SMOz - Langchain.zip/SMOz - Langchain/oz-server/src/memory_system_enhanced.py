"""
Enhanced Memory System for Lucy AI Companion
基于标准化三层记忆架构的优化记忆系统
"""

import os
import json
import uuid
import pickle
import random
import hashlib
import asyncio
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from collections import defaultdict, Counter
from dataclasses import dataclass, asdict

from langchain_core.vectorstores.in_memory import InMemoryVectorStore
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_core.documents import Document
from langchain.schema import SystemMessage, HumanMessage
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationSummaryBufferMemory

# 🧪 测试模式的模拟组件
class MockEmbeddings:
    """模拟的Embedding组件，用于测试模式"""
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """为文档生成模拟的embedding向量"""
        return [[random.random() for _ in range(384)] for _ in texts]
    
    def embed_query(self, text: str) -> List[float]:
        """为查询生成模拟的embedding向量"""
        return [random.random() for _ in range(384)]

class MockLLM:
    """模拟的LLM组件，用于测试模式"""
    
    def invoke(self, messages):
        """模拟LLM调用"""
        return MockResponse("This is a mock response for testing purposes.")
    
    async def ainvoke(self, messages):
        """模拟异步LLM调用"""
        return MockResponse("This is a mock async response for testing purposes.")

class MockResponse:
    """模拟的LLM响应"""
    
    def __init__(self, content):
        self.content = content

class MockSummarizer:
    """模拟的记忆总结器"""
    
    def __init__(self):
        pass
    
    def predict_new_summary(self, messages, existing_summary):
        return "Mock summary for testing"

class EnhancedMemorySystem:
    """
    基于标准化三层记忆架构的增强记忆系统
    
    特性:
    - 三层记忆架构 (STM/MTM/LTM)
    - LTM只存储结构化用户档案，不包含对话内容
    - MTM存储重要的完整对话
    - STM缓存最近的对话轮次
    """
    
    def __init__(self, 
                 embedding_model: str = "text-embedding-3-small",
                 llm_model: str = "gpt-4.1",
                 max_short_term: int = 10,
                 max_medium_term: int = 50,
                 memory_threshold: float = 0.5,
                 user_id: str = None,
                 test_mode: bool = False):
        
        # 用户标识和会话管理
        self.user_id = user_id or "default_user"
        self.session_id = str(uuid.uuid4())
        self.companion_start_date = datetime.now().strftime("%Y-%m-%d")
        self.test_mode = test_mode
        
        # 记忆容量配置
        self.max_short_term = max_short_term
        self.max_medium_term = max_medium_term
        self.memory_threshold = memory_threshold
        
        # 初始化组件
        try:
            if not test_mode:
                self.embeddings = OpenAIEmbeddings(model=embedding_model)
                self.llm = ChatOpenAI(model=llm_model, temperature=0.3)
            else:
                self.embeddings = MockEmbeddings()
                self.llm = MockLLM()
                self.summarizer = MockSummarizer()
        except Exception as e:
            print(f"⚠️ 无法初始化LLM/Embeddings，切换到测试模式: {e}")
            self.test_mode = True
            self.embeddings = MockEmbeddings()
            self.llm = MockLLM()
            self.summarizer = MockSummarizer()
        
        # 设置存储目录
        self.storage_dir = self._get_user_storage_dir()
        self._ensure_directory_structure()
        
        # 初始化记忆存储
        self.short_term_memories = []  # 短期记忆：最近的对话轮次
        self.medium_term_memories = []  # 中期记忆：重要的完整对话
        self.user_profile = self._load_user_profile()  # 长期记忆：结构化用户档案
        
        # 加载现有记忆
        self._load_existing_memories()
        
        # 初始化统计信息
        self.total_conversations = 0
        self.conversation_count = 0
        
        print(f"✅ Memory System initialized for user: {self.user_id}")
        print(f"📊 STM: {len(self.short_term_memories)}, MTM: {len(self.medium_term_memories)}")

    def _get_user_storage_dir(self) -> str:
        """获取用户专用的存储目录"""
        # 🔥 修复路径计算 - 检查是否在Docker容器内
        current_file = os.path.abspath(__file__)
        
        # 如果在Docker容器内（/code/src/），直接使用固定路径
        if current_file.startswith('/code/'):
            base_dir = "/code/data/memory"
        else:
            # 在开发环境中，使用相对路径
            base_dir = os.path.join(os.path.dirname(__file__), "..", "..", "sm-docker-local", "data", "memory")
        
        user_dir = os.path.join(base_dir, self.user_id)
        return user_dir

    def _ensure_directory_structure(self):
        """确保目录结构存在"""
        for subdir in ["short_term", "medium_term", "long_term", "metadata"]:
            dir_path = os.path.join(self.storage_dir, subdir)
            os.makedirs(dir_path, exist_ok=True)

    def _load_user_profile(self) -> Dict:
        """加载或初始化用户档案 (LTM)"""
        profile_file = os.path.join(self.storage_dir, "long_term", "user_profile.json")
        
        if os.path.exists(profile_file):
            with open(profile_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        
        # 初始化新用户档案
        return {
            "user_id": self.user_id,
            "companion_start_date": self.companion_start_date,
            "topics_of_interest": [],
            "emotional_tendencies": [],
            "communication_style": "Unknown",
            "relationship_stage": "Initial contact",
            "activity_level": "Unknown",
            "information_sharing_tendency": "Unknown",
            "average_importance": 0.0,
            "interaction_summary": {
                "total_conversations": 0,
                "last_interaction": None
            },
            "preferences": {},
            "behavior_traits": [],
            "summary_stats": {
                "most_discussed_topics": {},
                "dominant_emotions": {},
                "relationship_duration_days": 0
            }
        }

    def _load_existing_memories(self):
        """加载现有的记忆文件"""
        # 加载短期记忆
        self._load_short_term_memories()
        
        # 加载中期记忆
        self._load_medium_term_memories()
        
        # 用户档案已在 _load_user_profile 中加载

    def _load_short_term_memories(self):
        """加载短期记忆文件"""
        short_term_dir = os.path.join(self.storage_dir, "short_term")
        if not os.path.exists(short_term_dir):
            return
        
        # 获取最新的会话文件
        session_files = [f for f in os.listdir(short_term_dir) if f.startswith("session_")]
        if not session_files:
            return
        
        # 按时间排序，加载最新的
        session_files.sort(reverse=True)
        latest_file = os.path.join(short_term_dir, session_files[0])
        
        try:
            with open(latest_file, 'r', encoding='utf-8') as f:
                memories = json.load(f)
                self.short_term_memories = memories[-self.max_short_term:]  # 只保留最近的
        except Exception as e:
            print(f"⚠️ 加载短期记忆失败: {e}")

    def _load_medium_term_memories(self):
        """加载中期记忆文件"""
        medium_file = os.path.join(self.storage_dir, "medium_term", "important_memories.json")
        if os.path.exists(medium_file):
            try:
                with open(medium_file, 'r', encoding='utf-8') as f:
                    self.medium_term_memories = json.load(f)
            except Exception as e:
                print(f"⚠️ 加载中期记忆失败: {e}")

    def add_conversation(self, user_message: str, ai_response: str):
        """添加新的对话到记忆系统"""
        now = datetime.now()
        
        # 提取元数据
        metadata = self._extract_metadata_simple(user_message, ai_response)
        importance = self._calculate_importance_score(user_message, metadata)
        
        # 创建对话记录
        conversation = {
            "timestamp": now.isoformat(),
            "user": user_message,
            "ai": ai_response,
            "topics": metadata.get("topics", ["general"]),
            "emotions": metadata.get("emotions", ["neutral"]),
            "importance": importance
        }
        
        # 添加到短期记忆
        self.short_term_memories.append(conversation)
        
        # 如果重要，添加到中期记忆
        if importance > self.memory_threshold:
            self._add_to_medium_term(conversation, metadata)
        
        # 更新用户档案
        self._update_user_profile(conversation, metadata)
        
        # 维护记忆大小
        self._maintain_memory_limits()
        
        # 定期保存
        self.conversation_count += 1
        if self.conversation_count % 5 == 0:  # 每5次对话保存一次
            self.save_all_memories()

    def _extract_metadata_simple(self, user_message: str, ai_response: str) -> Dict:
        """简化的元数据提取 - 增强个人信息识别"""
        content = (user_message + " " + ai_response).lower()
        user_msg_lower = user_message.lower()
        
        # 话题检测
        topic_keywords = {
            "work": ["work", "job", "career", "office", "boss", "工作", "职业"],
            "reading": ["book", "read", "novel", "author", "story", "书", "阅读"],
            "family": ["family", "parent", "child", "mom", "dad", "家庭", "父母"],
            "pets": ["cat", "dog", "pet", "animal", "猫", "狗", "宠物"],
            "emotions": ["feel", "happy", "sad", "stressed", "worried", "感觉", "开心", "难过"],
            "hobbies": ["hobby", "interest", "like", "enjoy", "爱好", "兴趣"],
            "greeting": ["hi", "hello", "how are", "good morning", "你好", "早上好"],
            "personal_info": ["name", "birthday", "age", "birth", "born", "名字", "生日", "年龄"]
        }
        
        detected_topics = []
        for topic, keywords in topic_keywords.items():
            if any(keyword in content for keyword in keywords):
                detected_topics.append(topic.title())
        
        if not detected_topics:
            detected_topics = ["General"]
        
        # 情绪检测
        emotion_keywords = {
            "positive": ["happy", "excited", "great", "good", "love", "wonderful", "开心", "兴奋", "好"],
            "negative": ["sad", "angry", "stressed", "worried", "difficult", "problem", "难过", "生气", "压力"],
            "neutral": ["okay", "fine", "normal", "还好", "正常"]
        }
        
        detected_emotions = []
        for emotion, keywords in emotion_keywords.items():
            if any(keyword in content for keyword in keywords):
                detected_emotions.append(emotion.title())
        
        if not detected_emotions:
            detected_emotions = ["Neutral"]
        
        # 增强的个人信息检测和提取
        personal_info = {}
        has_personal_info = False
        
        # 检测名字
        name_patterns = [
            r"my name is\s+(\w+)",
            r"i'm\s+(\w+)",
            r"call me\s+(\w+)",
            r"i am\s+(\w+)"
        ]
        
        import re
        for pattern in name_patterns:
            match = re.search(pattern, user_msg_lower)
            if match:
                name = match.group(1).title()
                personal_info["name"] = name
                has_personal_info = True
                break
        
        # 检测生日
        birthday_patterns = [
            r"my birthday is\s+(.+?)(?:\.|$)",
            r"born on\s+(.+?)(?:\.|$)",
            r"birthday\s+(.+?)(?:\.|$)"
        ]
        
        for pattern in birthday_patterns:
            match = re.search(pattern, user_msg_lower)
            if match:
                birthday_text = match.group(1).strip()
                # 🔥 智能时间解析：将相对时间转换为具体日期
                parsed_birthday = self._parse_relative_date(birthday_text)
                personal_info["birthday"] = parsed_birthday
                has_personal_info = True
                break
        
        # 检测其他个人信息
        if any(keyword in content for keyword in [
            "my name", "i am", "i work", "i like", "i love", "i hate", "i feel",
            "我叫", "我是", "我工作", "我喜欢", "我讨厌", "我觉得"
        ]):
            has_personal_info = True
        
        return {
            "topics": detected_topics,
            "emotions": detected_emotions,
            "has_personal_info": has_personal_info,
            "personal_info": personal_info,  # 新增：具体的个人信息
            "user_message_length": len(user_message),
            "emotional_intensity": self._calculate_emotional_intensity(content)
        }

    def _calculate_importance_score(self, user_message: str, metadata: Dict) -> float:
        """计算对话重要性分数"""
        score = 0.0
        
        # 基础分数
        score += 0.1
        
        # 个人信息分享
        if metadata.get("has_personal_info"):
            score += 0.4
        
        # 情感强度
        score += metadata.get("emotional_intensity", 0.0) * 0.3
        
        # 消息长度 (长消息通常更重要)
        length_score = min(metadata.get("user_message_length", 0) / 100, 0.3)
        score += length_score
        
        # 特定话题加分
        important_topics = ["work", "family", "emotions", "problems"]
        topics = [t.lower() for t in metadata.get("topics", [])]
        if any(topic in topics for topic in important_topics):
            score += 0.2
        
        return min(score, 1.0)

    def _calculate_emotional_intensity(self, content: str) -> float:
        """计算情感强度"""
        intensity_keywords = {
            "high": ["very", "really", "extremely", "so much", "incredibly", "非常", "特别", "超级"],
            "medium": ["quite", "pretty", "somewhat", "还挺", "比较"],
            "low": ["a bit", "slightly", "maybe", "perhaps", "可能", "有点"]
        }
        
        for level, keywords in intensity_keywords.items():
            if any(keyword in content for keyword in keywords):
                if level == "high":
                    return 0.8
                elif level == "medium":
                    return 0.5
                else:
                    return 0.2
        
        return 0.3  # 默认强度

    def _parse_relative_date(self, date_text: str) -> str:
        """解析相对时间描述，转换为具体日期"""
        from datetime import datetime, timedelta
        
        now = datetime.now()
        date_text = date_text.lower().strip()
        
        # 处理相对时间描述
        if date_text in ["yesterday", "昨天"]:
            target_date = now - timedelta(days=1)
            return target_date.strftime("%Y-%m-%d")
        elif date_text in ["today", "今天"]:
            return now.strftime("%Y-%m-%d")
        elif date_text in ["tomorrow", "明天"]:
            target_date = now + timedelta(days=1)
            return target_date.strftime("%Y-%m-%d")
        elif "days ago" in date_text or "天前" in date_text:
            # 提取数字
            import re
            match = re.search(r"(\d+)", date_text)
            if match:
                days = int(match.group(1))
                target_date = now - timedelta(days=days)
                return target_date.strftime("%Y-%m-%d")
        elif "last week" in date_text or "上周" in date_text:
            target_date = now - timedelta(days=7)
            return target_date.strftime("%Y-%m-%d")
        elif "next week" in date_text or "下周" in date_text:
            target_date = now + timedelta(days=7)
            return target_date.strftime("%Y-%m-%d")
        
        # 尝试解析常见日期格式
        date_formats = [
            "%Y-%m-%d",      # 2025-05-29
            "%m/%d/%Y",      # 05/29/2025
            "%d/%m/%Y",      # 29/05/2025
            "%m-%d",         # 05-29
            "%B %d",         # May 29
            "%b %d",         # May 29
            "%d %B",         # 29 May
            "%d %b"          # 29 May
        ]
        
        for fmt in date_formats:
            try:
                parsed = datetime.strptime(date_text, fmt)
                # 如果只有月日，假设是今年
                if parsed.year == 1900:
                    parsed = parsed.replace(year=now.year)
                return parsed.strftime("%Y-%m-%d")
            except ValueError:
                continue
        
        # 如果无法解析，返回原文本但添加日期标记
        return f"{date_text} (记录于 {now.strftime('%Y-%m-%d')})"

    def _add_to_medium_term(self, conversation: Dict, metadata: Dict):
        """添加重要对话到中期记忆"""
        medium_conversation = {
            "timestamp": conversation["timestamp"],
            "importance": conversation["importance"],
            "conversation": [
                {
                    "user": conversation["user"],
                    "ai": conversation["ai"]
                }
            ],
            "topics": conversation["topics"],
            "emotions": conversation["emotions"],
            "insight": self._generate_conversation_insight(conversation, metadata)
        }
        
        self.medium_term_memories.append(medium_conversation)

    def _generate_conversation_insight(self, conversation: Dict, metadata: Dict) -> str:
        """为对话生成洞察"""
        topics = conversation["topics"]
        emotions = conversation["emotions"]
        importance = conversation["importance"]
        
        if metadata.get("has_personal_info"):
            return f"User shared personal information about {', '.join(topics)} with {', '.join(emotions)} emotions (importance: {importance:.2f})"
        elif importance > 0.7:
            return f"Significant conversation about {', '.join(topics)} with high emotional engagement"
        else:
            return f"Important discussion about {', '.join(topics)} topics"

    def _update_user_profile(self, conversation: Dict, metadata: Dict):
        """更新用户档案 (LTM) - 增强个人信息保存"""
        now = datetime.now()
        
        # 更新基本统计
        self.user_profile["interaction_summary"]["total_conversations"] += 1
        self.user_profile["interaction_summary"]["last_interaction"] = now.isoformat()
        
        # 保存具体的个人信息
        personal_info = metadata.get("personal_info", {})
        if personal_info:
            if "personal_details" not in self.user_profile:
                self.user_profile["personal_details"] = {}
            
            # 保存名字
            if "name" in personal_info:
                self.user_profile["personal_details"]["name"] = personal_info["name"]
                print(f"💡 保存用户名字: {personal_info['name']}")
            
            # 保存生日信息
            if "birthday" in personal_info:
                self.user_profile["personal_details"]["birthday"] = personal_info["birthday"]
                print(f"💡 保存用户生日: {personal_info['birthday']}")
        
        # 更新话题兴趣
        for topic in conversation["topics"]:
            if topic not in self.user_profile["topics_of_interest"]:
                self.user_profile["topics_of_interest"].append(topic)
        
        # 更新情感倾向
        for emotion in conversation["emotions"]:
            if emotion not in self.user_profile["emotional_tendencies"]:
                self.user_profile["emotional_tendencies"].append(emotion)
        
        # 更新统计数据
        stats = self.user_profile["summary_stats"]
        for topic in conversation["topics"]:
            stats["most_discussed_topics"][topic] = stats["most_discussed_topics"].get(topic, 0) + 1
        
        for emotion in conversation["emotions"]:
            stats["dominant_emotions"][emotion] = stats["dominant_emotions"].get(emotion, 0) + 1
        
        # 计算平均重要性
        total_conversations = self.user_profile["interaction_summary"]["total_conversations"]
        if hasattr(self, 'total_importance'):
            self.total_importance += conversation["importance"]
        else:
            self.total_importance = conversation["importance"]
        
        self.user_profile["average_importance"] = self.total_importance / total_conversations
        
        # 更新关系阶段
        self._update_relationship_stage()
        
        # 更新交流风格
        self._update_communication_style(metadata)

    def _update_relationship_stage(self):
        """更新关系发展阶段"""
        total_conversations = self.user_profile["interaction_summary"]["total_conversations"]
        
        if total_conversations <= 3:
            self.user_profile["relationship_stage"] = "Initial contact"
        elif total_conversations <= 10:
            self.user_profile["relationship_stage"] = "Building trust"
        elif total_conversations <= 25:
            self.user_profile["relationship_stage"] = "Deep interaction"
        else:
            self.user_profile["relationship_stage"] = "Long-term companion"

    def _update_communication_style(self, metadata: Dict):
        """更新交流风格分析"""
        total_conversations = self.user_profile["interaction_summary"]["total_conversations"]
        
        # 分析信息分享倾向
        personal_info_count = sum(1 for conv in self.short_term_memories[-10:] 
                                if conv.get("importance", 0) > 0.6)
        
        if personal_info_count > total_conversations * 0.3:
            self.user_profile["communication_style"] = "Open and sharing"
            self.user_profile["information_sharing_tendency"] = "High"
        elif personal_info_count > 0:
            self.user_profile["communication_style"] = "Cautiously sharing"
            self.user_profile["information_sharing_tendency"] = "Medium"
        else:
            self.user_profile["communication_style"] = "Reserved communicator"
            self.user_profile["information_sharing_tendency"] = "Low"
        
        # 分析活跃程度
        if total_conversations > 20:
            self.user_profile["activity_level"] = "Highly active"
        elif total_conversations > 5:
            self.user_profile["activity_level"] = "Regular interaction"
        else:
            self.user_profile["activity_level"] = "Exploring phase"

    def _maintain_memory_limits(self):
        """维护记忆容量限制"""
        # 维护短期记忆大小
        if len(self.short_term_memories) > self.max_short_term:
            self.short_term_memories = self.short_term_memories[-self.max_short_term:]
        
        # 维护中期记忆大小
        if len(self.medium_term_memories) > self.max_medium_term:
            # 保留最重要的对话
            self.medium_term_memories.sort(key=lambda x: x["importance"], reverse=True)
            self.medium_term_memories = self.medium_term_memories[:self.max_medium_term]

    def get_user_profile(self) -> Dict:
        """获取结构化用户档案"""
        return self.user_profile.copy()

    def get_important_conversations(self) -> List[Dict]:
        """获取重要对话记录"""
        return self.medium_term_memories.copy()

    def search_memories(self, query: str, memory_types: List[str] = None) -> List[Dict]:
        """搜索相关记忆"""
        if memory_types is None:
            memory_types = ["short_term", "medium_term", "long_term"]
        
        results = []
        query_lower = query.lower()
        
        # 搜索短期记忆
        if "short_term" in memory_types:
            for memory in self.short_term_memories:
                if (query_lower in memory["user"].lower() or 
                    query_lower in memory["ai"].lower() or
                    any(query_lower in topic.lower() for topic in memory["topics"])):
                    results.append({"type": "short_term", "data": memory})
        
        # 搜索中期记忆
        if "medium_term" in memory_types:
            for memory in self.medium_term_memories:
                for conv in memory["conversation"]:
                    if (query_lower in conv["user"].lower() or 
                        query_lower in conv["ai"].lower() or
                        any(query_lower in topic.lower() for topic in memory["topics"])):
                        results.append({"type": "medium_term", "data": memory})
                        break
        
        # 搜索用户档案
        if "long_term" in memory_types:
            profile_text = json.dumps(self.user_profile, ensure_ascii=False).lower()
            if query_lower in profile_text:
                results.append({"type": "long_term", "data": self.user_profile})
        
        return results

    def save_all_memories(self):
        """保存所有记忆到文件"""
        try:
            # 保存短期记忆
            self._save_short_term_memories()
            
            # 保存中期记忆
            self._save_medium_term_memories()
            
            # 保存用户档案
            self._save_user_profile()
            
            print(f"💾 Memories saved for user: {self.user_id}")
            
        except Exception as e:
            print(f"⚠️ 保存记忆失败: {e}")

    def _save_short_term_memories(self):
        """保存短期记忆"""
        if not self.short_term_memories:
            return
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = os.path.join(self.storage_dir, "short_term", f"session_{timestamp}.json")
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(self.short_term_memories, f, ensure_ascii=False, indent=2)

    def _save_medium_term_memories(self):
        """保存中期记忆"""
        file_path = os.path.join(self.storage_dir, "medium_term", "important_memories.json")
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(self.medium_term_memories, f, ensure_ascii=False, indent=2)

    def _save_user_profile(self):
        """保存用户档案"""
        file_path = os.path.join(self.storage_dir, "long_term", "user_profile.json")
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(self.user_profile, f, ensure_ascii=False, indent=2)

    def create_backup(self):
        """创建记忆备份"""
        import shutil
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = os.path.join(self.storage_dir, f"backup_{timestamp}")
        
        # 复制整个存储目录
        shutil.copytree(self.storage_dir, backup_dir, ignore=shutil.ignore_patterns("backup_*"))
        
        print(f"📦 Backup created: {backup_dir}")
        return backup_dir

# 工厂函数
def create_enhanced_memory_system(**kwargs) -> EnhancedMemorySystem:
    """创建增强记忆系统实例 - Long Term Companion优化"""
    return EnhancedMemorySystem(**kwargs) 