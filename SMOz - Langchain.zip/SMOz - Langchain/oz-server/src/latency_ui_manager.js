/**
 * 延迟用户体验管理器
 * 通过视觉反馈和交互设计优化响应延迟的用户体验
 */

class LatencyUIManager {
    constructor() {
        this.isTyping = false;
        this.responseStartTime = null;
        this.estimatedWaitTime = 3000; // 3秒预估
        this.progressInterval = null;
        this.typingAnimationInterval = null;
        
        // 响应时间预测模型（基于历史数据）
        this.responseTimeHistory = [];
        this.complexityTimeMap = {
            'ultra_simple': 300,    // 0.3秒
            'simple': 800,          // 0.8秒  
            'medium': 2000,         // 2秒
            'complex': 4000         // 4秒
        };
        
        this.initializeStyles();
    }
    
    initializeStyles() {
        // 注入CSS样式
        const style = document.createElement('style');
        style.textContent = `
            .typing-indicator {
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                margin: 10px 0;
                padding: 15px;
                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                border-radius: 18px;
                border-left: 4px solid #4CAF50;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                animation: slideIn 0.3s ease-out;
            }
            
            .typing-animation {
                display: flex;
                align-items: center;
                font-size: 14px;
                color: #555;
                margin-bottom: 10px;
            }
            
            .typing-animation .lucy-avatar {
                width: 20px;
                height: 20px;
                border-radius: 50%;
                background: linear-gradient(45deg, #667eea 0%, #764ba2 100%);
                margin-right: 8px;
                animation: pulse 1.5s infinite;
            }
            
            .dots {
                margin-left: 5px;
            }
            
            .dots span {
                animation: blink 1.4s infinite both;
                font-weight: bold;
                color: #4CAF50;
            }
            
            .dots span:nth-child(2) { animation-delay: 0.2s; }
            .dots span:nth-child(3) { animation-delay: 0.4s; }
            .dots span:nth-child(4) { animation-delay: 0.6s; }
            
            .progress-container {
                width: 100%;
                background-color: #e0e0e0;
                border-radius: 10px;
                overflow: hidden;
                height: 6px;
                margin-bottom: 8px;
            }
            
            .progress-fill {
                height: 100%;
                background: linear-gradient(90deg, #4CAF50 0%, #45a049 50%, #4CAF50 100%);
                width: 0%;
                transition: width 0.3s ease;
                border-radius: 10px;
                position: relative;
                overflow: hidden;
            }
            
            .progress-fill::after {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                bottom: 0;
                right: 0;
                background-image: linear-gradient(
                    -45deg,
                    rgba(255, 255, 255, .2) 25%,
                    transparent 25%,
                    transparent 50%,
                    rgba(255, 255, 255, .2) 50%,
                    rgba(255, 255, 255, .2) 75%,
                    transparent 75%,
                    transparent
                );
                background-size: 50px 50px;
                animation: move 2s linear infinite;
            }
            
            .time-estimate {
                font-size: 11px;
                color: #777;
                display: flex;
                justify-content: space-between;
                width: 100%;
            }
            
            .quick-actions {
                display: flex;
                gap: 8px;
                margin-top: 15px;
                flex-wrap: wrap;
            }
            
            .quick-action-btn {
                padding: 6px 12px;
                border: none;
                border-radius: 20px;
                background: rgba(76, 175, 80, 0.1);
                color: #4CAF50;
                cursor: pointer;
                font-size: 12px;
                transition: all 0.2s ease;
                border: 1px solid rgba(76, 175, 80, 0.3);
            }
            
            .quick-action-btn:hover {
                background: rgba(76, 175, 80, 0.2);
                transform: translateY(-1px);
                box-shadow: 0 2px 8px rgba(76, 175, 80, 0.3);
            }
            
            .complexity-indicator {
                display: inline-block;
                padding: 2px 8px;
                border-radius: 12px;
                font-size: 10px;
                font-weight: bold;
                text-transform: uppercase;
                margin-left: 8px;
            }
            
            .complexity-ultra_simple { background: #e8f5e9; color: #2e7d32; }
            .complexity-simple { background: #e3f2fd; color: #1565c0; }
            .complexity-medium { background: #fff3e0; color: #ef6c00; }
            .complexity-complex { background: #fce4ec; color: #ad1457; }
            
            @keyframes slideIn {
                from { opacity: 0; transform: translateY(10px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            @keyframes blink {
                0%, 80%, 100% { opacity: 0; }
                40% { opacity: 1; }
            }
            
            @keyframes pulse {
                0% { transform: scale(1); }
                50% { transform: scale(1.1); }
                100% { transform: scale(1); }
            }
            
            @keyframes move {
                0% { background-position: 0 0; }
                100% { background-position: 50px 50px; }
            }
            
            .response-time-badge {
                position: absolute;
                top: 5px;
                right: 5px;
                background: rgba(0,0,0,0.7);
                color: white;
                padding: 2px 6px;
                border-radius: 10px;
                font-size: 10px;
                z-index: 1000;
            }
        `;
        document.head.appendChild(style);
    }
    
    showTypingIndicator(complexity = 'medium', customMessage = null) {
        if (this.isTyping) return; // 防止重复显示
        
        this.isTyping = true;
        this.responseStartTime = Date.now();
        
        // 根据复杂度调整预估时间
        this.estimatedWaitTime = this.complexityTimeMap[complexity] || 3000;
        
        const chatHistory = document.getElementById('chat-history');
        if (!chatHistory) return;
        
        // 创建打字指示器
        const typingDiv = document.createElement('div');
        typingDiv.id = 'typing-indicator';
        typingDiv.className = 'typing-indicator';
        
        const message = customMessage || this.getTypingMessage(complexity);
        
        typingDiv.innerHTML = `
            <div class="typing-animation">
                <div class="lucy-avatar"></div>
                <span>${message}</span>
                <span class="complexity-indicator complexity-${complexity}">${complexity}</span>
                <span class="dots">
                    <span>.</span><span>.</span><span>.</span>
                </span>
            </div>
            <div class="progress-container">
                <div class="progress-fill"></div>
            </div>
            <div class="time-estimate">
                <span>Expected: ${(this.estimatedWaitTime/1000).toFixed(1)}s</span>
                <span id="elapsed-time">0.0s</span>
            </div>
        `;
        
        chatHistory.appendChild(typingDiv);
        
        // 启动动画
        this.startProgressAnimation();
        this.startElapsedTimeCounter();
        
        // 显示快捷操作（延迟1秒后显示）
        setTimeout(() => {
            if (this.isTyping) {
                this.showQuickActions(typingDiv, complexity);
            }
        }, 1000);
        
        // 自动隐藏保护机制（10秒后强制隐藏）
        setTimeout(() => {
            if (this.isTyping) {
                this.hideTypingIndicator();
            }
        }, 10000);
    }
    
    getTypingMessage(complexity) {
        const messages = {
            'ultra_simple': 'Quick reply coming up',
            'simple': 'Lucy is responding',
            'medium': 'Lucy is thinking carefully',
            'complex': 'Lucy is processing your message deeply'
        };
        return messages[complexity] || 'Lucy is typing';
    }
    
    startProgressAnimation() {
        const progressFill = document.querySelector('#typing-indicator .progress-fill');
        if (!progressFill) return;
        
        const startTime = Date.now();
        
        const updateProgress = () => {
            if (!this.isTyping) return;
            
            const elapsed = Date.now() - startTime;
            let progress = elapsed / this.estimatedWaitTime;
            
            // 使用非线性进度（开始快，后面慢）
            progress = Math.min(this.easeOutQuart(progress), 0.95);
            
            progressFill.style.width = `${progress * 100}%`;
            
            if (progress < 0.95) {
                requestAnimationFrame(updateProgress);
            }
        };
        
        requestAnimationFrame(updateProgress);
    }
    
    startElapsedTimeCounter() {
        const elapsedElement = document.getElementById('elapsed-time');
        if (!elapsedElement) return;
        
        const updateTime = () => {
            if (!this.isTyping) return;
            
            const elapsed = (Date.now() - this.responseStartTime) / 1000;
            elapsedElement.textContent = `${elapsed.toFixed(1)}s`;
            
            setTimeout(updateTime, 100);
        };
        
        updateTime();
    }
    
    showQuickActions(parentElement, complexity) {
        // 根据复杂度显示不同的快捷操作
        const quickActionsData = {
            'ultra_simple': ['👍', '👎', '❓'],
            'simple': ['Tell me more', 'Thanks', 'Skip'],
            'medium': ['Continue', 'Explain', 'Change topic'],
            'complex': ['I need help', 'Give me time', 'Emergency support']
        };
        
        const actions = quickActionsData[complexity] || quickActionsData['simple'];
        
        const quickActionsDiv = document.createElement('div');
        quickActionsDiv.className = 'quick-actions';
        
        actions.forEach(action => {
            const btn = document.createElement('button');
            btn.className = 'quick-action-btn';
            btn.textContent = action;
            btn.onclick = () => this.handleQuickAction(action);
            quickActionsDiv.appendChild(btn);
        });
        
        parentElement.appendChild(quickActionsDiv);
    }
    
    handleQuickAction(action) {
        console.log(`Quick action: ${action}`);
        
        // 发送快捷操作到服务器
        if (typeof window.sendQuickAction === 'function') {
            window.sendQuickAction(action);
        }
        
        // 隐藏打字指示器
        this.hideTypingIndicator();
        
        // 显示用户选择的操作
        this.addQuickActionToChat(action);
    }
    
    addQuickActionToChat(action) {
        const chatHistory = document.getElementById('chat-history');
        if (!chatHistory) return;
        
        const actionDiv = document.createElement('div');
        actionDiv.style.cssText = `
            text-align: center;
            margin: 5px 0;
            padding: 5px;
            background: rgba(76, 175, 80, 0.1);
            border-radius: 10px;
            font-size: 12px;
            color: #666;
        `;
        actionDiv.textContent = `You chose: ${action}`;
        chatHistory.appendChild(actionDiv);
    }
    
    hideTypingIndicator() {
        this.isTyping = false;
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            // 添加淡出动画
            typingIndicator.style.transition = 'opacity 0.3s ease-out, transform 0.3s ease-out';
            typingIndicator.style.opacity = '0';
            typingIndicator.style.transform = 'translateY(-10px)';
            
            setTimeout(() => {
                if (typingIndicator.parentNode) {
                    typingIndicator.remove();
                }
            }, 300);
        }
    }
    
    updateEstimatedTime(newEstimate) {
        this.estimatedWaitTime = newEstimate;
        const estimateElement = document.querySelector('#typing-indicator .time-estimate span:first-child');
        if (estimateElement) {
            estimateElement.textContent = `Expected: ${(newEstimate/1000).toFixed(1)}s`;
        }
    }
    
    showResponseTimeBadge(responseTime, element) {
        const badge = document.createElement('div');
        badge.className = 'response-time-badge';
        badge.textContent = `${responseTime.toFixed(2)}s`;
        
        element.style.position = 'relative';
        element.appendChild(badge);
        
        // 3秒后自动隐藏
        setTimeout(() => {
            if (badge.parentNode) {
                badge.remove();
            }
        }, 3000);
    }
    
    // 辅助函数：缓动函数
    easeOutQuart(t) {
        return 1 - (--t) * t * t * t;
    }
    
    // 记录响应时间用于预测
    recordResponseTime(complexity, actualTime) {
        this.responseTimeHistory.push({
            complexity,
            time: actualTime,
            timestamp: Date.now()
        });
        
        // 保持最近50条记录
        if (this.responseTimeHistory.length > 50) {
            this.responseTimeHistory.shift();
        }
        
        // 更新预测模型
        this.updatePredictionModel();
    }
    
    updatePredictionModel() {
        // 根据历史数据更新时间预测
        const recentData = this.responseTimeHistory.slice(-20); // 最近20条
        
        for (let complexity in this.complexityTimeMap) {
            const complexityData = recentData.filter(d => d.complexity === complexity);
            if (complexityData.length > 3) {
                const avgTime = complexityData.reduce((sum, d) => sum + d.time, 0) / complexityData.length;
                // 使用加权平均更新预测时间
                this.complexityTimeMap[complexity] = Math.round(
                    this.complexityTimeMap[complexity] * 0.7 + avgTime * 1000 * 0.3
                );
            }
        }
    }
    
    // 获取性能统计
    getPerformanceStats() {
        if (this.responseTimeHistory.length === 0) {
            return { message: "No response time data yet" };
        }
        
        const times = this.responseTimeHistory.map(d => d.time);
        const avg = times.reduce((a, b) => a + b, 0) / times.length;
        
        return {
            totalResponses: this.responseTimeHistory.length,
            averageTime: `${avg.toFixed(2)}s`,
            fastestTime: `${Math.min(...times).toFixed(2)}s`,
            slowestTime: `${Math.max(...times).toFixed(2)}s`,
            predictionAccuracy: this.calculatePredictionAccuracy()
        };
    }
    
    calculatePredictionAccuracy() {
        // 计算预测准确度
        const recent = this.responseTimeHistory.slice(-10);
        if (recent.length < 3) return "Insufficient data";
        
        let totalError = 0;
        recent.forEach(record => {
            const predicted = this.complexityTimeMap[record.complexity] / 1000;
            const actual = record.time;
            totalError += Math.abs(predicted - actual) / actual;
        });
        
        const accuracy = 1 - (totalError / recent.length);
        return `${(accuracy * 100).toFixed(1)}%`;
    }
}

// 全局实例
window.latencyUIManager = new LatencyUIManager();

// WebSocket集成函数
window.sendQuickAction = function(action) {
    if (window.ws && window.ws.readyState === WebSocket.OPEN) {
        window.ws.send(JSON.stringify({
            kind: "quick_action",
            action: action,
            timestamp: Date.now()
        }));
    }
};

// 使用示例函数
window.demonstrateLatencyUI = function() {
    const manager = window.latencyUIManager;
    
    // 演示不同复杂度的响应
    const complexities = ['ultra_simple', 'simple', 'medium', 'complex'];
    let index = 0;
    
    const demo = () => {
        if (index < complexities.length) {
            const complexity = complexities[index];
            manager.showTypingIndicator(complexity, `Demonstrating ${complexity} response`);
            
            setTimeout(() => {
                manager.hideTypingIndicator();
                index++;
                if (index < complexities.length) {
                    setTimeout(demo, 1000);
                }
            }, manager.complexityTimeMap[complexity]);
        }
    };
    
    demo();
};

console.log("LatencyUIManager loaded. Try: window.demonstrateLatencyUI()"); 