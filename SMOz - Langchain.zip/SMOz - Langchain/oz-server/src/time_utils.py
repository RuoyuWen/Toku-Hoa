#!/usr/bin/env python3
"""
时间工具模块 - 提供一致的时间处理功能
解决跨时区、时间同步等问题
"""

import os
import pytz
from datetime import datetime, timezone
from typing import Dict, Optional
import requests
import json

class TimeManager:
    """
    时间管理器 - 提供统一的时间处理功能
    """
    
    def __init__(self, timezone_name: str = None):
        """
        初始化时间管理器
        
        Args:
            timezone_name: 时区名称，如 'Asia/Shanghai', 'America/New_York' 等
                          如果为None，会尝试自动检测
        """
        self.timezone_name = timezone_name or self._detect_timezone()
        self.timezone = pytz.timezone(self.timezone_name)
        print(f"🕒 时间管理器初始化: {self.timezone_name}")
    
    def _detect_timezone(self) -> str:
        """
        自动检测时区
        优先级: 环境变量 > 系统检测 > 默认UTC
        """
        # 1. 检查环境变量
        tz_env = os.getenv('TZ') or os.getenv('TIMEZONE')
        if tz_env:
            try:
                pytz.timezone(tz_env)  # 验证时区有效性
                return tz_env
            except:
                pass
        
        # 2. 尝试从系统获取时区
        try:
            # 尝试读取系统时区文件
            if os.path.exists('/etc/timezone'):
                with open('/etc/timezone', 'r') as f:
                    tz_name = f.read().strip()
                    if tz_name:
                        pytz.timezone(tz_name)  # 验证
                        return tz_name
        except:
            pass
        
        # 3. 尝试通过网络API获取时区（可选）
        try:
            response = requests.get('http://worldtimeapi.org/api/ip', timeout=2)
            if response.status_code == 200:
                data = response.json()
                return data.get('timezone', 'UTC')
        except:
            pass
        
        # 4. 默认使用UTC
        print("⚠️ 无法检测时区，使用UTC")
        return 'UTC'
    
    def now(self) -> datetime:
        """获取当前时间（带时区信息）"""
        return datetime.now(self.timezone)
    
    def utc_now(self) -> datetime:
        """获取UTC时间"""
        return datetime.now(timezone.utc)
    
    def get_time_info(self) -> Dict[str, str]:
        """
        获取完整的时间信息字典
        
        Returns:
            包含各种时间格式的字典
        """
        now = self.now()
        
        return {
            'timestamp': now.isoformat(),
            'readable_time': now.strftime('%Y-%m-%d %H:%M:%S'),
            'date': now.strftime('%Y-%m-%d'),
            'time': now.strftime('%H:%M:%S'),
            'weekday': now.strftime('%A'),
            'weekday_cn': self._get_weekday_cn(now.weekday()),
            'full_format': now.strftime('%Y-%m-%d %H:%M:%S %A'),
            'timezone': str(self.timezone),
            'timezone_name': self.timezone_name,
            'utc_offset': now.strftime('%z'),
            'is_dst': now.dst() != datetime.timedelta(0) if now.dst() else False
        }
    
    def _get_weekday_cn(self, weekday: int) -> str:
        """获取中文星期"""
        weekdays = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']
        return weekdays[weekday]
    
    def format_time_context(self) -> str:
        """
        格式化时间上下文，用于AI提示词
        """
        time_info = self.get_time_info()
        
        return f"""=== CURRENT TIME CONTEXT ===
Current Time: {time_info['full_format']}
Date: {time_info['date']} ({time_info['weekday']})
Time: {time_info['time']}
Timezone: {time_info['timezone_name']} (UTC{time_info['utc_offset']})
DST Active: {time_info['is_dst']}

IMPORTANT: This is the REAL current time. Any dates in memory are historical."""
    
    def get_system_prompt_time(self) -> str:
        """获取用于系统提示词的时间字符串"""
        time_info = self.get_time_info()
        return f"Current time: {time_info['full_format']} (Timezone: {time_info['timezone_name']})"
    
    def is_same_day(self, timestamp_str: str) -> bool:
        """
        检查给定时间戳是否是今天
        
        Args:
            timestamp_str: ISO格式的时间戳字符串
            
        Returns:
            是否是今天
        """
        try:
            # 解析时间戳
            if timestamp_str.endswith('Z'):
                dt = datetime.fromisoformat(timestamp_str[:-1]).replace(tzinfo=timezone.utc)
            else:
                dt = datetime.fromisoformat(timestamp_str)
            
            # 转换到本地时区
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            
            local_dt = dt.astimezone(self.timezone)
            today = self.now().date()
            
            return local_dt.date() == today
            
        except Exception as e:
            print(f"⚠️ 时间戳解析失败: {timestamp_str}, 错误: {e}")
            return False
    
    def get_time_diff_description(self, timestamp_str: str) -> str:
        """
        获取时间差描述
        
        Args:
            timestamp_str: ISO格式的时间戳字符串
            
        Returns:
            时间差描述，如 "2 days ago", "yesterday" 等
        """
        try:
            # 解析时间戳
            if timestamp_str.endswith('Z'):
                dt = datetime.fromisoformat(timestamp_str[:-1]).replace(tzinfo=timezone.utc)
            else:
                dt = datetime.fromisoformat(timestamp_str)
            
            # 转换到本地时区
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            
            local_dt = dt.astimezone(self.timezone)
            now = self.now()
            
            # 计算时间差
            diff = now - local_dt
            days = diff.days
            
            if days == 0:
                hours = diff.seconds // 3600
                if hours == 0:
                    minutes = diff.seconds // 60
                    if minutes == 0:
                        return "just now"
                    else:
                        return f"{minutes} minutes ago"
                else:
                    return f"{hours} hours ago"
            elif days == 1:
                return "yesterday"
            elif days < 7:
                return f"{days} days ago"
            elif days < 30:
                weeks = days // 7
                return f"{weeks} weeks ago"
            elif days < 365:
                months = days // 30
                return f"{months} months ago"
            else:
                years = days // 365
                return f"{years} years ago"
                
        except Exception as e:
            print(f"⚠️ 时间差计算失败: {timestamp_str}, 错误: {e}")
            return "unknown time"
    
    def sync_time_with_ntp(self) -> bool:
        """
        尝试与NTP服务器同步时间（仅在有权限时）
        
        Returns:
            是否同步成功
        """
        try:
            # 这个功能需要系统权限，在Docker中可能无法使用
            # 这里只是检查时间是否准确
            response = requests.get('http://worldtimeapi.org/api/ip', timeout=5)
            if response.status_code == 200:
                data = response.json()
                server_time = datetime.fromisoformat(data['datetime'].replace('Z', '+00:00'))
                local_time = self.utc_now()
                
                diff = abs((server_time - local_time).total_seconds())
                if diff > 60:  # 如果差异超过1分钟
                    print(f"⚠️ 时间可能不准确，差异: {diff:.1f}秒")
                    return False
                else:
                    print(f"✅ 时间同步正常，差异: {diff:.1f}秒")
                    return True
            
        except Exception as e:
            print(f"⚠️ 时间同步检查失败: {e}")
            return False
        
        return True

# 全局时间管理器实例
_time_manager = None

def get_time_manager(timezone_name: str = None) -> TimeManager:
    """
    获取全局时间管理器实例
    
    Args:
        timezone_name: 时区名称，仅在首次调用时有效
        
    Returns:
        TimeManager实例
    """
    global _time_manager
    if _time_manager is None:
        _time_manager = TimeManager(timezone_name)
    return _time_manager

def get_current_time_info() -> Dict[str, str]:
    """快捷函数：获取当前时间信息"""
    return get_time_manager().get_time_info()

def get_time_context_for_ai() -> str:
    """快捷函数：获取AI用的时间上下文"""
    return get_time_manager().format_time_context()

def get_system_prompt_time() -> str:
    """快捷函数：获取系统提示词用的时间"""
    return get_time_manager().get_system_prompt_time()

# 环境变量配置
def setup_timezone_from_env():
    """从环境变量设置时区"""
    timezone_name = os.getenv('APP_TIMEZONE') or os.getenv('TZ')
    if timezone_name:
        global _time_manager
        _time_manager = TimeManager(timezone_name)
        print(f"🌍 从环境变量设置时区: {timezone_name}")

# 自动初始化
setup_timezone_from_env() 