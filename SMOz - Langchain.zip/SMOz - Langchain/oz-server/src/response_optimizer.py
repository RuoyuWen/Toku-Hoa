"""
响应延迟优化器 - 智能分级系统 (优化版本)
用于优化Long Term Companion的响应速度和用户体验
"""

import asyncio
import time
import re
from typing import Dict, List, Tuple, Optional
from openai import AsyncOpenAI  # 使用异步客户端
from datetime import datetime
import hashlib

class ResponseOptimizer:
    """
    智能响应分级系统 (优化版本)
    
    分级策略：
    1. 超简单 (0.3s): 打招呼、确认词 → 预设回复
    2. 简单 (0.8s): 日常对话 → 快速LLM + 基础记忆
    3. 中等 (2s): 个人分享 → 并行处理（快速+完整）
    4. 复杂 (3-5s): 深度心理需求 → 完整记忆+心理分析
    """
    
    def __init__(self):
        self.client_fast = AsyncOpenAI()  # 异步客户端
        self.response_times = []  # 响应时间统计
        self.classification_cache = {}  # 分类缓存
        
        # 预设快速回复库 (扩展)
        self.quick_replies = {
            # 超简单回复 (即时响应)
            "greetings": {
                "patterns": ["hi", "hello", "hey"],
                "responses": [
                    "Hey there! How's your day going?",
                    "Hi! Great to see you again!",
                    "Hello! What's on your mind today?"
                ]
            },
            "morning_greetings": {
                "patterns": ["good morning", "morning"],
                "responses": [
                    "Good morning! Hope you're having a great start to your day!",
                    "Morning! What's on your agenda today?",
                    "Good morning! How did you sleep?"
                ]
            },
            "thanks": {
                "patterns": ["thank", "thanks", "thx"],
                "responses": [
                    "You're welcome! Happy to help!",
                    "Of course! Glad I could help.",
                    "Anytime! That's what I'm here for."
                ]
            },
            "simple_affirmation": {
                "patterns": ["yes", "yeah", "ok", "sure"],
                "responses": [
                    "Awesome! I'm here to listen.",
                    "Great! What would you like to talk about?",
                    "Perfect! Let's continue."
                ]
            },
            "simple_negation": {
                "patterns": ["no", "nah", "not really"],
                "responses": [
                    "That's okay! What else is on your mind?",
                    "No worries! Is there something else you'd like to discuss?",
                    "I understand. What would you like to talk about instead?"
                ]
            },
            "goodbye": {
                "patterns": ["bye", "goodbye", "see you", "gotta go"],
                "responses": [
                    "Take care! I'll be here when you're ready to chat.",
                    "See you later! Hope you have a great day!",
                    "Goodbye! Looking forward to our next conversation."
                ]
            }
        }
        
        # 优化的复杂度分类规则
        self.complexity_rules = {
            "ultra_simple": {
                "max_words": 3,
                "exact_patterns": ["hi", "bye", "ok", "yes", "no", "thanks", "hello", "hey"],
                "response_time_target": 0.3
            },
            "simple": {
                "max_words": 15,
                "casual_patterns": ["how are you", "what's up", "how's it going", "good morning", "that's nice"],
                "simple_states": ["i'm good", "i'm fine", "i'm okay", "not bad"],
                "response_time_target": 0.8
            },
            "medium": {
                "min_words": 6,
                "max_words": 50,
                "personal_indicators": ["i feel", "i think", "i believe", "i wonder", "my opinion"],
                "question_patterns": ["what do you think", "how can i", "why do", "what's your opinion"],
                "topic_keywords": ["work", "relationship", "friend", "life", "future", "decision", "career", "friendship"],
                "response_time_target": 2.0
            },
            "complex": {
                "min_words": 10,
                "emotional_intensity": [
                    "really depressed", "very anxious", "extremely worried", "completely overwhelmed",
                    "deeply confused", "totally lost", "devastated", "heartbroken", "terrified"
                ],
                "psychological_keywords": [
                    "depression", "anxiety", "panic", "trauma", "ptsd", "suicidal", "self-harm",
                    "therapy", "counseling", "medication", "mental health"
                ],
                "complex_relationships": [
                    "complicated relationship", "family issues", "relationship problems",
                    "marriage troubles", "divorce", "breakup", "abuse", "toxic"
                ],
                "life_struggles": [
                    "life crisis", "existential", "meaning of life", "identity crisis",
                    "career change", "financial stress", "unemployment", "homeless"
                ],
                "intensity_words": ["completely", "totally", "extremely", "overwhelming", "constant pressure"],
                "response_time_target": 5.0
            }
        }
    
    async def get_optimized_response(self, user_input: str, memory_system) -> Dict:
        """
        主入口：获取优化的响应
        
        返回：{
            "response": str,
            "response_time": float,
            "strategy_used": str,
            "confidence": float
        }
        """
        start_time = time.time()
        
        # 1. 快速分类用户输入
        complexity = self.classify_input_complexity(user_input)
        
        # 2. 根据复杂度选择策略
        if complexity == "ultra_simple":
            result = await self.ultra_simple_response(user_input)
            strategy = "ultra_simple"
            
        elif complexity == "simple":
            result = await self.simple_response(user_input, memory_system)
            strategy = "simple"
            
        elif complexity == "medium":
            result = await self.medium_response_parallel(user_input, memory_system)
            strategy = "medium_parallel"
            
        else:  # complex
            result = await self.complex_response_full(user_input, memory_system)
            strategy = "complex_full"
        
        # 3. 记录性能数据
        response_time = time.time() - start_time
        self.response_times.append(response_time)
        
        return {
            "response": result,
            "response_time": response_time,
            "strategy_used": strategy,
            "complexity": complexity,
            "confidence": self.calculate_confidence(complexity, response_time)
        }
    
    def classify_input_complexity(self, text: str) -> str:
        """
        优化的智能分类算法 (修复版本)
        
        改进点：
        1. 修复Medium和Complex识别问题
        2. 更敏感的关键词检测
        3. 更好的上下文理解
        """
        text_lower = text.lower().strip()
        word_count = len(text.split())
        
        # 缓存检查
        text_hash = hashlib.md5(text_lower.encode()).hexdigest()[:8]
        if text_hash in self.classification_cache:
            return self.classification_cache[text_hash]
        
        # 1. 超简单判断 (严格)
        if word_count <= 3:
            ultra_patterns = self.complexity_rules["ultra_simple"]["exact_patterns"]
            for pattern in ultra_patterns:
                if text_lower == pattern or text_lower.startswith(pattern + " "):
                    self.classification_cache[text_hash] = "ultra_simple"
                    return "ultra_simple"
        
        # 2. 复杂判断 (优先检查，降低阈值)
        if word_count >= 8:  # 进一步降低最小词数要求
            complexity_score = 0
            
            # 检查情绪强度词汇
            emotional_intensity = self.complexity_rules["complex"]["emotional_intensity"]
            for phrase in emotional_intensity:
                if phrase in text_lower:
                    complexity_score += 3
            
            # 检查心理健康关键词
            psychological_keywords = self.complexity_rules["complex"]["psychological_keywords"]
            for keyword in psychological_keywords:
                if keyword in text_lower:
                    complexity_score += 2
            
            # 检查复杂关系问题
            complex_relationships = self.complexity_rules["complex"]["complex_relationships"]
            for phrase in complex_relationships:
                if phrase in text_lower:
                    complexity_score += 2
            
            # 检查生活困境
            life_struggles = self.complexity_rules["complex"]["life_struggles"]
            for phrase in life_struggles:
                if phrase in text_lower:
                    complexity_score += 2
            
            # 检查单个强烈情绪词汇
            strong_emotions = ["depressed", "overwhelmed", "devastated", "anxious", "suicidal", "crisis", "therapy", "trauma"]
            for emotion in strong_emotions:
                if emotion in text_lower:
                    complexity_score += 1
            
            # 检查强度词汇 (增加检测)
            intensity_words = self.complexity_rules["complex"]["intensity_words"]
            for word in intensity_words:
                if word in text_lower:
                    complexity_score += 1
            
            # 特殊复杂模式检测
            complex_patterns = [
                "completely overwhelmed", "totally lost", "extremely", 
                "feelings of", "inadequacy", "questioning everything"
            ]
            for pattern in complex_patterns:
                if pattern in text_lower:
                    complexity_score += 2
            
            # 复杂度阈值 (降低到1)
            if complexity_score >= 1:
                self.classification_cache[text_hash] = "complex"
                return "complex"
        
        # 3. 中等复杂度判断 (优先于简单，收紧条件但降低阈值)
        if 4 <= word_count <= 50:  # 进一步降低最小词数
            medium_score = 0
            
            # 🔥 记忆相关问题检测 - 优先级最高
            memory_patterns = [
                "do you remember", "remember my", "my name", "what's my", 
                "favorite", "what do you know about me", "recall", "what did i"
            ]
            for pattern in memory_patterns:
                if pattern in text_lower:
                    medium_score += 2  # 高权重，确保被识别为medium
            
            # 个人表达指标
            personal_indicators = self.complexity_rules["medium"]["personal_indicators"]
            for indicator in personal_indicators:
                if indicator in text_lower:
                    medium_score += 1
            
            # 问题模式
            question_patterns = self.complexity_rules["medium"]["question_patterns"]
            for pattern in question_patterns:
                if pattern in text_lower:
                    medium_score += 1
            
            # 额外问题指标 - 针对特定模式
            additional_question_patterns = ["what's your opinion", "i wonder", "what about"]
            for pattern in additional_question_patterns:
                if pattern in text_lower:
                    medium_score += 1
            
            # 话题关键词
            topic_keywords = self.complexity_rules["medium"]["topic_keywords"]
            for keyword in topic_keywords:
                if keyword in text_lower:
                    medium_score += 0.5
            
            # 额外的中等复杂度指标
            medium_indicators = ["stressed", "worried", "concerned", "opinion", "advice", "improve", "change", "better"]
            for indicator in medium_indicators:
                if indicator in text_lower:
                    medium_score += 0.5
            
            # 检查"关于"模式 - 表示询问观点
            about_patterns = ["about", "regarding", "concerning"]
            for pattern in about_patterns:
                if pattern in text_lower:
                    medium_score += 0.5
            
            # 检查未来时态 - 表示计划和思考
            future_indicators = ["will", "going to", "planning", "considering"]
            for indicator in future_indicators:
                if indicator in text_lower:
                    medium_score += 0.5
            
            # 中等复杂度需要至少0.8分 (进一步降低阈值)
            if medium_score >= 0.8:
                self.classification_cache[text_hash] = "medium"
                return "medium"
        
        # 4. 简单判断 (精确匹配)
        if word_count <= 15:
            simple_patterns = self.complexity_rules["simple"]["casual_patterns"]
            simple_states = self.complexity_rules["simple"]["simple_states"]
            
            for pattern in simple_patterns:
                if pattern in text_lower:
                    self.classification_cache[text_hash] = "simple"
                    return "simple"
            
            for state in simple_states:
                if state in text_lower:
                    self.classification_cache[text_hash] = "simple"
                    return "simple"
        
        # 5. 默认根据词数判断
        if word_count <= 5:
            self.classification_cache[text_hash] = "simple"
            return "simple"
        elif word_count >= 15:
            # 长文本默认为中等复杂度
            self.classification_cache[text_hash] = "medium"
            return "medium"
        else:
            self.classification_cache[text_hash] = "simple"
            return "simple"
    
    async def ultra_simple_response(self, user_input: str) -> str:
        """超简单响应 - 即时预设回复"""
        text_lower = user_input.lower().strip()
        
        for category, data in self.quick_replies.items():
            for pattern in data["patterns"]:
                if pattern in text_lower:
                    import random
                    return random.choice(data["responses"])
        
        # 兜底回复
        return "I hear you! What else would you like to talk about?"
    
    async def simple_response(self, user_input: str, memory_system) -> str:
        """简单响应 - 快速LLM无记忆检索"""
        
        # 获取基本用户信息（如果有）
        user_name = self.get_user_name_quick(memory_system)
        name_context = f" Remember, the user's name is {user_name}." if user_name else ""
        
        simple_prompt = f"""You are Lucy, a friendly AI companion. 
        
Respond naturally and concisely (20-40 words).{name_context}

User: {user_input}
Lucy:"""
        
        try:
            response = await self.client_fast.chat.completions.create(
                model="gpt-3.5-turbo",  # 使用快速模型
                messages=[
                    {"role": "user", "content": simple_prompt}
                ],
                max_tokens=60,
                temperature=0.7,
                timeout=1.5  # 1.5秒超时
            )
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            print(f"快速响应失败: {e}")
            return "I'm here to listen! Tell me more."
    
    async def medium_response_parallel(self, user_input: str, memory_system) -> str:
        """中等复杂度 - 并行处理（修复异步问题）"""
        
        try:
            # 创建任务而不是协程
            task1 = asyncio.create_task(self.simple_response(user_input, memory_system))
            task2 = asyncio.create_task(self.get_memory_enhanced_response(user_input, memory_system))
            
            # 等待任何一个完成，最多等待2秒
            done, pending = await asyncio.wait(
                [task1, task2], 
                timeout=2.0,
                return_when=asyncio.FIRST_COMPLETED
            )
            
            if done:
                # 获取第一个完成的结果
                result = await list(done)[0]
                
                # 取消剩余任务
                for task in pending:
                    task.cancel()
                
                return result
            else:
                # 超时，取消所有任务
                task1.cancel()
                task2.cancel()
                return "That's interesting! Let me think about that for a moment..."
                
        except Exception as e:
            print(f"并行处理失败: {e}")
            return "I'm processing that... Can you tell me a bit more?"
    
    async def complex_response_full(self, user_input: str, memory_system) -> str:
        """复杂响应 - 完整记忆和心理分析"""
        
        # 对于复杂输入，直接使用记忆系统的完整处理能力
        try:
            # 注意：这里不调用 process_message 避免递归
            # 而是直接使用记忆增强响应但给更多时间
            return await asyncio.wait_for(
                self.get_memory_enhanced_response(user_input, memory_system),
                timeout=5.0
            )
                
        except asyncio.TimeoutError:
            return "That's a very deep question. I'm still processing it... Could you tell me more about how you're feeling about this?"
        except Exception as e:
            print(f"复杂响应失败: {e}")
            # 兜底到简单响应
            return await self.simple_response(user_input, memory_system)
    
    async def get_memory_enhanced_response(self, user_input: str, memory_system) -> str:
        """记忆增强响应 - 中等复杂度的完整版本"""
        
        try:
            # 获取相关记忆上下文
            if hasattr(memory_system, 'get_contextual_memory'):
                memory_context = memory_system.get_contextual_memory(user_input)
            else:
                memory_context = "No previous context available."
            
            # 构建增强提示词
            enhanced_prompt = f"""You are Lucy, a psychologically aware AI companion.

Relevant memory context: {memory_context[:200]}...

Respond naturally as Lucy, showing understanding and empathy. Keep response 30-60 words.

User: {user_input}
Lucy:"""
            
            response = await self.client_fast.chat.completions.create(
                model="gpt-3.5-turbo",  # 使用标准模型
                messages=[
                    {"role": "user", "content": enhanced_prompt}
                ],
                max_tokens=100,
                temperature=0.7,
                timeout=3.0
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            print(f"记忆增强响应失败: {e}")
            return await self.simple_response(user_input, memory_system)
    
    def get_user_name_quick(self, memory_system) -> Optional[str]:
        """快速获取用户名字（不进行复杂检索）"""
        try:
            if hasattr(memory_system, 'conversation_metadata'):
                prefs = memory_system.conversation_metadata.get("user_preferences", {})
                for pref_text in prefs.values():
                    if "name" in pref_text.lower() or "名字" in pref_text:
                        # 简单提取名字
                        words = pref_text.split()
                        for i, word in enumerate(words):
                            if word.lower() in ["name", "called", "名字", "叫"]:
                                if i + 1 < len(words):
                                    return words[i + 1].rstrip("，。,.")
            return None
        except:
            return None
    
    def calculate_confidence(self, complexity: str, response_time: float) -> float:
        """计算响应置信度"""
        target_time = self.complexity_rules[complexity]["response_time_target"]
        
        if response_time <= target_time:
            return 1.0  # 完美
        elif response_time <= target_time * 1.5:
            return 0.8  # 良好
        elif response_time <= target_time * 2:
            return 0.6  # 一般
        else:
            return 0.4  # 较差
    
    def get_performance_stats(self) -> Dict:
        """获取性能统计"""
        if not self.response_times:
            return {"message": "No data yet"}
        
        avg_time = sum(self.response_times) / len(self.response_times)
        recent_times = self.response_times[-10:]  # 最近10次
        recent_avg = sum(recent_times) / len(recent_times)
        
        return {
            "total_responses": len(self.response_times),
            "average_response_time": round(avg_time, 2),
            "recent_average": round(recent_avg, 2),
            "best_time": round(min(self.response_times), 2),
            "worst_time": round(max(self.response_times), 2),
            "cache_hit_rate": len(self.classification_cache) / max(len(self.response_times), 1)
        } 