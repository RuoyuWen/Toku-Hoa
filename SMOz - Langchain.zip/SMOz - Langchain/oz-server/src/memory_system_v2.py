"""
SMOz Memory System V2.0
基于标准化三层记忆架构的全新记忆系统
符合理想设计：LTM只存储结构化用户档案，不包含对话内容
"""

import os
import json
import uuid
from datetime import datetime
from typing import List, Dict, Optional
from collections import Counter
from pathlib import Path
import re


class SMOzMemorySystem:
    """
    SMOz标准化三层记忆系统
    
    Memory Layers:
    - Short-Term Memory (STM): 存储最近的对话轮次 (5-10轮)
    - Medium-Term Memory (MTM): 存储重要的完整对话
    - Long-Term Memory (LTM): 存储结构化用户档案 (无对话内容)
    """
    
    def __init__(self, user_id: str = "default_user", max_stm: int = 10, max_mtm: int = 50):
        self.user_id = user_id
        self.session_id = str(uuid.uuid4())
        self.max_stm = max_stm
        self.max_mtm = max_mtm
        
        # 设置存储目录
        self.storage_dir = self._get_user_storage_dir()
        print(f"🗂️ 用户记忆存储目录: {self.storage_dir}")
        self._ensure_directory_structure()
        
        # 初始化记忆存储
        self.short_term_memories = []  # STM: 最近对话轮次
        self.medium_term_memories = []  # MTM: 重要完整对话
        self.user_profile = self._load_user_profile()  # LTM: 结构化档案
        
        # 加载现有记忆
        self._load_existing_memories()
        
        print(f"✅ SMOz Memory System V2.0 initialized for user: {self.user_id}")
        print(f"📊 STM: {len(self.short_term_memories)}, MTM: {len(self.medium_term_memories)}")
    
    def _get_user_storage_dir(self) -> str:
        """获取用户存储目录"""
        # 🔥 修复路径计算 - 检查是否在Docker容器内
        current_file = Path(__file__).resolve()
        
        # 如果在Docker容器内（/code/src/），直接使用固定路径
        if str(current_file).startswith('/code/'):
            base_dir = Path("/code/data/memory")
        else:
            # 在开发环境中，使用相对路径
            base_dir = current_file.parent.parent.parent / "sm-docker-local" / "data" / "memory"
        
        user_dir = base_dir / self.user_id
        return str(user_dir)
    
    def _ensure_directory_structure(self):
        """确保目录结构存在"""
        for subdir in ["short_term", "medium_term", "long_term", "metadata"]:
            dir_path = Path(self.storage_dir) / subdir
            dir_path.mkdir(parents=True, exist_ok=True)
    
    def _load_user_profile(self) -> Dict:
        """加载或初始化用户档案 (LTM)"""
        profile_file = Path(self.storage_dir) / "long_term" / "user_profile.json"
        
        print(f"🔍 尝试加载用户档案: {profile_file}")
        print(f"📂 文件是否存在: {profile_file.exists()}")
        
        if profile_file.exists():
            try:
                with open(profile_file, 'r', encoding='utf-8') as f:
                    profile_data = json.load(f)
                    print(f"✅ 成功加载用户档案，包含 {len(profile_data)} 个字段")
                    
                    # 检查是否有个人详细信息
                    personal_details = profile_data.get("personal_details", {})
                    if personal_details:
                        print(f"👤 发现个人信息: {personal_details}")
                    
                    return profile_data
            except Exception as e:
                print(f"⚠️ 加载用户档案失败: {e}")
        
        print("🆕 创建新的用户档案")
        # 初始化新用户档案
        return {
            "user_id": self.user_id,
            "companion_start_date": datetime.now().strftime("%Y-%m-%d"),
            "topics_of_interest": [],
            "emotional_tendencies": [],
            "communication_style": "Unknown",
            "relationship_stage": "Initial contact",
            "activity_level": "Unknown",
            "information_sharing_tendency": "Unknown",
            "average_importance": 0.0,
            "interaction_summary": {
                "total_conversations": 0,
                "last_interaction": None
            },
            "preferences": {},
            "behavior_traits": [],
            "summary_stats": {
                "most_discussed_topics": {},
                "dominant_emotions": {},
                "relationship_duration_days": 0
            }
        }
    
    def _load_existing_memories(self):
        """加载现有记忆"""
        # 加载短期记忆
        self._load_short_term_memories()
        
        # 加载中期记忆
        self._load_medium_term_memories()
    
    def _load_short_term_memories(self):
        """加载短期记忆"""
        short_term_dir = Path(self.storage_dir) / "short_term"
        print(f"🔍 查找短期记忆目录: {short_term_dir}")
        
        if not short_term_dir.exists():
            print("📂 短期记忆目录不存在")
            return
        
        # 获取最新的会话文件
        session_files = list(short_term_dir.glob("session_*.json"))
        print(f"📄 发现 {len(session_files)} 个会话文件")
        
        if not session_files:
            print("📄 没有找到会话文件")
            return
        
        # 加载最新的会话文件
        latest_file = max(session_files, key=lambda x: x.stat().st_mtime)
        print(f"📥 加载最新会话文件: {latest_file}")
        
        try:
            with open(latest_file, 'r', encoding='utf-8') as f:
                memories = json.load(f)
                # 只保留最近的对话轮次
                self.short_term_memories = memories[-self.max_stm:]
                print(f"✅ 加载了 {len(self.short_term_memories)} 条短期记忆")
        except Exception as e:
            print(f"⚠️ 加载短期记忆失败: {e}")
    
    def _load_medium_term_memories(self):
        """加载中期记忆"""
        medium_file = Path(self.storage_dir) / "medium_term" / "important_memories.json"
        print(f"🔍 查找中期记忆文件: {medium_file}")
        print(f"📂 文件是否存在: {medium_file.exists()}")
        
        if medium_file.exists():
            try:
                with open(medium_file, 'r', encoding='utf-8') as f:
                    self.medium_term_memories = json.load(f)
                    print(f"✅ 加载了 {len(self.medium_term_memories)} 条中期记忆")
            except Exception as e:
                print(f"⚠️ 加载中期记忆失败: {e}")
        else:
            print("📄 中期记忆文件不存在")
    
    def add_conversation(self, user_message: str, ai_response: str):
        """添加对话到记忆系统 - 增强个人信息提取"""
        
        # 提取元数据和个人信息
        metadata = self._extract_conversation_metadata(user_message, ai_response)
        importance = self._calculate_importance_score(user_message, metadata)
        
        # 创建对话记录
        conversation = {
            "timestamp": datetime.now().isoformat(),
            "user": user_message,
            "ai": ai_response,
            "topics": metadata.get("topics", ["General"]),
            "emotions": metadata.get("emotions", ["Neutral"]),
            "importance": importance
        }
        
        # 保存到短期记忆
        self.short_term_memories.append(conversation)
        
        # 如果重要，保存到中期记忆
        if importance > 0.6:
            self._add_to_medium_term(conversation, metadata)
        
        # 更新用户档案（包含个人信息）
        self._update_user_profile(conversation, metadata)
        
        # 维护记忆限制
        self._maintain_memory_limits()
        
        print(f"💾 对话已添加到记忆系统 (重要性: {importance:.2f})")
    
    def _extract_conversation_metadata(self, user_message: str, ai_response: str) -> Dict:
        """提取对话元数据和个人信息 - 增强时间处理"""
        content = (user_message + " " + ai_response).lower()
        user_msg_lower = user_message.lower()
        
        # 🔥 导入智能时间解析器
        try:
            import sys
            import os
            current_dir = os.path.dirname(__file__)
            sys.path.insert(0, current_dir)
            
            from time_parser import parse_time_expression, extract_all_times
            print("✅ 智能时间解析器导入成功")
        except ImportError as e:
            print(f"⚠️ 智能时间解析器导入失败: {e}")
            # 如果导入失败，使用基础解析
            def parse_time_expression(text, context_type="general"):
                return {
                    "parsed_date": self._parse_relative_date(text),
                    "confidence": 0.7,
                    "is_relative": True
                }
            extract_all_times = lambda x: []
        
        # 基础话题和情感检测
        topic_keywords = {
            "greeting": ["hi", "hello", "how are", "good morning"],
            "personal_info": ["name", "birthday", "age", "birth", "born"],
            "work": ["work", "job", "career", "office"],
            "family": ["family", "parent", "child"],
            "emotions": ["feel", "happy", "sad", "stressed"],
            "events": ["meeting", "appointment", "date", "event", "schedule"],
            "plans": ["plan", "will", "going to", "tomorrow", "next week"],
            "preferences": ["favorite", "like", "love", "prefer", "enjoy", "hate", "dislike"],
            "entertainment": ["movie", "film", "book", "music", "song", "game", "show", "series"]
        }
        
        detected_topics = []
        for topic, keywords in topic_keywords.items():
            if any(keyword in content for keyword in keywords):
                detected_topics.append(topic.title())
        
        emotion_keywords = {
            "positive": ["happy", "excited", "great", "good", "love"],
            "negative": ["sad", "angry", "stressed", "worried"],
            "neutral": ["okay", "fine", "normal"]
        }
        
        detected_emotions = []
        for emotion, keywords in emotion_keywords.items():
            if any(keyword in content for keyword in keywords):
                detected_emotions.append(emotion.title())
        
        # 🔥 智能个人信息和时间提取
        personal_info = {}
        time_info = {}
        preferences_info = {}  # 🔥 新增：偏好信息
        
        # 提取名字
        name_patterns = [
            r"my name is\s+(\w+)",
            r"i'm\s+(\w+)",
            r"call me\s+(\w+)",
            r"i am\s+(\w+)"
        ]
        
        for pattern in name_patterns:
            match = re.search(pattern, user_msg_lower)
            if match:
                personal_info["name"] = match.group(1).title()
                break
        
        # 🔥 增强偏好信息提取
        preference_patterns = [
            # 最喜欢的电影/书籍/音乐等
            (r"my favorite\s+(\w+)\s+is\s+(.+?)(?:\.|$|,)", "favorite"),
            (r"favorite\s+(\w+)\s+is\s+(.+?)(?:\.|$|,)", "favorite"),
            (r"i love\s+(.+?)(?:\.|$|,)", "love"),
            (r"i like\s+(.+?)(?:\.|$|,)", "like"),
            (r"i enjoy\s+(.+?)(?:\.|$|,)", "enjoy"),
            (r"i prefer\s+(.+?)(?:\.|$|,)", "prefer"),
            (r"i hate\s+(.+?)(?:\.|$|,)", "hate"),
            (r"i dislike\s+(.+?)(?:\.|$|,)", "dislike"),
        ]
        
        for pattern, preference_type in preference_patterns:
            matches = re.finditer(pattern, user_msg_lower)
            for match in matches:
                if preference_type == "favorite" and len(match.groups()) >= 2:
                    # 最喜欢的X是Y
                    category = match.group(1).strip()
                    item = match.group(2).strip()
                    preferences_info[f"favorite_{category}"] = item
                    print(f"💡 提取偏好信息: 最喜欢的{category} = {item}")
                else:
                    # 我喜欢/讨厌X
                    item = match.group(1).strip()
                    if preference_type not in preferences_info:
                        preferences_info[preference_type] = []
                    preferences_info[preference_type].append(item)
                    print(f"💡 提取偏好信息: {preference_type} = {item}")
        
        # 🔥 智能时间信息提取 - 处理各种时间相关信息
        time_patterns = [
            (r"my birthday is\s+(.+?)(?:\.|$)", "birthday"),
            (r"born on\s+(.+?)(?:\.|$)", "birthday"),
            (r"birthday\s+(.+?)(?:\.|$)", "birthday"),
            (r"meeting.{0,20}?(\w+day|\d+月\d+日|\d{4}-\d{1,2}-\d{1,2})", "meeting"),
            (r"appointment.{0,20}?(\w+day|\d+月\d+日|\d{4}-\d{1,2}-\d{1,2})", "appointment"),
            (r"going to.{0,30}?(\w+day|\d+月\d+日|\d{4}-\d{1,2}-\d{1,2})", "plan"),
            (r"will.{0,30}?(\w+day|\d+月\d+日|\d{4}-\d{1,2}-\d{1,2})", "plan"),
        ]
        
        for pattern, info_type in time_patterns:
            match = re.search(pattern, user_msg_lower)
            if match:
                time_text = match.group(1).strip()
                try:
                    # 使用智能时间解析器
                    if callable(parse_time_expression):
                        parsed_time = parse_time_expression(time_text, info_type)
                        if parsed_time.get("confidence", 0) > 0.5:
                            if info_type == "birthday":
                                personal_info["birthday"] = parsed_time["parsed_date"]
                            else:
                                time_info[info_type] = {
                                    "original": time_text,
                                    "parsed_date": parsed_time["parsed_date"],
                                    "confidence": parsed_time["confidence"]
                                }
                    else:
                        # 回退到基础解析
                        parsed_date = self._parse_relative_date(time_text)
                        if info_type == "birthday":
                            personal_info["birthday"] = parsed_date
                        else:
                            time_info[info_type] = {"parsed_date": parsed_date}
                except Exception as e:
                    print(f"⚠️ 时间解析失败: {e}")
                    continue
        
        # 🔥 提取文本中的所有时间表达式
        try:
            all_times = extract_all_times(user_message)
            if all_times:
                time_info["detected_times"] = all_times
        except Exception as e:
            pass
        
        return {
            "topics": detected_topics if detected_topics else ["General"],
            "emotions": detected_emotions if detected_emotions else ["Neutral"],
            "personal_info": personal_info,
            "time_info": time_info,  # 🔥 新增：时间信息
            "has_personal_info": bool(personal_info),
            "has_time_info": bool(time_info),  # 🔥 新增：是否包含时间信息
            "preferences": preferences_info  # 🔥 新增：偏好信息
        }
    
    def _parse_relative_date(self, date_text: str) -> str:
        """解析相对时间描述，转换为具体日期"""
        from datetime import datetime, timedelta
        
        now = datetime.now()
        date_text = date_text.lower().strip()
        
        # 处理相对时间描述
        if date_text in ["yesterday", "昨天"]:
            target_date = now - timedelta(days=1)
            return target_date.strftime("%Y-%m-%d")
        elif date_text in ["today", "今天"]:
            return now.strftime("%Y-%m-%d")
        elif date_text in ["tomorrow", "明天"]:
            target_date = now + timedelta(days=1)
            return target_date.strftime("%Y-%m-%d")
        elif "days ago" in date_text or "天前" in date_text:
            # 提取数字
            import re
            match = re.search(r"(\d+)", date_text)
            if match:
                days = int(match.group(1))
                target_date = now - timedelta(days=days)
                return target_date.strftime("%Y-%m-%d")
        elif "last week" in date_text or "上周" in date_text:
            target_date = now - timedelta(days=7)
            return target_date.strftime("%Y-%m-%d")
        elif "next week" in date_text or "下周" in date_text:
            target_date = now + timedelta(days=7)
            return target_date.strftime("%Y-%m-%d")
        
        # 尝试解析常见日期格式
        date_formats = [
            "%Y-%m-%d",      # 2025-05-29
            "%m/%d/%Y",      # 05/29/2025
            "%d/%m/%Y",      # 29/05/2025
            "%m-%d",         # 05-29
            "%B %d",         # May 29
            "%b %d",         # May 29
            "%d %B",         # 29 May
            "%d %b"          # 29 May
        ]
        
        for fmt in date_formats:
            try:
                parsed = datetime.strptime(date_text, fmt)
                # 如果只有月日，假设是今年
                if parsed.year == 1900:
                    parsed = parsed.replace(year=now.year)
                return parsed.strftime("%Y-%m-%d")
            except ValueError:
                continue
        
        # 如果无法解析，返回原文本但添加日期标记
        return f"{date_text} (记录于 {now.strftime('%Y-%m-%d')})"
    
    def _calculate_importance_score(self, user_message: str, metadata: Dict) -> float:
        """计算对话重要性"""
        score = 0.1  # 基础分数
        
        # 个人信息分享
        if metadata["has_personal_info"]:
            score += 0.4
        
        # 情感强度
        strong_emotions = ["Sad", "Angry", "Anxious", "Excited", "Happy"]
        if any(emotion in strong_emotions for emotion in metadata["emotions"]):
            score += 0.3
        
        # 重要话题
        important_topics = ["Work", "Family", "Emotions", "Health"]
        if any(topic in important_topics for topic in metadata["topics"]):
            score += 0.2
        
        # 消息长度
        if len(user_message) > 50:
            score += 0.1
        
        return min(score, 1.0)
    
    def _add_to_medium_term(self, conversation: Dict, metadata: Dict):
        """添加到中期记忆 (MTM格式)"""
        mtm_conversation = {
            "timestamp": conversation["timestamp"],
            "importance": conversation["importance"],
            "conversation": [
                {
                    "user": conversation["user"],
                    "ai": conversation["ai"]
                }
            ],
            "topics": conversation["topics"],
            "emotions": conversation["emotions"],
            "insight": self._generate_insight(conversation, metadata),
            "personal_info": metadata["personal_info"],
            "preferences": metadata["preferences"]
        }
        
        self.medium_term_memories.append(mtm_conversation)
    
    def _generate_insight(self, conversation: Dict, metadata: Dict) -> str:
        """生成对话洞察"""
        topics = conversation["topics"]
        emotions = conversation["emotions"]
        importance = conversation["importance"]
        
        if importance > 0.8:
            return f"Highly significant conversation about {', '.join(topics)} with strong {', '.join(emotions)} emotions"
        elif importance > 0.6:
            return f"Important discussion about {', '.join(topics)} topics"
        else:
            return f"Meaningful exchange about {', '.join(topics)}"
    
    def _update_user_profile(self, conversation: Dict, metadata: Dict):
        """更新用户档案 (LTM - 只存储结构化信息) - 增强时间信息处理"""
        now = datetime.now()
        
        # 更新基础统计
        self.user_profile["interaction_summary"]["total_conversations"] += 1
        self.user_profile["interaction_summary"]["last_interaction"] = now.isoformat()
        
        # 保存具体的个人信息
        personal_info = metadata.get("personal_info", {})
        if personal_info:
            if "personal_details" not in self.user_profile:
                self.user_profile["personal_details"] = {}
            
            # 保存名字
            if "name" in personal_info:
                self.user_profile["personal_details"]["name"] = personal_info["name"]
                print(f"💡 保存用户名字: {personal_info['name']}")
            
            # 保存生日信息
            if "birthday" in personal_info:
                self.user_profile["personal_details"]["birthday"] = personal_info["birthday"]
                print(f"💡 保存用户生日: {personal_info['birthday']}")
        
        # 🔥 保存时间信息到专门的结构中
        time_info = metadata.get("time_info", {})
        if time_info:
            if "temporal_information" not in self.user_profile:
                self.user_profile["temporal_information"] = {}
            
            # 保存各种时间相关信息
            for time_type, time_data in time_info.items():
                if time_type == "detected_times":
                    # 保存检测到的时间表达式
                    if "detected_expressions" not in self.user_profile["temporal_information"]:
                        self.user_profile["temporal_information"]["detected_expressions"] = []
                    
                    for time_expr in time_data:
                        self.user_profile["temporal_information"]["detected_expressions"].append({
                            "original": time_expr["original"],
                            "parsed_date": time_expr["parsed"]["parsed_date"],
                            "confidence": time_expr["parsed"]["confidence"],
                            "recorded_at": now.isoformat()
                        })
                
                elif time_type in ["meeting", "appointment", "plan"]:
                    # 保存具体的事件和计划
                    if "upcoming_events" not in self.user_profile["temporal_information"]:
                        self.user_profile["temporal_information"]["upcoming_events"] = []
                    
                    self.user_profile["temporal_information"]["upcoming_events"].append({
                        "type": time_type,
                        "original": time_data.get("original", ""),
                        "parsed_date": time_data["parsed_date"],
                        "confidence": time_data.get("confidence", 0.8),
                        "recorded_at": now.isoformat(),
                        "status": "pending"
                    })
                    
                    print(f"📅 保存{time_type}: {time_data['parsed_date']}")
        
        # 更新话题兴趣 (去重)
        for topic in conversation["topics"]:
            if topic not in self.user_profile["topics_of_interest"]:
                self.user_profile["topics_of_interest"].append(topic)
        
        # 更新情感倾向 (去重)
        for emotion in conversation["emotions"]:
            if emotion not in self.user_profile["emotional_tendencies"]:
                self.user_profile["emotional_tendencies"].append(emotion)
        
        # 更新统计数据
        stats = self.user_profile["summary_stats"]
        
        # 话题统计
        for topic in conversation["topics"]:
            stats["most_discussed_topics"][topic] = stats["most_discussed_topics"].get(topic, 0) + 1
        
        # 情感统计
        for emotion in conversation["emotions"]:
            stats["dominant_emotions"][emotion] = stats["dominant_emotions"].get(emotion, 0) + 1
        
        # 计算平均重要性
        total_convs = self.user_profile["interaction_summary"]["total_conversations"]
        current_avg = self.user_profile["average_importance"]
        new_avg = (current_avg * (total_convs - 1) + conversation["importance"]) / total_convs
        self.user_profile["average_importance"] = new_avg
        
        # 更新关系阶段和交流风格
        self._update_behavioral_analysis()
        
        # 🔥 保存偏好信息
        if "preferences" in metadata and metadata["preferences"]:
            if "preferences" not in self.user_profile:
                self.user_profile["preferences"] = {}
            
            prefs = metadata["preferences"]
            for key, value in prefs.items():
                if key.startswith("favorite_"):
                    # 最喜欢的类别
                    category = key.replace("favorite_", "")
                    if "favorites" not in self.user_profile["preferences"]:
                        self.user_profile["preferences"]["favorites"] = {}
                    self.user_profile["preferences"]["favorites"][category] = value
                    print(f"💡 保存最喜欢的{category}: {value}")
                else:
                    # 其他偏好类型（like, love, hate等）
                    if key not in self.user_profile["preferences"]:
                        self.user_profile["preferences"][key] = []
                    if isinstance(value, list):
                        self.user_profile["preferences"][key].extend(value)
                    else:
                        self.user_profile["preferences"][key].append(value)
                    print(f"💡 保存偏好信息 {key}: {value}")
    
    def _update_behavioral_analysis(self):
        """更新行为分析"""
        total_convs = self.user_profile["interaction_summary"]["total_conversations"]
        
        # 更新关系阶段
        if total_convs <= 3:
            self.user_profile["relationship_stage"] = "Initial contact"
        elif total_convs <= 10:
            self.user_profile["relationship_stage"] = "Building trust"
        elif total_convs <= 25:
            self.user_profile["relationship_stage"] = "Deep interaction"
        else:
            self.user_profile["relationship_stage"] = "Long-term companion"
        
        # 分析信息分享倾向
        high_importance_count = sum(1 for conv in self.short_term_memories 
                                  if conv.get("importance", 0) > 0.6)
        
        if high_importance_count > total_convs * 0.3:
            self.user_profile["communication_style"] = "Open and sharing"
            self.user_profile["information_sharing_tendency"] = "High"
        elif high_importance_count > 0:
            self.user_profile["communication_style"] = "Cautiously sharing"
            self.user_profile["information_sharing_tendency"] = "Medium"
        else:
            self.user_profile["communication_style"] = "Reserved communicator"
            self.user_profile["information_sharing_tendency"] = "Low"
        
        # 分析活跃程度
        if total_convs > 20:
            self.user_profile["activity_level"] = "Highly active"
        elif total_convs > 5:
            self.user_profile["activity_level"] = "Regular interaction"
        else:
            self.user_profile["activity_level"] = "Exploring phase"
    
    def _maintain_memory_limits(self):
        """维护记忆容量限制"""
        # STM: 保持最新的N条对话
        if len(self.short_term_memories) > self.max_stm:
            self.short_term_memories = self.short_term_memories[-self.max_stm:]
        
        # MTM: 保持最重要的N条对话
        if len(self.medium_term_memories) > self.max_mtm:
            self.medium_term_memories.sort(key=lambda x: x["importance"], reverse=True)
            self.medium_term_memories = self.medium_term_memories[:self.max_mtm]
    
    def get_user_profile(self) -> Dict:
        """获取结构化用户档案 (LTM)"""
        return self.user_profile.copy()
    
    def get_important_conversations(self) -> List[Dict]:
        """获取重要对话记录 (MTM)"""
        return self.medium_term_memories.copy()
    
    def get_recent_conversations(self) -> List[Dict]:
        """获取最近对话 (STM)"""
        return self.short_term_memories.copy()
    
    def search_memories(self, query: str, max_results: int = 5) -> List[Dict]:
        """搜索相关记忆 - 优化偏好匹配"""
        results = []
        query_lower = query.lower()
        
        # 🔥 特殊处理偏好相关查询
        preference_keywords = {
            "movie": ["movie", "film", "cinema"],
            "music": ["music", "song", "artist", "band"],
            "book": ["book", "novel", "read"],
            "food": ["food", "eat", "restaurant", "meal"],
            "color": ["color", "colour"],
            "sport": ["sport", "game", "play"],
            "hobby": ["hobby", "interest", "enjoy"]
        }
        
        # 检查是否是偏好相关查询
        detected_categories = []
        for category, keywords in preference_keywords.items():
            if any(keyword in query_lower for keyword in keywords):
                detected_categories.append(category)
        
        if detected_categories and "favorite" in query_lower:
            # 这是一个关于最喜欢的X的查询
            print(f"🔍 检测到偏好查询: {detected_categories}")
            
            # 首先检查用户档案中的偏好信息
            if "preferences" in self.user_profile and "favorites" in self.user_profile["preferences"]:
                favorites = self.user_profile["preferences"]["favorites"]
                for category in detected_categories:
                    if category in favorites:
                        # 构造一个包含偏好信息的虚拟记忆
                        preference_memory = {
                            "user_message": f"my favorite {category} is {favorites[category]}",
                            "ai_response": f"I know your favorite {category} is {favorites[category]}!",
                            "timestamp": datetime.now().isoformat(),
                            "importance": 0.9,  # 高重要性
                            "metadata": {
                                "topic": ["preferences", "personal_info"],
                                "preferences": {f"favorite_{category}": favorites[category]}
                            }
                        }
                        results.append(preference_memory)
                        print(f"✅ 找到偏好信息: 最喜欢的{category} = {favorites[category]}")
        
        # 🔥 原有的记忆搜索逻辑...
        return results
    
    def save_all_memories(self):
        """保存所有记忆"""
        try:
            self._save_short_term_memories()
            self._save_medium_term_memories()
            self._save_user_profile()
            print(f"💾 All memories saved for user: {self.user_id}")
        except Exception as e:
            print(f"⚠️ 保存记忆失败: {e}")
    
    def _save_short_term_memories(self):
        """保存短期记忆 (STM)"""
        if not self.short_term_memories:
            return
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = Path(self.storage_dir) / "short_term" / f"session_{timestamp}.json"
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(self.short_term_memories, f, ensure_ascii=False, indent=2)
    
    def _save_medium_term_memories(self):
        """保存中期记忆 (MTM)"""
        file_path = Path(self.storage_dir) / "medium_term" / "important_memories.json"
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(self.medium_term_memories, f, ensure_ascii=False, indent=2)
    
    def _save_user_profile(self):
        """保存用户档案 (LTM)"""
        file_path = Path(self.storage_dir) / "long_term" / "user_profile.json"
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(self.user_profile, f, ensure_ascii=False, indent=2)
    
    def create_backup(self):
        """创建备份"""
        import shutil
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = Path(self.storage_dir) / f"backup_{timestamp}"
        
        # 复制存储目录
        source_dir = Path(self.storage_dir)
        shutil.copytree(source_dir, backup_dir, 
                       ignore=shutil.ignore_patterns("backup_*"))
        
        print(f"📦 Backup created: {backup_dir}")
        return str(backup_dir)
    
    def get_memory_stats(self) -> Dict:
        """获取记忆统计信息"""
        return {
            "user_id": self.user_id,
            "short_term_count": len(self.short_term_memories),
            "medium_term_count": len(self.medium_term_memories),
            "total_conversations": self.user_profile["interaction_summary"]["total_conversations"],
            "relationship_stage": self.user_profile["relationship_stage"],
            "communication_style": self.user_profile["communication_style"],
            "top_topics": dict(Counter(self.user_profile["summary_stats"]["most_discussed_topics"]).most_common(5)),
            "top_emotions": dict(Counter(self.user_profile["summary_stats"]["dominant_emotions"]).most_common(3)),
            "average_importance": self.user_profile["average_importance"]
        }
    
    def get_upcoming_events(self) -> List[Dict]:
        """获取即将到来的事件"""
        temporal_info = self.user_profile.get("temporal_information", {})
        upcoming_events = temporal_info.get("upcoming_events", [])
        
        # 过滤出未来的事件
        now = datetime.now()
        future_events = []
        
        for event in upcoming_events:
            try:
                event_date = datetime.fromisoformat(event["parsed_date"])
                if event_date > now and event.get("status") == "pending":
                    future_events.append(event)
            except Exception as e:
                # 如果日期格式不是ISO，尝试其他格式
                try:
                    event_date = datetime.strptime(event["parsed_date"], "%Y-%m-%d")
                    if event_date.date() >= now.date() and event.get("status") == "pending":
                        future_events.append(event)
                except Exception:
                    continue
        
        # 按日期排序
        future_events.sort(key=lambda x: x["parsed_date"])
        return future_events
    
    def get_time_related_context(self, query: str = "") -> Dict:
        """获取时间相关的上下文信息"""
        temporal_info = self.user_profile.get("temporal_information", {})
        personal_details = self.user_profile.get("personal_details", {})
        
        context = {
            "personal_dates": {},
            "upcoming_events": self.get_upcoming_events(),
            "recent_time_expressions": [],
            "temporal_patterns": {},
            "user_context": self._build_user_context()
        }
        
        # 添加个人重要日期
        if "birthday" in personal_details:
            context["personal_dates"]["birthday"] = personal_details["birthday"]
        
        # 添加最近的时间表达式
        detected_expressions = temporal_info.get("detected_expressions", [])
        if detected_expressions:
            # 只取最近的5个
            context["recent_time_expressions"] = detected_expressions[-5:]
        
        return context
    
    def _build_user_context(self) -> str:
        """构建用户基础信息"""
        # 构建用户基础信息
        user_info = []
        if "personal_details" in self.user_profile:
            personal = self.user_profile["personal_details"]
            if "name" in personal:
                user_info.append(f"姓名={personal['name']}")
            if "birthday" in personal:
                user_info.append(f"生日={personal['birthday']}")
            if "age" in personal:
                user_info.append(f"年龄={personal['age']}")
        
        # 🔥 添加偏好信息
        if "preferences" in self.user_profile:
            prefs = self.user_profile["preferences"]
            
            # 最喜欢的信息
            if "favorites" in prefs:
                for category, item in prefs["favorites"].items():
                    user_info.append(f"最喜欢的{category}={item}")
            
            # 其他偏好信息
            for pref_type in ["like", "love", "enjoy", "prefer"]:
                if pref_type in prefs and prefs[pref_type]:
                    items = prefs[pref_type][-3:]  # 最近3个
                    user_info.append(f"{pref_type}: {', '.join(items)}")
        
        user_context = "; ".join(user_info) if user_info else "新用户"
        return user_context


# 使用示例
if __name__ == "__main__":
    # 初始化记忆系统
    memory = SMOzMemorySystem(user_id="test_user")
    
    # 添加对话
    memory.add_conversation(
        "Hi, how are you today?",
        "Hello! I'm doing great, thanks for asking. How are you?"
    )
    
    memory.add_conversation(
        "I've been feeling really stressed about work lately",
        "I'm sorry to hear you're feeling stressed. Would you like to talk about what's been bothering you at work?"
    )
    
    # 获取用户档案
    profile = memory.get_user_profile()
    print("User Profile:", json.dumps(profile, indent=2, ensure_ascii=False))
    
    # 获取记忆统计
    stats = memory.get_memory_stats()
    print("Memory Stats:", json.dumps(stats, indent=2, ensure_ascii=False))
    
    # 保存记忆
    memory.save_all_memories() 