#!/usr/bin/env python3
"""
智能时间解析器
处理各种相对时间表达并转换为绝对时间
"""

import re
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple
import calendar

class IntelligentTimeParser:
    """智能时间解析器"""
    
    def __init__(self):
        # 中文月份映射
        self.chinese_months = {
            "一月": 1, "二月": 2, "三月": 3, "四月": 4, "五月": 5, "六月": 6,
            "七月": 7, "八月": 8, "九月": 9, "十月": 10, "十一月": 11, "十二月": 12,
            "1月": 1, "2月": 2, "3月": 3, "4月": 4, "5月": 5, "6月": 6,
            "7月": 7, "8月": 8, "9月": 9, "10月": 10, "11月": 11, "12月": 12
        }
        
        # 中文星期映射
        self.chinese_weekdays = {
            "周一": 0, "周二": 1, "周三": 2, "周四": 3, "周五": 4, "周六": 5, "周日": 6,
            "星期一": 0, "星期二": 1, "星期三": 2, "星期四": 3, "星期五": 4, "星期六": 5, "星期日": 6,
            "礼拜一": 0, "礼拜二": 1, "礼拜三": 2, "礼拜四": 3, "礼拜五": 4, "礼拜六": 5, "礼拜日": 6
        }
    
    def parse_time_expression(self, text: str, context_type: str = "general") -> Dict:
        """
        解析时间表达式
        
        Args:
            text: 包含时间信息的文本
            context_type: 上下文类型 (birthday, event, appointment, etc.)
        
        Returns:
            字典包含解析结果
        """
        now = datetime.now()
        text = text.lower().strip()
        
        result = {
            "original_text": text,
            "parsed_date": None,
            "parsed_time": None,
            "full_datetime": None,
            "is_relative": False,
            "confidence": 0.0,
            "context_type": context_type
        }
        
        # 1. 处理相对时间表达
        relative_result = self._parse_relative_expressions(text, now)
        if relative_result:
            result.update(relative_result)
            result["is_relative"] = True
            return result
        
        # 2. 处理绝对时间表达
        absolute_result = self._parse_absolute_expressions(text, now)
        if absolute_result:
            result.update(absolute_result)
            result["is_relative"] = False
            return result
        
        # 3. 处理模糊时间表达
        fuzzy_result = self._parse_fuzzy_expressions(text, now)
        if fuzzy_result:
            result.update(fuzzy_result)
            return result
        
        # 如果无法解析，返回带时间戳的原文
        result["parsed_date"] = f"{text} (记录于 {now.strftime('%Y-%m-%d %H:%M')})"
        result["confidence"] = 0.1
        return result
    
    def _parse_relative_expressions(self, text: str, now: datetime) -> Optional[Dict]:
        """解析相对时间表达"""
        
        patterns = [
            # 昨天、今天、明天
            (r"(?:昨天|yesterday)", lambda: now - timedelta(days=1), 0.9),
            (r"(?:今天|today)", lambda: now, 0.9),
            (r"(?:明天|tomorrow)", lambda: now + timedelta(days=1), 0.9),
            
            # 前天、后天
            (r"(?:前天|day before yesterday)", lambda: now - timedelta(days=2), 0.8),
            (r"(?:后天|day after tomorrow)", lambda: now + timedelta(days=2), 0.8),
            
            # X天前/后
            (r"(\d+)\s*天前", lambda m: now - timedelta(days=int(m.group(1))), 0.8),
            (r"(\d+)\s*days?\s+ago", lambda m: now - timedelta(days=int(m.group(1))), 0.8),
            (r"(\d+)\s*天后", lambda m: now + timedelta(days=int(m.group(1))), 0.8),
            (r"in\s+(\d+)\s+days?", lambda m: now + timedelta(days=int(m.group(1))), 0.8),
            
            # 上周、本周、下周
            (r"(?:上周|last week)", lambda: now - timedelta(weeks=1), 0.7),
            (r"(?:本周|this week)", lambda: now, 0.7),
            (r"(?:下周|next week)", lambda: now + timedelta(weeks=1), 0.7),
            
            # 上个月、这个月、下个月
            (r"(?:上个月|last month)", lambda: self._add_months(now, -1), 0.7),
            (r"(?:这个月|本月|this month)", lambda: now, 0.7),
            (r"(?:下个月|next month)", lambda: self._add_months(now, 1), 0.7),
        ]
        
        for pattern, calc_func, confidence in patterns:
            match = re.search(pattern, text)
            if match:
                try:
                    if hasattr(calc_func, '__call__'):
                        if match.groups():
                            target_date = calc_func(match)
                        else:
                            target_date = calc_func()
                    else:
                        target_date = calc_func
                    
                    return {
                        "parsed_date": target_date.strftime("%Y-%m-%d"),
                        "full_datetime": target_date.isoformat(),
                        "confidence": confidence
                    }
                except Exception as e:
                    continue
        
        return None
    
    def _parse_absolute_expressions(self, text: str, now: datetime) -> Optional[Dict]:
        """解析绝对时间表达"""
        
        date_patterns = [
            # 标准格式
            (r"(\d{4})-(\d{1,2})-(\d{1,2})", lambda m: datetime(int(m.group(1)), int(m.group(2)), int(m.group(3))), 0.95),
            (r"(\d{1,2})/(\d{1,2})/(\d{4})", lambda m: datetime(int(m.group(3)), int(m.group(1)), int(m.group(2))), 0.90),
            (r"(\d{1,2})\.(\d{1,2})\.(\d{4})", lambda m: datetime(int(m.group(3)), int(m.group(2)), int(m.group(1))), 0.90),
            
            # 月日格式（假设当年）
            (r"(\d{1,2})月(\d{1,2})日", lambda m: datetime(now.year, int(m.group(1)), int(m.group(2))), 0.85),
            (r"(\d{1,2})-(\d{1,2})", lambda m: datetime(now.year, int(m.group(1)), int(m.group(2))), 0.80),
            (r"(\d{1,2})/(\d{1,2})", lambda m: datetime(now.year, int(m.group(1)), int(m.group(2))), 0.80),
            
            # 英文月份
            (r"(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{1,2}),?\s*(\d{4})?", 
             lambda m: self._parse_english_month(m, now), 0.85),
        ]
        
        for pattern, calc_func, confidence in date_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                try:
                    target_date = calc_func(match)
                    return {
                        "parsed_date": target_date.strftime("%Y-%m-%d"),
                        "full_datetime": target_date.isoformat(),
                        "confidence": confidence
                    }
                except Exception as e:
                    continue
        
        return None
    
    def _parse_fuzzy_expressions(self, text: str, now: datetime) -> Optional[Dict]:
        """解析模糊时间表达"""
        
        fuzzy_patterns = [
            # 季节
            (r"(?:春天|spring)", lambda: datetime(now.year, 3, 20), 0.5),
            (r"(?:夏天|summer)", lambda: datetime(now.year, 6, 21), 0.5),
            (r"(?:秋天|autumn|fall)", lambda: datetime(now.year, 9, 22), 0.5),
            (r"(?:冬天|winter)", lambda: datetime(now.year, 12, 21), 0.5),
            
            # 节日（简化版）
            (r"(?:新年|new year)", lambda: datetime(now.year, 1, 1), 0.7),
            (r"(?:圣诞|christmas)", lambda: datetime(now.year, 12, 25), 0.7),
            (r"(?:情人节|valentine)", lambda: datetime(now.year, 2, 14), 0.7),
            
            # 时间段
            (r"(?:早上|morning)", lambda: now.replace(hour=8, minute=0, second=0), 0.6),
            (r"(?:中午|noon)", lambda: now.replace(hour=12, minute=0, second=0), 0.6),
            (r"(?:下午|afternoon)", lambda: now.replace(hour=15, minute=0, second=0), 0.6),
            (r"(?:晚上|evening)", lambda: now.replace(hour=19, minute=0, second=0), 0.6),
        ]
        
        for pattern, calc_func, confidence in fuzzy_patterns:
            if re.search(pattern, text):
                try:
                    target_date = calc_func()
                    return {
                        "parsed_date": target_date.strftime("%Y-%m-%d"),
                        "full_datetime": target_date.isoformat(),
                        "confidence": confidence
                    }
                except Exception as e:
                    continue
        
        return None
    
    def _parse_english_month(self, match, now):
        """解析英文月份"""
        month_names = {
            "january": 1, "february": 2, "march": 3, "april": 4,
            "may": 5, "june": 6, "july": 7, "august": 8,
            "september": 9, "october": 10, "november": 11, "december": 12
        }
        
        month_name = match.group(1).lower()
        day = int(match.group(2))
        year = int(match.group(3)) if match.group(3) else now.year
        
        month = month_names[month_name]
        return datetime(year, month, day)
    
    def _add_months(self, date: datetime, months: int) -> datetime:
        """添加月份"""
        month = date.month - 1 + months
        year = date.year + month // 12
        month = month % 12 + 1
        day = min(date.day, calendar.monthrange(year, month)[1])
        return datetime(year, month, day, date.hour, date.minute, date.second)
    
    def extract_all_time_expressions(self, text: str) -> list:
        """从文本中提取所有时间表达式"""
        results = []
        
        # 常见时间模式
        time_patterns = [
            r"\d{4}-\d{1,2}-\d{1,2}",  # 2025-05-29
            r"\d{1,2}/\d{1,2}/\d{4}",  # 5/29/2025
            r"\d{1,2}月\d{1,2}日",      # 5月29日
            r"昨天|今天|明天",            # 相对日期
            r"\d+天前|\d+天后",          # N天前后
            r"上周|本周|下周",            # 相对周
            r"上个月|这个月|下个月",       # 相对月
        ]
        
        for pattern in time_patterns:
            matches = re.finditer(pattern, text)
            for match in matches:
                time_expr = match.group()
                parsed = self.parse_time_expression(time_expr)
                if parsed["confidence"] > 0.5:
                    results.append({
                        "original": time_expr,
                        "parsed": parsed,
                        "start": match.start(),
                        "end": match.end()
                    })
        
        return results

# 全局时间解析器实例
time_parser = IntelligentTimeParser()

def parse_time_expression(text: str, context_type: str = "general") -> Dict:
    """便捷函数：解析时间表达式"""
    return time_parser.parse_time_expression(text, context_type)

def extract_all_times(text: str) -> list:
    """便捷函数：提取所有时间表达式"""
    return time_parser.extract_all_time_expressions(text) 