"""
Configuration file for AI of Oz system
Contains feature flags and system configuration
"""

class FeatureFlags:
    """功能开关配置类"""
    
    # 功能开关：检测功能（敏感度检测）
    ENABLE_DETECT = False
    
    # 功能开关：提炼功能（消息精化）
    ENABLE_REFINE = False
    
    # 功能开关：总结功能（对话总结）
    ENABLE_SUMMARY = False
    
    @classmethod
    def to_dict(cls):
        """将配置转换为字典格式"""
        return {
            'ENABLE_DETECT': cls.ENABLE_DETECT,
            'ENABLE_REFINE': cls.ENABLE_REFINE,
            'ENABLE_SUMMARY': cls.ENABLE_SUMMARY
        }
    
    @classmethod
    def update_from_dict(cls, config_dict):
        """从字典更新配置"""
        if 'ENABLE_DETECT' in config_dict:
            cls.ENABLE_DETECT = bool(config_dict['ENABLE_DETECT'])
        if 'ENABLE_REFINE' in config_dict:
            cls.ENABLE_REFINE = bool(config_dict['ENABLE_REFINE'])
        if 'ENABLE_SUMMARY' in config_dict:
            cls.ENABLE_SUMMARY = bool(config_dict['ENABLE_SUMMARY'])
    
    @classmethod
    def reset_to_defaults(cls):
        """重置为默认配置（所有功能关闭）"""
        cls.ENABLE_DETECT = False
        cls.ENABLE_REFINE = False
        cls.ENABLE_SUMMARY = False
    
    @classmethod
    def enable_all(cls):
        """启用所有功能"""
        cls.ENABLE_DETECT = True
        cls.ENABLE_REFINE = True
        cls.ENABLE_SUMMARY = True


# 使用说明：
# 1. 修改上面的类属性来启用/禁用相应功能
# 2. 也可以通过API接口 /feature-flags 动态修改
# 3. 目前所有功能都设置为False（禁用状态）以减少延迟 