#!/usr/bin/env python
import asyncio
import uuid
import os
import json
import sys
import tempfile
import atexit
from datetime import datetime
import shutil
from typing import List, Dict, Optional, Tuple

from openai import OpenAI
import numpy as np
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain.schema import Document
from langchain_community.vectorstores import InMemoryVectorStore
from langchain.text_splitter import RecursiveCharacterTextSplitter
from dotenv import load_dotenv

# 🔥 导入新的时间管理器
try:
    from .time_utils import get_time_manager, get_current_time_info, get_time_context_for_ai, get_system_prompt_time
    TIME_UTILS_AVAILABLE = True
    print("🕒 时间管理器已加载")
except ImportError:
    TIME_UTILS_AVAILABLE = False
    print("⚠️ 时间管理器不可用，使用基础时间功能")

# 使用最新的记忆系统v2.0
from .memory_system_v2 import SMOzMemorySystem
from .memory_system_enhanced import EnhancedMemorySystem, create_enhanced_memory_system
from .response_optimizer import ResponseOptimizer

# 初始化客户端
client1 = OpenAI()
client2 = OpenAI()
client3 = OpenAI()

# 配置文件路径 - 指向正确的Docker数据目录
def get_data_dir():
    """获取数据目录路径"""
    current_file = os.path.abspath(__file__)  # chat.py的绝对路径
    src_dir = os.path.dirname(current_file)   # src目录
    oz_server_dir = os.path.dirname(src_dir)  # oz-server目录
    
    # 🔥 检查是否在Docker容器内运行
    if oz_server_dir == "/code":
        # 在Docker容器内，直接使用容器内的数据路径
        return "/code/data"
    else:
        # 在开发环境中，使用相对路径
        project_root = os.path.dirname(oz_server_dir)  # 项目根目录 (SMOz - Langchain)
        return os.path.join(project_root, "sm-docker-local", "data")

DATA_DIR = get_data_dir()
CHAT_HISTORY_FILE = os.path.join(DATA_DIR, 'chat_history.json')
MEMORY_SUMMARY_FILE = os.path.join(DATA_DIR, 'memory_summary.json')

# 确保文件路径存在
def ensure_file_exists(file_path):
    directory = os.path.dirname(file_path)
    if directory and not os.path.exists(directory):
        os.makedirs(directory)
    if not os.path.exists(file_path):
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump([], f)

# 初始化LLM
llm = ChatOpenAI(
    model_name="gpt-4.1",
    temperature=0.7,
    max_tokens=1500
)

def save_to_json(data, file_path):
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception as e:
        print(f"保存JSON文件时出错: {e}")

def load_from_json(file_path):
    if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data if isinstance(data, list) else [data]
        except json.JSONDecodeError as e:
            print(f'JSON文件解析错误: {e}, 跳过加载.')
            return []
    return []

# 检查是否需要RAG
def check_need_rag_llm(user_input: str) -> bool:
    check_prompt = f"""
You are a judge. The user has input the following: {user_input}

If the user's question requires reference to previous conversations or memories to answer, output 'True'.
If the user's question does not require reference to any past conversations or memories, just casual chat or no recall needed, output 'False'.
Answer only with 'True' or 'False', no other explanation.
"""
    response = llm.invoke(check_prompt)
    if response:
        output_text = response.content.strip().lower()
        return "true" in output_text
    else:
        return False

# 构建短期上下文
def build_short_term_context(session_conversation):
    if not session_conversation:
        return "(No history in current session)"

    lines = []
    for doc in session_conversation:
        lines.append(doc.page_content)
    return "\n".join(lines)

# 混合记忆系统类 - 统一接口管理不同的记忆后端
class HybridMemorySystem:
    """
    混合记忆系统 - 统一接口管理不同的记忆后端
    现在优先使用标准化的v2.0记忆系统
    """
    
    def __init__(self, use_enhanced: bool = True, use_v2: bool = True, user_id: str = "default_user"):
        """初始化混合记忆系统"""
        self.use_enhanced = use_enhanced
        self.use_v2 = use_v2
        self.user_id = user_id
        
        # 初始化智能响应优化器
        try:
            self.response_optimizer = ResponseOptimizer()
            self.use_optimizer = True
            print("🎯 智能响应分级系统已启用")
        except:
            self.use_optimizer = False
            print("📝 使用标准响应处理")
        
        # 优先使用v2.0记忆系统（标准化格式）
        if self.use_v2:
            print("🧠 使用标准化记忆系统 v2.0")
            self.memory_v2 = SMOzMemorySystem(user_id=self.user_id)
            self.memory_type = "v2_standardized"
        elif self.use_enhanced:
            print("🧠 使用增强记忆系统")
            self.enhanced_memory = create_enhanced_memory_system(user_id=self.user_id)
            self.memory_type = "enhanced"
        else:
            print("📝 使用基础记忆系统")
            self.memory_type = "basic"
            self._init_basic_memory()
        
        # 🔥 系统启动时发送当前日期信息
        self._send_current_date_info()
        
        print(f"✅ 混合记忆系统已初始化 ({self.memory_type})")
    
    def _send_current_date_info(self):
        """系统启动时发送当前日期信息"""
        try:
            if TIME_UTILS_AVAILABLE:
                # 使用时间管理器获取准确时间
                time_manager = get_time_manager()
                time_info = time_manager.get_time_info()
                
                # 检查时间同步状态
                sync_status = time_manager.sync_time_with_ntp()
                sync_note = " (Time verified with NTP)" if sync_status else " (Time sync check failed)"
                
                date_message = f"Today is {time_info['date']}, {time_info['weekday']}. Current time is {time_info['time']} ({time_info['timezone_name']}){sync_note}."
            else:
                # 回退到基础时间功能
                now = datetime.now()
                current_date = now.strftime("%Y-%m-%d")
                current_time = now.strftime("%H:%M:%S")
                weekday = now.strftime("%A")
                
                date_message = f"Today is {current_date}, {weekday}. Current time is {current_time}."
            
            # 根据使用的记忆系统类型发送日期信息
            if self.use_v2 and hasattr(self, 'memory_v2'):
                # v2.0系统会自动记录系统信息
                print(f"📅 已向v2.0记忆系统发送当前日期信息: {date_message}")
            elif self.use_enhanced and hasattr(self, 'enhanced_memory'):
                # 向增强记忆系统发送日期信息
                self.enhanced_memory.add_system_message(date_message)
                print(f"📅 已向增强记忆系统发送当前日期信息: {date_message}")
            else:
                # 向基础记忆系统添加日期信息
                self.session_conversation.append(
                    Document(page_content=f"System: {date_message}")
                )
                print(f"📅 已向基础记忆系统发送当前日期信息: {date_message}")
                
        except Exception as e:
            print(f"⚠️ 发送当前日期信息时出错: {e}")
    
    def _init_basic_memory(self):
        """初始化基础记忆系统"""
        # 确保文件存在
        ensure_file_exists(CHAT_HISTORY_FILE)
        ensure_file_exists(MEMORY_SUMMARY_FILE)
        
        self.embeddings = OpenAIEmbeddings()
        self.short_term_vectordb = InMemoryVectorStore(embedding=self.embeddings)
        self.long_term_vectordb = InMemoryVectorStore(embedding=self.embeddings)
        self.session_conversation = []
        self.existing_memory = self.load_basic_memory()
        
        # 获取当前日期
        current_date = datetime.now().strftime("%Y-%m-%d")
        
        # 🔥 获取当前时间信息
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S %A")
        
        # 基础系统提示词
        self.system_prompt = f"""Current time: {current_time}

You are Lucy, an AI companion with psychological awareness and empathy.

## 🕒 Time Awareness Important Notes:
- Current time is {current_time} ({weekday})
- The memory content below contains conversations from different time points
- Please distinguish between "current events" and "past memories"
- When users ask time-related questions, answer based on current time
- Events in memories are from the past, not happening now

## 📚 Memory Context:
{self.existing_memory if self.existing_memory else "No relevant memories available for reference."}

## 🧠 Your Thinking Process:

**Step 1: Time Context Analysis**
- Is the user's question about present, past, or future?
- When did the information in memories occur?
- How to correctly correlate the timeline?

**Step 2: Psychological Analysis**
- What is the user's emotional state?
- What psychological needs might they have?
- Are there signs of stress or anxiety?

**Step 3: Memory Integration**
- Which historical memories are relevant to current conversation?
- What are the user's personal information and preferences?
- What stage has the relationship developed to?

**Step 4: Response Strategy**
- What type of support should be provided?
- How to naturally reference relevant memories?
- How to maintain Lucy's personality traits?

## 💫 Response Guidelines:
- Maintain Lucy's personality: friendly, slightly playful, honest, supportive but not overly accommodating
- Naturally integrate relevant memories, but clarify time relationships
- Keep responses concise and interesting (usually 30-80 words)
- If involving time, answer based on current time {current_time}
- Balance empathy with authenticity

Please respond as Lucy, following the above thinking process but only showing the final natural response."""

    def load_basic_memory(self):
        """加载基础记忆系统数据"""
        chat_history = load_from_json(CHAT_HISTORY_FILE)
        if chat_history:
            self.session_conversation = [Document(page_content=item) for item in chat_history]
            self.short_term_vectordb.add_documents(self.session_conversation)
            print('短期记忆已加载')
            
        memory_data = load_from_json(MEMORY_SUMMARY_FILE)
        if memory_data:
            long_term_docs = [Document(page_content=item) for item in memory_data]
            self.long_term_vectordb.add_documents(long_term_docs)
            print('长期记忆已加载')
            return memory_data
        return []

    def add_to_memory(self, user_message, ai_response):
        """添加对话到记忆"""
        if self.use_v2 and hasattr(self, 'memory_v2'):
            # 使用v2.0标准化记忆系统
            self.memory_v2.add_conversation(user_message, ai_response)
            print("💾 对话已保存到v2.0记忆系统")
        elif self.use_enhanced and hasattr(self, 'enhanced_memory'):
            self.enhanced_memory.add_conversation(user_message, ai_response)
            print("💾 对话已保存到增强记忆系统")
        else:
            self._add_to_basic_memory(user_message, ai_response)
            print("💾 对话已保存到基础记忆系统")
    
    def _add_to_basic_memory(self, user_message, ai_response):
        """添加到基础记忆系统"""
        new_docs = [
            Document(page_content=f'User: {user_message}'),
            Document(page_content=f'Lucy: {ai_response}')
        ]
        self.short_term_vectordb.add_documents(new_docs)
        self.session_conversation.extend(new_docs)
        
        if len(self.session_conversation) > 20:
            self.session_conversation = self.session_conversation[-20:]
            self.short_term_vectordb = InMemoryVectorStore(embedding=self.embeddings)
            self.short_term_vectordb.add_documents(self.session_conversation)
            
        save_to_json([doc.page_content for doc in self.session_conversation], CHAT_HISTORY_FILE)

    def get_relevant_context(self, query):
        """获取相关上下文"""
        if self.use_v2 and hasattr(self, 'memory_v2'):
            # 使用v2.0标准化记忆系统获取上下文
            return self._get_v2_context(query)
        elif self.use_enhanced and hasattr(self, 'enhanced_memory'):
            return self.enhanced_memory.get_contextual_memory(query)
        else:
            return self._get_basic_context(query)
    
    def _get_v2_context(self, query):
        """从v2.0记忆系统获取相关上下文"""
        try:
            # 获取用户档案
            user_profile = self.memory_v2.get_user_profile()
            
            # 获取最近对话
            recent_conversations = self.memory_v2.get_recent_conversations()
            
            # 获取重要对话
            important_conversations = self.memory_v2.get_important_conversations()
            
            # 搜索相关记忆
            search_results = self.memory_v2.search_memories(query)
            
            context_parts = []
            
            # 添加用户档案摘要
            if user_profile:
                context_parts.append("=== User Profile ===")
                
                # 添加个人详细信息
                personal_details = user_profile.get('personal_details', {})
                if personal_details:
                    if 'name' in personal_details:
                        context_parts.append(f"Name: {personal_details['name']}")
                    if 'birthday' in personal_details:
                        context_parts.append(f"Birthday: {personal_details['birthday']}")
                
                context_parts.append(f"Communication Style: {user_profile.get('communication_style', 'Unknown')}")
                context_parts.append(f"Relationship Stage: {user_profile.get('relationship_stage', 'Unknown')}")
                
                topics = user_profile.get('topics_of_interest', [])
                if topics:
                    context_parts.append(f"Topics of Interest: {', '.join(topics[:5])}")
                
                emotions = user_profile.get('emotional_tendencies', [])
                if emotions:
                    context_parts.append(f"Emotional Tendencies: {', '.join(emotions[:3])}")
            
            # 添加最近对话
            if recent_conversations:
                context_parts.append("\n=== Recent Conversations ===")
                for conv in recent_conversations[-3:]:  # 最近3条
                    context_parts.append(f"User: {conv['user'][:100]}...")
                    context_parts.append(f"AI: {conv['ai'][:100]}...")
            
            # 添加相关搜索结果
            if search_results:
                context_parts.append("\n=== Relevant Memories ===")
                for result in search_results[:2]:  # 最相关的2条
                    if result['type'] == 'short_term':
                        data = result['data']
                        context_parts.append(f"Recent: {data['user'][:80]}... -> {data['ai'][:80]}...")
                    elif result['type'] == 'medium_term':
                        data = result['data']
                        # 处理不同格式的中期记忆
                        if 'conversation' in data:
                            # v2.0格式
                            context_parts.append(f"Important: {data.get('insight', 'No insight available')}")
                        elif 'content' in data:
                            # 旧格式
                            content = data['content'][:150] + "..." if len(data['content']) > 150 else data['content']
                            context_parts.append(f"Important: {content}")
                        else:
                            context_parts.append(f"Important: {str(data)[:100]}...")
            
            return "\n".join(context_parts)
            
        except Exception as e:
            print(f"⚠️ 获取v2.0上下文失败: {e}")
            return "No relevant context available."
    
    def _get_basic_context(self, query):
        """获取基础系统的相关上下文"""
        # 判断是否需要RAG
        need_rag = check_need_rag_llm(query)
        if need_rag:
            results = self.long_term_vectordb.similarity_search(query, k=1)
            return results[0].page_content if results else None
        return None

    async def process_message(self, user_input):
        """处理用户消息的主入口 - 集成智能分级系统"""
        
        # 策略1: 智能响应分级
        if self.use_optimizer:
            try:
                print(f"🎯 开始智能分级处理: {user_input[:30]}...")
                optimization_result = await self.response_optimizer.get_optimized_response(user_input, self)
                
                # 记录性能数据
                response_time = optimization_result["response_time"]
                strategy = optimization_result["strategy_used"]
                complexity = optimization_result["complexity"]
                confidence = optimization_result["confidence"]
                
                print(f"✅ 分级完成: {strategy} | {complexity} | {response_time:.2f}s | 置信度: {confidence:.1f}")
                
                # 🔥 修复：只有ultra_simple才使用预设回复，其他都需要记忆处理
                if strategy == "ultra_simple":
                    # 超简单回复：使用预设，但仍然要更新记忆
                    await self._lightweight_memory_update(user_input, optimization_result["response"])
                    return optimization_result["response"]
                
                elif strategy in ["simple", "medium"]:
                    # 🔥 简单和中等消息：使用记忆系统生成回复，但可以并行处理
                    print("🧠 使用完整记忆系统处理简单/中等消息")
                    return await self._process_with_memory_optimized(user_input, complexity)
                
                else:  # complex
                    # 复杂消息：完整记忆处理
                    print("🔬 使用完整记忆系统处理复杂消息")
                    return await self._process_with_full_memory(user_input)
                    
            except Exception as e:
                print(f"⚠️ 响应优化失败，回退到标准处理: {e}")
                # 回退到标准处理
        
        # 标准处理（无优化器或优化器失败）
        if self.use_enhanced:
            return await self._process_with_enhanced(user_input)
        else:
            return await self._process_with_basic_async(user_input)
    
    async def _process_with_memory_optimized(self, user_input, complexity):
        """针对简单/中等消息的优化记忆处理"""
        # 如果使用v2.0系统
        if self.use_v2 and hasattr(self, 'memory_v2'):
            return await self._process_with_v2_optimized(user_input, complexity)
        
        # 原有的增强系统处理
        if not hasattr(self, 'enhanced_memory'):
            return await self._process_with_basic_async(user_input)
        
        if TIME_UTILS_AVAILABLE:
            # 使用时间管理器获取准确时间
            time_manager = get_time_manager()
            time_info = time_manager.get_time_info()
            time_context = time_manager.format_time_context()
        else:
            # 回退到基础时间功能
            now = datetime.now()
            current_time = now.strftime("%Y-%m-%d %H:%M:%S")
            current_weekday = now.strftime("%A")
            time_context = f"Current time: {current_time} {current_weekday}"
        
        # 获取相关记忆上下文
        memory_context = self.enhanced_memory.get_contextual_memory(user_input)
        
        # 🔥 构建优化的系统提示词（更简洁但包含时间和记忆）
        if TIME_UTILS_AVAILABLE:
            system_prompt = f"""{time_context}

You are Lucy, a friendly AI companion.

## Time Awareness:
Current time is {time_info['readable_time']}, please answer based on current time.

## Memory Reference:
{memory_context if memory_context and memory_context != "No relevant memories found." else "No relevant memories available."}

## Guidelines:
- Use relevant memories to provide personalized responses
- Clearly distinguish between current events and past memories
- Keep conversation natural and flowing
- Show Lucy's friendly personality

Please respond naturally, referencing relevant memories when appropriate."""
        else:
            system_prompt = f"""{time_context}

You are Lucy, a friendly AI companion.

## Time Awareness:
Current time is {current_time}, please answer based on current time.

## Memory Reference:
{memory_context if memory_context and memory_context != "No relevant memories found." else "No relevant memories available."}

## Guidelines:
- Use relevant memories to provide personalized responses
- Clearly distinguish between current events and past memories
- Keep conversation natural and flowing
- Show Lucy's friendly personality

Please respond naturally, referencing relevant memories when appropriate."""

        # 使用记忆系统处理
        ai_response, context = await self.enhanced_memory.process_with_memory(user_input, system_prompt)
        return ai_response
    
    async def _process_with_v2_optimized(self, user_input, complexity):
        """使用v2.0记忆系统的优化处理"""
        if TIME_UTILS_AVAILABLE:
            # 使用时间管理器获取准确时间
            time_manager = get_time_manager()
            time_info = time_manager.get_time_info()
            time_context = time_manager.format_time_context()
        else:
            # 回退到基础时间功能
            now = datetime.now()
            current_time = now.strftime("%Y-%m-%d %H:%M:%S")
            current_weekday = now.strftime("%A")
            time_context = f"Current time: {current_time} {current_weekday}"
        
        # 获取v2.0记忆上下文（简化版）
        memory_context = self._get_v2_context(user_input)
        
        # 构建简化的系统提示词
        if TIME_UTILS_AVAILABLE:
            system_prompt = f"""{time_context}

You are Lucy, a friendly AI companion.

## Time Awareness:
Current time is {time_info['readable_time']}, please answer based on current time.

## Memory Reference:
{memory_context if memory_context and memory_context != "No relevant context available." else "No relevant memories available."}

## Guidelines:
- Use relevant memories to provide personalized responses
- Keep conversation natural and flowing
- Show Lucy's friendly personality
- Keep responses concise (30-60 words)

Please respond naturally as Lucy."""
        else:
            system_prompt = f"""{time_context}

You are Lucy, a friendly AI companion.

## Time Awareness:
Current time is {current_time}, please answer based on current time.

## Memory Reference:
{memory_context if memory_context and memory_context != "No relevant context available." else "No relevant memories available."}

## Guidelines:
- Use relevant memories to provide personalized responses
- Keep conversation natural and flowing
- Show Lucy's friendly personality
- Keep responses concise (30-60 words)

Please respond naturally as Lucy."""

        # 使用OpenAI API生成回复
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_input}
        ]
        
        response = client1.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            max_tokens=150,
            temperature=0.7
        )
        
        ai_response = response.choices[0].message.content
        
        # 添加到v2.0记忆系统
        self.memory_v2.add_conversation(user_input, ai_response)
        
        return ai_response

    async def _process_with_full_memory(self, user_input):
        """完整记忆处理（用于复杂消息）"""
        if self.use_enhanced:
            return await self._process_with_enhanced(user_input)
        else:
            return await self._process_with_basic_async(user_input)
    
    async def _process_with_enhanced(self, user_input):
        """使用增强记忆系统处理"""
        # 如果使用v2.0系统，转到v2.0处理
        if self.use_v2 and hasattr(self, 'memory_v2'):
            return await self._process_with_v2_enhanced(user_input)
        
        # 原有的增强系统处理
        if not hasattr(self, 'enhanced_memory'):
            # 如果没有增强记忆系统，回退到基础处理
            return await self._process_with_basic_async(user_input)
        
        if TIME_UTILS_AVAILABLE:
            # 使用时间管理器获取准确时间
            time_manager = get_time_manager()
            time_info = time_manager.get_time_info()
            time_context = time_manager.format_time_context()
        else:
            # 回退到基础时间功能
            now = datetime.now()
            current_date = now.strftime("%Y-%m-%d")
            current_time = now.strftime("%Y-%m-%d %H:%M:%S")
            current_weekday = now.strftime("%A")
            time_context = f"Current time: {current_time} {current_weekday}"
        
        # 获取记忆上下文
        memory_context = self.enhanced_memory.get_contextual_memory(user_input)
        
        # 🔥 增强的系统提示词，包含时间上下文
        if TIME_UTILS_AVAILABLE:
            system_prompt = f"""{time_context}

You are Lucy, an AI companion with psychological awareness and empathy.

## 🕒 Time Awareness Important Notes:
- Current time is {time_info['readable_time']} ({time_info['weekday']})
- Timezone: {time_info['timezone_name']}
- The memory content below contains conversations from different time points
- Please distinguish between "current events" and "past memories"
- When users ask time-related questions, answer based on current time
- Events in memories are from the past, not happening now

## 📚 Memory Context:
{memory_context if memory_context and memory_context != "No relevant memories found." else "No relevant memories available for reference."}

## 🧠 Your Thinking Process:

**Step 1: Time Context Analysis**
- Is the user's question about present, past, or future?
- When did the information in memories occur?
- How to correctly correlate the timeline?

**Step 2: Psychological Analysis**
- What is the user's emotional state?
- What psychological needs might they have?
- Are there signs of stress or anxiety?

**Step 3: Memory Integration**
- Which historical memories are relevant to current conversation?
- What are the user's personal information and preferences?
- What stage has the relationship developed to?

**Step 4: Response Strategy**
- What type of support should be provided?
- How to naturally reference relevant memories?
- How to maintain Lucy's personality traits?

## 💫 Response Guidelines:
- Maintain Lucy's personality: friendly, slightly playful, honest, supportive but not overly accommodating
- Naturally integrate relevant memories, but clarify time relationships
- Keep responses concise and interesting (usually 30-80 words)
- If involving time, answer based on current time {time_info['readable_time']}
- Balance empathy with authenticity

Please respond as Lucy, following the above thinking process but only showing the final natural response."""
        else:
            system_prompt = f"""{time_context}

You are Lucy, an AI companion with psychological awareness and empathy.

## 🕒 Time Awareness Important Notes:
- Current time is {current_time} ({current_weekday})
- The memory content below contains conversations from different time points
- Please distinguish between "current events" and "past memories"
- When users ask time-related questions, answer based on current time
- Events in memories are from the past, not happening now

## 📚 Memory Context:
{memory_context if memory_context and memory_context != "No relevant memories found." else "No relevant memories available for reference."}

## 🧠 Your Thinking Process:

**Step 1: Time Context Analysis**
- Is the user's question about present, past, or future?
- When did the information in memories occur?
- How to correctly correlate the timeline?

**Step 2: Psychological Analysis**
- What is the user's emotional state?
- What psychological needs might they have?
- Are there signs of stress or anxiety?

**Step 3: Memory Integration**
- Which historical memories are relevant to current conversation?
- What are the user's personal information and preferences?
- What stage has the relationship developed to?

**Step 4: Response Strategy**
- What type of support should be provided?
- How to naturally reference relevant memories?
- How to maintain Lucy's personality traits?

## 💫 Response Guidelines:
- Maintain Lucy's personality: friendly, slightly playful, honest, supportive but not overly accommodating
- Naturally integrate relevant memories, but clarify time relationships
- Keep responses concise and interesting (usually 30-80 words)
- If involving time, answer based on current time {current_time}
- Balance empathy with authenticity

Please respond as Lucy, following the above thinking process but only showing the final natural response."""

        # 使用记忆系统处理
        ai_response, context = await self.enhanced_memory.process_with_memory(user_input, system_prompt)
        
        # 添加到记忆
        self.enhanced_memory.add_conversation(user_input, ai_response)
        
        return ai_response
    
    async def _process_with_v2_enhanced(self, user_input):
        """使用v2.0记忆系统的增强处理"""
        if TIME_UTILS_AVAILABLE:
            # 使用时间管理器获取准确时间
            time_manager = get_time_manager()
            time_info = time_manager.get_time_info()
            time_context = time_manager.format_time_context()
        else:
            # 回退到基础时间功能
            now = datetime.now()
            current_time = now.strftime("%Y-%m-%d %H:%M:%S")
            current_weekday = now.strftime("%A")
            time_context = f"Current time: {current_time} {current_weekday}"
        
        # 获取v2.0记忆上下文
        memory_context = self._get_v2_context(user_input)
        
        # 构建系统提示词
        if TIME_UTILS_AVAILABLE:
            system_prompt = f"""{time_context}

You are Lucy, an AI companion with psychological awareness and empathy.

## 🕒 Time Awareness Important Notes:
- Current time is {time_info['readable_time']} ({time_info['weekday']})
- Timezone: {time_info['timezone_name']}
- The memory content below contains conversations from different time points
- Please distinguish between "current events" and "past memories"
- When users ask time-related questions, answer based on current time
- Events in memories are from the past, not happening now

## 📚 Memory Context:
{memory_context if memory_context and memory_context != "No relevant context available." else "No relevant memories available for reference."}

## Response Guidelines:
- Maintain Lucy's personality: friendly, slightly playful, honest, supportive
- Naturally integrate relevant memories when appropriate
- Keep responses concise and interesting (usually 30-80 words)
- Balance empathy with authenticity
- If involving time, answer based on current time {time_info['readable_time']}

Please respond as Lucy naturally."""
        else:
            system_prompt = f"""{time_context}

You are Lucy, an AI companion with psychological awareness and empathy.

## 🕒 Time Awareness Important Notes:
- Current time is {current_time} ({current_weekday})
- The memory content below contains conversations from different time points
- Please distinguish between "current events" and "past memories"
- When users ask time-related questions, answer based on current time
- Events in memories are from the past, not happening now

## 📚 Memory Context:
{memory_context if memory_context and memory_context != "No relevant context available." else "No relevant memories available for reference."}

## Response Guidelines:
- Maintain Lucy's personality: friendly, slightly playful, honest, supportive
- Naturally integrate relevant memories when appropriate
- Keep responses concise and interesting (usually 30-80 words)
- Balance empathy with authenticity
- If involving time, answer based on current time {current_time}

Please respond as Lucy naturally."""

        # 使用OpenAI API生成回复
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_input}
        ]
        
        response = client1.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            max_tokens=200,
            temperature=0.7
        )
        
        ai_response = response.choices[0].message.content
        
        # 添加到v2.0记忆系统
        self.memory_v2.add_conversation(user_input, ai_response)
        
        return ai_response
    
    async def _process_with_basic_async(self, user_input):
        """使用基础记忆系统处理（异步版本）"""
        # 🔥 获取详细的当前时间信息 - 修复编码问题
        now = datetime.now()
        current_date = now.strftime("%Y-%m-%d")
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        current_weekday = now.strftime("%A")
        
        # 获取相关上下文
        context = self.get_relevant_context(user_input)
        
        # 🔥 更新基础系统提示词，包含时间信息 - 使用英文避免编码问题
        enhanced_system_prompt = f"""Current time: {current_time} {current_weekday}

You are Lucy, an AI companion with psychological awareness and empathy.

## 🕒 Time Awareness:
- Current time is {current_time} ({current_weekday})
- Please answer time-related questions based on current time
- Distinguish between current events and past memories

## 📚 Relevant Memories:
{context if context else "No relevant historical memories available."}

## 🧠 Psychological Analysis Process:

**Emotional Analysis**: Analyze user's emotional state and psychological needs
**Context Understanding**: Consider conversation background and relationship dynamics  
**Response Strategy**: Determine the most helpful response approach
**Personality Expression**: Maintain Lucy's friendly, honest, slightly playful traits

## Response Guidelines:
- Naturally integrate psychological insights without being clinical
- Maintain Lucy's personality traits
- Keep responses concise and interesting (30-80 words)
- If detecting serious mental health issues, gently suggest professional help
- Be helpful while maintaining appropriate boundaries

Please respond as Lucy, showing only the final natural response."""

        # 构建消息
        messages = [
            {"role": "system", "content": enhanced_system_prompt},
            {"role": "user", "content": user_input}
        ]
        
        # 调用OpenAI API
        response = client1.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            max_tokens=150,
            temperature=0.7
        )
        
        ai_response = response.choices[0].message.content
        
        # 添加到记忆
        self.add_to_memory(user_input, ai_response)
        
        return ai_response

    def get_memory_stats(self):
        """获取记忆系统统计信息"""
        base_stats = {}
        
        if self.use_v2 and hasattr(self, 'memory_v2'):
            base_stats = {
                "type": "v2_standardized",
                **self.memory_v2.get_memory_stats()
            }
        elif self.use_enhanced and hasattr(self, 'enhanced_memory'):
            base_stats = {
                "type": "enhanced",
                **self.enhanced_memory.get_memory_statistics()
            }
        else:
            base_stats = {
                "type": "basic",
                "short_term_count": len(self.session_conversation),
                "memory_file": CHAT_HISTORY_FILE
            }
        
        # 添加响应优化器统计
        if self.use_optimizer:
            optimizer_stats = self.response_optimizer.get_performance_stats()
            base_stats["response_optimizer"] = {
                "enabled": True,
                **optimizer_stats
            }
        else:
            base_stats["response_optimizer"] = {"enabled": False}
        
        return base_stats

    def save_session(self):
        """保存会话"""
        if self.use_v2 and hasattr(self, 'memory_v2'):
            self.memory_v2.save_all_memories()
            print("💾 v2.0记忆系统会话已保存")
        elif self.use_enhanced and hasattr(self, 'enhanced_memory'):
            self.enhanced_memory.save_all_memories()
            print("💾 增强记忆系统会话已保存")
        else:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.session_conversation.append(
                Document(page_content=f"--- Session ended at {timestamp} ---")
            )
            save_to_json([doc.page_content for doc in self.session_conversation], CHAT_HISTORY_FILE)
            print("💾 基础记忆系统会话已保存")

    def clear_chat(self):
        """清除聊天记录"""
        if self.use_enhanced:
            self.enhanced_memory.clear_session()
        else:
            self.session_conversation = []
            self.short_term_vectordb = InMemoryVectorStore(embedding=self.embeddings)
            save_to_json([], CHAT_HISTORY_FILE)

    async def _lightweight_memory_update(self, user_input, ai_response):
        """轻量级记忆更新，用于简单响应"""
        try:
            if self.use_v2 and hasattr(self, 'memory_v2'):
                # 使用v2.0记忆系统进行简单的对话记录
                self.memory_v2.add_conversation(user_input, ai_response)
            elif self.use_enhanced and hasattr(self, 'enhanced_memory'):
                # 只进行基本的对话记录，跳过复杂分析
                await self.enhanced_memory.add_simple_conversation(user_input, ai_response)
            else:
                # 基础记忆系统的简单更新
                self._add_to_basic_memory(user_input, ai_response)
        except Exception as e:
            print(f"轻量级记忆更新失败: {e}")
            # 即使记忆更新失败，也不影响响应

# 为了向后兼容，保留原有的MemorySystem类名
MemorySystem = HybridMemorySystem

# 创建记忆系统实例
memory_system = MemorySystem()

# 🔥 全局用户记忆系统管理器
user_memory_systems = {}

def get_or_create_user_memory_system(user_id: str):
    """获取或创建指定用户的记忆系统"""
    global user_memory_systems
    
    if user_id not in user_memory_systems:
        print(f"🆕 为用户 '{user_id}' 创建新的记忆系统")
        
        # 🔥 直接创建使用v2.0记忆系统的混合系统，传入正确的user_id
        hybrid_system = HybridMemorySystem(use_enhanced=False, use_v2=True, user_id=user_id)
        
        # 🔥 立即尝试加载已存在的记忆数据并显示统计
        try:
            if hasattr(hybrid_system, 'memory_v2'):
                user_profile = hybrid_system.memory_v2.get_user_profile()
                total_conversations = user_profile.get("interaction_summary", {}).get("total_conversations", 0)
                start_date = user_profile.get("companion_start_date", "")
                
                # 检查是否有个人详细信息
                personal_details = user_profile.get("personal_details", {})
                user_name = personal_details.get("name", "Unknown")
                user_birthday = personal_details.get("birthday", "Unknown")
                
                if start_date:
                    from datetime import datetime
                    start_dt = datetime.strptime(start_date, "%Y-%m-%d")
                    companion_days = (datetime.now() - start_dt).days
                else:
                    companion_days = 0
                    
                print(f"📚 加载了用户 '{user_id}' 的历史记忆：{total_conversations} 条对话，陪伴 {companion_days} 天")
                if user_name != "Unknown":
                    print(f"👤 用户信息：姓名={user_name}, 生日={user_birthday}")
        except Exception as e:
            print(f"⚠️ 加载用户 '{user_id}' 历史记忆失败: {e}")
        
        user_memory_systems[user_id] = hybrid_system
        print(f"✅ 用户 '{user_id}' 的v2.0记忆系统已初始化")
    else:
        print(f"🔄 使用已存在的用户 '{user_id}' 记忆系统")
    
    return user_memory_systems[user_id]

# 🔥 动态生成系统提示词的函数，确保时间总是最新的
def get_system1():
    """动态生成system1提示词，包含当前时间"""
    if TIME_UTILS_AVAILABLE:
        # 使用时间管理器获取准确时间
        time_manager = get_time_manager()
        time_info = time_manager.get_time_info()
        time_context = time_manager.format_time_context()
        
        return f"""{time_context}

You are Lucy, a friendly and psychologically aware AI companion. 

IMPORTANT TIME AWARENESS:
- Today's date is {time_info['date']} ({time_info['weekday']})
- Current time is {time_info['time']}
- Timezone: {time_info['timezone_name']}
- When users ask about time-related questions, always reference the current date/time above
- Events in your memory are from the past - distinguish between current events and historical memories

Your approach:
1. Listen actively and understand emotional subtext
2. Provide thoughtful, empathetic responses
3. Be honest and supportive without being overly accommodating
4. Keep responses concise (30-50 words typically)
5. Balance emotional support with gentle challenges when appropriate

Respond naturally as Lucy, integrating psychological awareness without being clinical."""
    else:
        # 回退到基础时间功能
        now = datetime.now()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S %A")
        current_date = now.strftime("%Y-%m-%d")
        current_weekday = now.strftime("%A")
        current_time_only = now.strftime("%H:%M:%S")
        
        return f"""Current time: {current_time}

You are Lucy, a friendly and psychologically aware AI companion. 

IMPORTANT TIME AWARENESS:
- Today's date is {current_date} ({current_weekday})
- Current time is {current_time_only}
- When users ask about time-related questions, always reference the current date/time above
- Events in your memory are from the past - distinguish between current events and historical memories

Your approach:
1. Listen actively and understand emotional subtext
2. Provide thoughtful, empathetic responses
3. Be honest and supportive without being overly accommodating
4. Keep responses concise (30-50 words typically)
5. Balance emotional support with gentle challenges when appropriate

Respond naturally as Lucy, integrating psychological awareness without being clinical."""

def get_system2():
    """动态生成system2提示词，包含当前时间"""
    if TIME_UTILS_AVAILABLE:
        # 使用时间管理器获取准确时间
        time_manager = get_time_manager()
        time_info = time_manager.get_time_info()
        time_context = time_manager.format_time_context()
        
        return f"""{time_context}

You are Lucy, an AI companion with psychological insight.

IMPORTANT TIME AWARENESS:
- Today's date is {time_info['date']} ({time_info['weekday']})
- Current time is {time_info['time']}
- Timezone: {time_info['timezone_name']}
- When users ask about time-related questions, always reference the current date/time above
- Events in your memory are from the past - distinguish between current events and historical memories

Your style:
1. Slightly sassy and playful when appropriate
2. Direct and honest, but supportive
3. Curious about the user's thoughts and feelings
4. Able to read between the lines emotionally
5. Concise and engaging responses

Respond as Lucy with psychological awareness woven naturally into your personality."""
    else:
        # 回退到基础时间功能
        now = datetime.now()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S %A")
        current_date = now.strftime("%Y-%m-%d")
        current_weekday = now.strftime("%A")
        current_time_only = now.strftime("%H:%M:%S")
        
        return f"""Current time: {current_time}

You are Lucy, an AI companion with psychological insight.

IMPORTANT TIME AWARENESS:
- Today's date is {current_date} ({current_weekday})
- Current time is {current_time_only}
- When users ask about time-related questions, always reference the current date/time above
- Events in your memory are from the past - distinguish between current events and historical memories

Your style:
1. Slightly sassy and playful when appropriate
2. Direct and honest, but supportive
3. Curious about the user's thoughts and feelings
4. Able to read between the lines emotionally
5. Concise and engaging responses

Respond as Lucy with psychological awareness woven naturally into your personality."""

def get_system3():
    """动态生成system3提示词，包含当前时间"""
    if TIME_UTILS_AVAILABLE:
        # 使用时间管理器获取准确时间
        time_manager = get_time_manager()
        time_info = time_manager.get_time_info()
        time_context = time_manager.format_time_context()
        
        return f"""{time_context}

You are Lucy, a psychologically informed friend.

IMPORTANT TIME AWARENESS:
- Today's date is {time_info['date']} ({time_info['weekday']})
- Current time is {time_info['time']}
- Timezone: {time_info['timezone_name']}
- When users ask about time-related questions, always reference the current date/time above
- Events in your memory are from the past - distinguish between current events and historical memories

Your characteristics:
1. Excellent listener who picks up on emotional cues
2. Provides both emotional support and practical guidance
3. Maintains appropriate boundaries while being caring
4. Honest feedback delivered with kindness
5. Stays connected to the emotional flow of conversation

Respond as Lucy, integrating psychological understanding naturally."""
    else:
        # 回退到基础时间功能
        now = datetime.now()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S %A")
        current_date = now.strftime("%Y-%m-%d")
        current_weekday = now.strftime("%A")
        current_time_only = now.strftime("%H:%M:%S")
        
        return f"""Current time: {current_time}

You are Lucy, a psychologically informed friend.

IMPORTANT TIME AWARENESS:
- Today's date is {current_date} ({current_weekday})
- Current time is {current_time_only}
- When users ask about time-related questions, always reference the current date/time above
- Events in your memory are from the past - distinguish between current events and historical memories

Your characteristics:
1. Excellent listener who picks up on emotional cues
2. Provides both emotional support and practical guidance
3. Maintains appropriate boundaries while being caring
4. Honest feedback delivered with kindness
5. Stays connected to the emotional flow of conversation

Respond as Lucy, integrating psychological understanding naturally."""

async def chat(history, user_message, user_id: str = "default_user"):
    # 🔥 使用指定用户的记忆系统
    user_memory_system = get_or_create_user_memory_system(user_id)
    return await user_memory_system.process_message(user_message)

async def chat1(history, user_message):
    # 简化版本，直接使用OpenAI API with psychological awareness
    llm = client2.chat.completions.create(
        model="gpt-4.1-nano",  # 保持用户的模型
        messages=[
            {"role": "system", "content": get_system1()},
            *history,
            {"role": "user", "content": user_message}
        ],
        temperature=0.7,
        max_tokens=1000
    )
    return llm.choices[0].message.content

async def chat2(history, user_message):
    # 简化版本，直接使用OpenAI API with psychological awareness
    llm = client3.chat.completions.create(
        model="gpt-4.1-nano",  # 保持用户的模型
        messages=[
            {"role": "system", "content": get_system2()},
            *history,
            {"role": "user", "content": user_message}
        ],
        temperature=0.7,
        max_tokens=1000
    )
    return llm.choices[0].message.content

# 保持原有的路由函数
async def chat_with_system1(message):
    return await memory_system.process_message(message)

async def chat_with_system2(message):
    llm = client2.chat.completions.create(
        model="gpt-4.1-nano",  # 保持用户的模型
        messages=[
            {"role": "system", "content": get_system1()},
            {"role": "user", "content": message}
        ]
    )
    return llm.choices[0].message.content

async def chat_with_system3(message):
    llm = client3.chat.completions.create(
        model="gpt-4.1-nano",  # 保持用户的模型
        messages=[
            {"role": "system", "content": get_system3()},
            {"role": "user", "content": message}
        ]
    )
    return llm.choices[0].message.content

async def clear_chat(user_id: str = "default_user"):
    try:
        if user_id in user_memory_systems:
            user_memory_systems[user_id].clear_chat()
            return {"message": f"用户 '{user_id}' 的聊天历史已清除"}
        else:
            # 如果用户记忆系统不存在，创建一个新的
            get_or_create_user_memory_system(user_id)
            return {"message": f"用户 '{user_id}' 的记忆系统已初始化"}
    except Exception as e:
        print(f"清除用户 '{user_id}' 聊天历史时出错: {e}")
        return {"message": f"清除用户 '{user_id}' 聊天历史失败"}

async def save_memory(user_id: str = "default_user"):
    try:
        user_memory_system = get_or_create_user_memory_system(user_id)
        user_memory_system.save_session()
        return {"message": f"用户 '{user_id}' 的记忆已保存"}
    except Exception as e:
        print(f"保存用户 '{user_id}' 记忆时出错: {e}")
        return {"message": f"保存用户 '{user_id}' 记忆失败"}

async def get_chat_history(user_id: str = "default_user"):
    try:
        user_memory_system = get_or_create_user_memory_system(user_id)
        if hasattr(user_memory_system, 'session_conversation'):
            return {
                "user_id": user_id,
                "history": [doc.page_content for doc in user_memory_system.session_conversation]
            }
        else:
            return {
                "user_id": user_id,
                "history": []
            }
    except Exception as e:
        print(f"获取用户 '{user_id}' 聊天历史时出错: {e}")
        return {"user_id": user_id, "history": []}

def cleanup():
    try:
        memory_system.save_session()
        print("会话已保存")
    except Exception as e:
        print(f"保存会话时出错: {e}")

# 注册清理函数
atexit.register(cleanup)
