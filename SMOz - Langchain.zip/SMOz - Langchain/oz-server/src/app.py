import json
import datetime
import asyncio
import requests
import os
from fastapi import FastAPI, WebSocket
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

from .detect import detect, detectanl
from .chat import chat, chat1, chat2, memory_system, get_or_create_user_memory_system
from .summary import summarize
from .refine import refine_msg
from .config import FeatureFlags

app = FastAPI()

# 🔥 添加静态文件服务
app.mount("/src", StaticFiles(directory="src"), name="src")

multi = False

class UserQuery(BaseModel):
    query: str
    user_id: str = "default_user"  # 🔥 新增用户ID字段，默认值为default_user

# 🔥 用户记忆系统管理器 - 使用chat.py中的统一管理
# 移除重复定义，使用chat.py中的get_or_create_user_memory_system

chat_history = []
active_connections = []


class ConnectionManager:
    def __init__(self):
        self.active_connections = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            await connection.send_text(message)


manager = ConnectionManager()

chat_history = []

file_name = ""


async def save_chat_history(message):
    global file_name
    # 🔥 确保使用正确的数据目录路径
    current_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 从src目录向上两级
    project_root = os.path.dirname(current_dir)  # 再向上一级到项目根目录
    data_dir = os.path.join(project_root, "sm-docker-local", "data")
    
    # 确保 data 目录存在
    os.makedirs(data_dir, exist_ok=True)
    with open(file_name, "a") as f:
        json.dump(message, f)
        f.write("\n")  # 每条记录之间换行，方便阅读

@app.post("/generate")
async def generate(userQuery: UserQuery):
    global file_name
    print(f"🔥 用户 '{userQuery.user_id}' 发送消息: {userQuery.query}")
    # 🔥 使用本地时间确保时区一致性
    now = datetime.datetime.now()
    time_str = now.isoformat()  # 使用本地时间
    file_time_str = now.strftime("%m-%d_%H-%M-%S")  # 文件名用的时间格式
    
    # 🔥 为每个用户创建独立的聊天历史文件，使用正确的数据目录
    current_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 从src目录向上两级
    project_root = os.path.dirname(current_dir)  # 再向上一级到项目根目录
    data_dir = os.path.join(project_root, "sm-docker-local", "data")
    user_file_name = os.path.join(data_dir, f"chat_history_{userQuery.user_id}_{file_time_str}.json")
    
    # 如果 file_name 为空，设置一个新的文件名
    if not file_name:
        file_name = user_file_name
    
    chat_history.append({
        "role": "user",
        "content": userQuery.query,
        "timestamp": time_str,
        "user_id": userQuery.user_id  # 🔥 添加用户ID到历史记录
    })

    if(multi):
        # 根据配置决定是否启用detect功能
        tasks = []
        
        if FeatureFlags.ENABLE_DETECT:
            tasks.extend([detect(userQuery.query), detectanl(userQuery.query)])
        
        # 🔥 chat功能传递用户ID
        tasks.extend([
            chat(chat_history, userQuery.query, userQuery.user_id),  # 传递用户ID
            chat1(chat_history, userQuery.query),  # 第二个chat响应
            chat2(chat_history, userQuery.query),  # 第三个chat响应
        ])
        
        # 保存聊天记录
        tasks.append(save_chat_history({
            "role": "user",
            "content": userQuery.query,
            "timestamp": time_str,
            "user_id": userQuery.user_id  # 🔥 保存用户ID
        }))
        
        results = await asyncio.gather(*tasks)
        
        # 根据是否启用detect功能来解析结果
        if FeatureFlags.ENABLE_DETECT:
            detected, detectinfo, responsea, responseb, responsec = results[0], results[1], results[2], results[3], results[4]
        else:
            detected, detectinfo = "低敏感", "检测功能已禁用"
            responsea, responseb, responsec = results[0], results[1], results[2]

        res = {
            "human_message": userQuery.query,
            "ai_message_one": responsea,
            "ai_message_two": responseb,
            "ai_message_three": responsec,
            "sensitivity": detected,
            "explanation": detectinfo,
            "user_id": userQuery.user_id,  # 🔥 返回用户ID
            "timestamp": time_str  # 🔥 添加服务器时间戳
        }
        print("sending response", res)
        await manager.broadcast(json.dumps(res))
    else:
        # 根据配置决定是否启用detect功能
        tasks = []
        
        if FeatureFlags.ENABLE_DETECT:
            tasks.extend([detect(userQuery.query), detectanl(userQuery.query)])
            
        # 🔥 chat功能传递用户ID
        tasks.append(chat(chat_history, userQuery.query, userQuery.user_id))
        
        # 保存聊天记录
        tasks.append(save_chat_history({
            "role": "user",
            "content": userQuery.query,
            "timestamp": time_str,
            "user_id": userQuery.user_id  # 🔥 保存用户ID
        }))
        
        results = await asyncio.gather(*tasks)
        
        # 根据是否启用detect功能来解析结果
        if FeatureFlags.ENABLE_DETECT:
            detected, detectinfo, responsea = results[0], results[1], results[2]
        else:
            detected, detectinfo = "低敏感", "检测功能已禁用"
            responsea = results[0]

        # 将AI响应也添加到chat_history
        chat_history.append({
            "role": "assistant", 
            "content": responsea,
            "timestamp": time_str,
            "user_id": userQuery.user_id  # 🔥 添加用户ID
        })

        res = {
            "human_message": userQuery.query,
            "ai_proposed_message": responsea,
            "sensitivity": detected,
            "explanation": detectinfo,
            "user_id": userQuery.user_id,  # 🔥 返回用户ID
            "timestamp": time_str  # 🔥 添加服务器时间戳
        }
        print("sending response", res)
        await manager.broadcast(json.dumps(res))

@app.get("/history")
async def get_history():
    return chat_history


# 新增：获取当前功能开关状态
@app.get("/feature-flags")
async def get_feature_flags():
    """获取当前的功能开关配置"""
    return FeatureFlags.to_dict()


# 新增：更新功能开关配置
@app.post("/feature-flags")
async def update_feature_flags(flags: dict):
    """更新功能开关配置"""
    FeatureFlags.update_from_dict(flags)
    return {"message": "功能开关已更新", "current_flags": FeatureFlags.to_dict()}


# 新增：记忆系统状态API
@app.get("/memory-status")
async def get_memory_status():
    """获取记忆系统状态和统计信息"""
    try:
        stats = memory_system.get_memory_stats()
        return {
            "status": "success",
            "memory_system": stats
        }
    except Exception as e:
        return {
            "status": "error", 
            "message": f"获取记忆状态失败: {str(e)}"
        }

# 🔥 新增：多用户记忆系统状态API
@app.get("/memory-status/{user_id}")
async def get_user_memory_status(user_id: str):
    """获取指定用户的记忆系统状态和统计信息"""
    try:
        user_memory_system = get_or_create_user_memory_system(user_id)
        stats = user_memory_system.get_memory_stats()
        return {
            "status": "success",
            "user_id": user_id,
            "memory_system": stats
        }
    except Exception as e:
        return {
            "status": "error", 
            "user_id": user_id,
            "message": f"获取用户 '{user_id}' 记忆状态失败: {str(e)}"
        }

# 🔥 新增：获取所有用户列表API
@app.get("/users")
async def get_all_users():
    """获取所有用户的列表和统计信息"""
    try:
        users_info = []
        for user_id, memory_sys in user_memory_systems.items():
            stats = memory_sys.get_memory_stats()
            users_info.append({
                "user_id": user_id,
                "total_conversations": stats.get("total_conversations", 0),
                "companion_days": stats.get("companion_days", 0),
                "memory_type": getattr(memory_sys, 'memory_type', 'hybrid')
            })
        
        return {
            "status": "success",
            "total_users": len(user_memory_systems),
            "users": users_info
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"获取用户列表失败: {str(e)}"
        }

# 新增：强制保存记忆API
@app.post("/memory-save")
async def save_memory_endpoint():
    """手动保存当前记忆状态"""
    try:
        memory_system.save_session()
        return {"message": "记忆已保存", "timestamp": datetime.datetime.now().isoformat()}
    except Exception as e:
        return {"message": f"保存记忆失败: {str(e)}"}

# 🔥 新增：保存特定用户记忆API
@app.post("/memory-save/{user_id}")
async def save_user_memory_endpoint(user_id: str):
    """手动保存指定用户的记忆状态"""
    try:
        # 获取或创建用户记忆系统
        user_memory_system = get_or_create_user_memory_system(user_id)
        user_memory_system.save_session()
        return {
            "message": f"用户 '{user_id}' 的记忆已保存", 
            "user_id": user_id,
            "timestamp": datetime.datetime.now().isoformat()
        }
    except Exception as e:
        return {
            "message": f"保存用户 '{user_id}' 记忆失败: {str(e)}",
            "user_id": user_id
        }

# 🔥 新增：清除特定用户记忆API
@app.post("/memory-clear/{user_id}")
async def clear_user_memory_endpoint(user_id: str):
    """清除指定用户的记忆"""
    try:
        # 从chat.py导入用户记忆系统字典
        from .chat import user_memory_systems
        if user_id in user_memory_systems:
            user_memory_systems[user_id].clear_chat()
            return {
                "message": f"用户 '{user_id}' 的记忆已清除",
                "user_id": user_id
            }
        else:
            return {
                "message": f"用户 '{user_id}' 的记忆系统不存在",
                "user_id": user_id
            }
    except Exception as e:
        return {
            "message": f"清除用户 '{user_id}' 记忆失败: {str(e)}",
            "user_id": user_id
        }

# 新增：切换记忆系统类型API
@app.post("/memory-switch")
async def switch_memory_system(use_enhanced: bool = True):
    """切换记忆系统类型（需要重启生效）"""
    try:
        # 保存当前会话
        memory_system.save_session()
        
        return {
            "message": f"已请求切换到{'增强' if use_enhanced else '基础'}记忆系统",
            "note": "需要重启服务器才能生效",
            "current_type": memory_system.memory_type
        }
    except Exception as e:
        return {"message": f"切换记忆系统失败: {str(e)}"}


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    global file_name
    await manager.connect(websocket)
    print("connected")
    # 🔥 使用本地时间确保时区一致性
    now = datetime.datetime.now()
    time_str = now.isoformat()  # 使用本地时间
    file_time_str = now.strftime("%m-%d_%H-%M-%S")  # 文件名用的时间格式
    
    # 🔥 修改文件保存路径，保存到memory目录中
    current_file = os.path.abspath(__file__)  # app.py的绝对路径
    src_dir = os.path.dirname(current_file)   # src目录
    oz_server_dir = os.path.dirname(src_dir)  # oz-server目录
    project_root = os.path.dirname(oz_server_dir)  # 项目根目录 (SMOz - Langchain)
    memory_dir = os.path.join(project_root, "sm-docker-local", "data", "memory", "default_user", "chat_logs")
    os.makedirs(memory_dir, exist_ok=True)
    file_name = os.path.join(memory_dir, f"websocket_chat_{file_time_str}.json")

    try:
        while True:
            data = await websocket.receive_text()
            data = json.loads(data)
            if data["kind"] == "refine":
                # 检查是否启用refine功能
                if FeatureFlags.ENABLE_REFINE:
                    input = data["message"]
                    response = await refine_msg(chat_history, input)
                    await manager.broadcast(json.dumps({
                        "kind": "refined",
                        "message": response,
                    }))
                else:
                    # 如果refine功能被禁用，返回原始消息
                    await manager.broadcast(json.dumps({
                        "kind": "refined",
                        "message": data["message"],  # 返回原始消息不做修改
                    }))
            elif data["kind"] == "save_memory":
                # 处理记忆保存请求
                try:
                    memory_system.save_session()
                    await manager.broadcast(json.dumps({
                        "kind": "memory_saved",
                        "message": "记忆已保存",
                        "timestamp": datetime.datetime.now().isoformat(),
                        "success": True
                    }))
                except Exception as e:
                    await manager.broadcast(json.dumps({
                        "kind": "memory_save_error",
                        "message": f"保存记忆失败: {str(e)}",
                        "success": False
                    }))
            elif data["kind"] == "message" and data.get("intervene") == False:
                # 🔥 处理用户提交的最终响应
                final_message = data["message"]
                # 🔥 使用本地时间确保时区一致性
                now = datetime.datetime.now()
                time_str = now.isoformat()  # 使用本地时间
                
                # 将最终响应添加到聊天历史
                chat_history.append({
                    "role": "assistant",
                    "content": final_message,
                    "timestamp": time_str,
                })
                
                # 保存最终响应
                await save_chat_history({
                    "role": "assistant",
                    "content": final_message,
                    "timestamp": time_str,
                })
                
                # 🔥 发送最终响应到前端，确保时间戳一致性
                await manager.broadcast(json.dumps({
                    "kind": "final_response",
                    "message": final_message,
                    "timestamp": time_str,
                    "sender": "Digital Human"
                }))
                
                # 🔥 将最终响应也保存到记忆系统中
                try:
                    user_memory_system = get_or_create_user_memory_system("default_user")
                    # 如果有最近的用户消息，将其与AI回复一起保存到记忆系统
                    if chat_history and len(chat_history) >= 2:
                        recent_user_msg = chat_history[-2]  # 倒数第二条应该是用户消息
                        if recent_user_msg.get("role") == "user":
                            user_memory_system.add_to_memory(recent_user_msg["content"], final_message)
                            print(f"💾 最终响应已保存到记忆系统")
                except Exception as e:
                    print(f"保存最终响应到记忆系统失败: {e}")
                
                # 发送到orchestration服务器
                try:
                    requests.post("http://orchestration-server:8080/event", json={"body": {
                        "text": final_message
                    }}, timeout=5)
                except Exception as e:
                    print(f"发送到orchestration服务器失败: {e}")
                
                # 🔥 生成并发送摘要（如果启用）
                if FeatureFlags.ENABLE_SUMMARY:
                    summary = summarize(chat_history)
                    await manager.broadcast(json.dumps({
                        "kind": "summary",
                        "summary": summary,
                    }))
                else:
                    await manager.broadcast(json.dumps({
                        "kind": "summary",
                        "summary": "总结功能已禁用",
                    }))
            else:
                # 🔥 处理其他类型的消息（如用户原始输入）
                user_message = data["message"]
                # 🔥 使用本地时间确保时区一致性
                now = datetime.datetime.now()
                time_str = now.isoformat()  # 使用本地时间
                
                # 将用户消息添加到聊天历史
                chat_history.append({
                    "role": "user",
                    "content": user_message,
                    "timestamp": time_str,
                })
                
                # 保存用户消息
                await save_chat_history({
                    "role": "user",
                    "content": user_message,
                    "timestamp": time_str,
                })
                
                # 🔥 生成AI响应和敏感度检测
                tasks = []
                
                if FeatureFlags.ENABLE_DETECT:
                    tasks.extend([detect(user_message), detectanl(user_message)])
                
                # 生成AI响应（使用默认用户ID）
                tasks.append(chat(chat_history, user_message, "default_user"))
                
                results = await asyncio.gather(*tasks)
                
                # 解析结果
                if FeatureFlags.ENABLE_DETECT:
                    detected, detectinfo, ai_response = results[0], results[1], results[2]
                else:
                    detected, detectinfo = "低敏感", "检测功能已禁用"
                    ai_response = results[0]
                
                # 🔥 向前端发送完整响应（包含时间戳）
                response_data = {
                    "human_message": user_message,
                    "ai_proposed_message": ai_response,
                    "sensitivity": detected,
                    "explanation": detectinfo,
                    "timestamp": time_str  # 🔥 添加服务器时间戳
                }
                
                await manager.broadcast(json.dumps(response_data))
    except Exception as e:
        manager.disconnect(websocket)  # Ensure to remove on disconnect/error
        chat_history.clear()

    # 1. detect the sensitivity of the user input
    # 2. response the user input
    # 3. summarize the conversation
    # 4. repeat the user input

# 🔥 添加HTML文件路由
@app.get("/")
async def serve_index():
    """提供主页面"""
    return FileResponse("index_new.html")

@app.get("/index")
async def serve_index_alt():
    """提供主页面（备用路径）"""
    return FileResponse("index_new.html")

@app.get("/multi")
async def serve_multi():
    """提供多用户页面"""
    return FileResponse("multi.html")

@app.get("/multiuser")
async def serve_multiuser():
    """提供多用户页面"""
    return FileResponse("multiuser.html")



