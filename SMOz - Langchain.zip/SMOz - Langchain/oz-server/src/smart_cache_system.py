"""
智能缓存系统 - 延迟优化策略3
通过预测和缓存优化响应速度
"""

import asyncio
import json
import hashlib
import time
import pickle
import os
from typing import Dict, List, Optional, Tuple
from collections import defaultdict, OrderedDict
from datetime import datetime, timedelta
import threading
from concurrent.futures import ThreadPoolExecutor

class SmartCacheSystem:
    """
    智能缓存系统
    
    功能特性：
    1. 响应缓存 - 缓存相同/相似查询的回复
    2. 上下文缓存 - 缓存记忆检索结果
    3. 预加载系统 - 后台预生成常见回复
    4. 语义相似度匹配 - 基于内容相似性的缓存命中
    5. 自适应缓存策略 - 根据使用模式调整缓存
    """
    
    def __init__(self, cache_dir: str = "cache", max_cache_size: int = 1000):
        self.cache_dir = cache_dir
        self.max_cache_size = max_cache_size
        
        # 确保缓存目录存在
        os.makedirs(cache_dir, exist_ok=True)
        
        # 多层缓存系统
        self.response_cache = OrderedDict()  # 精确匹配缓存
        self.semantic_cache = OrderedDict()  # 语义相似度缓存
        self.context_cache = OrderedDict()   # 上下文缓存
        self.preloaded_responses = {}        # 预加载回复
        
        # 缓存统计
        self.cache_stats = {
            "hits": 0,
            "misses": 0,
            "semantic_hits": 0,
            "preload_hits": 0,
            "total_requests": 0
        }
        
        # 使用模式分析
        self.usage_patterns = defaultdict(int)
        self.response_times = {}
        self.similarity_threshold = 0.85  # 语义相似度阈值
        
        # 线程池用于后台任务
        self.executor = ThreadPoolExecutor(max_workers=2)
        
        # 加载持久化缓存
        self.load_persistent_cache()
        
        # 启动预加载任务
        asyncio.create_task(self.start_preloading())
        
        print(f"🧠 SmartCacheSystem initialized with {len(self.response_cache)} cached responses")
    
    def generate_cache_key(self, user_input: str, context_hash: str = "") -> str:
        """生成缓存键"""
        # 标准化输入
        normalized_input = user_input.lower().strip()
        
        # 移除常见的变化词汇
        stop_words = ["please", "can you", "could you", "would you", "um", "uh", "well"]
        words = normalized_input.split()
        filtered_words = [w for w in words if w not in stop_words]
        clean_input = " ".join(filtered_words)
        
        # 生成哈希键
        content = f"{clean_input}_{context_hash}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def calculate_semantic_similarity(self, text1: str, text2: str) -> float:
        """
        计算语义相似度 (简化版本)
        在生产环境中可以使用更sophisticated的embeddings
        """
        # 简单的词汇重叠相似度
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1.intersection(words2)
        union = words1.union(words2)
        
        jaccard_similarity = len(intersection) / len(union)
        
        # 额外考虑词序和长度
        length_similarity = 1 - abs(len(text1) - len(text2)) / max(len(text1), len(text2))
        
        return (jaccard_similarity * 0.7 + length_similarity * 0.3)
    
    async def get_cached_response(self, user_input: str, context_hash: str = "") -> Optional[Dict]:
        """
        获取缓存的响应
        
        返回: {
            "response": str,
            "cache_type": str,
            "similarity": float,
            "cached_at": datetime,
            "hit_count": int
        }
        """
        self.cache_stats["total_requests"] += 1
        start_time = time.time()
        
        cache_key = self.generate_cache_key(user_input, context_hash)
        
        # 1. 精确匹配检查
        if cache_key in self.response_cache:
            result = self.response_cache[cache_key]
            result["cache_type"] = "exact"
            result["similarity"] = 1.0
            result["hit_count"] = result.get("hit_count", 0) + 1
            
            # 移动到最近使用位置 (LRU)
            self.response_cache.move_to_end(cache_key)
            
            self.cache_stats["hits"] += 1
            self.record_response_time("cache_hit", time.time() - start_time)
            
            print(f"🎯 精确缓存命中: {user_input[:30]}...")
            return result
        
        # 2. 语义相似度匹配
        best_match = await self.find_semantic_match(user_input)
        if best_match:
            self.cache_stats["semantic_hits"] += 1
            self.record_response_time("semantic_hit", time.time() - start_time)
            
            print(f"🔍 语义缓存命中: {user_input[:30]}... (相似度: {best_match['similarity']:.2f})")
            return best_match
        
        # 3. 预加载响应检查
        preload_response = self.check_preloaded_responses(user_input)
        if preload_response:
            self.cache_stats["preload_hits"] += 1
            self.record_response_time("preload_hit", time.time() - start_time)
            
            print(f"⚡ 预加载命中: {user_input[:30]}...")
            return preload_response
        
        # 4. 缓存未命中
        self.cache_stats["misses"] += 1
        self.record_response_time("cache_miss", time.time() - start_time)
        
        # 记录使用模式
        self.usage_patterns[user_input.lower()[:50]] += 1
        
        return None
    
    async def find_semantic_match(self, user_input: str) -> Optional[Dict]:
        """查找语义相似的缓存回复"""
        
        best_similarity = 0
        best_match = None
        
        # 在缓存中搜索相似回复
        for cache_key, cached_data in list(self.response_cache.items())[-100:]:  # 检查最近100条
            cached_input = cached_data.get("original_input", "")
            
            if cached_input:
                similarity = self.calculate_semantic_similarity(user_input, cached_input)
                
                if similarity > self.similarity_threshold and similarity > best_similarity:
                    best_similarity = similarity
                    best_match = {
                        **cached_data,
                        "cache_type": "semantic",
                        "similarity": similarity,
                        "original_match": cached_input
                    }
        
        return best_match
    
    def check_preloaded_responses(self, user_input: str) -> Optional[Dict]:
        """检查预加载的响应"""
        
        # 检查预设的快速回复
        quick_patterns = {
            "greeting": ["hi", "hello", "hey", "good morning", "good evening"],
            "thanks": ["thank", "thanks", "thx", "appreciate"],
            "goodbye": ["bye", "goodbye", "see you", "gotta go"],
            "how_are_you": ["how are you", "how's it going", "what's up"],
            "good": ["good", "great", "excellent", "wonderful", "fine"],
            "bad": ["bad", "terrible", "awful", "sad", "depressed"]
        }
        
        user_lower = user_input.lower()
        
        for pattern_type, patterns in quick_patterns.items():
            if any(pattern in user_lower for pattern in patterns):
                if pattern_type in self.preloaded_responses:
                    response_data = self.preloaded_responses[pattern_type]
                    return {
                        "response": response_data["response"],
                        "cache_type": "preloaded",
                        "similarity": 1.0,
                        "pattern_type": pattern_type,
                        "cached_at": response_data["created_at"]
                    }
        
        return None
    
    async def cache_response(self, user_input: str, response: str, context_hash: str = "", 
                           metadata: Dict = None):
        """缓存响应"""
        
        cache_key = self.generate_cache_key(user_input, context_hash)
        
        cache_data = {
            "response": response,
            "original_input": user_input,
            "context_hash": context_hash,
            "cached_at": datetime.now().isoformat(),
            "hit_count": 0,
            "metadata": metadata or {}
        }
        
        # 添加到缓存
        self.response_cache[cache_key] = cache_data
        
        # 维护缓存大小
        await self.maintain_cache_size()
        
        # 异步保存到磁盘
        self.executor.submit(self.save_to_disk, cache_key, cache_data)
        
        print(f"💾 响应已缓存: {user_input[:30]}...")
    
    async def maintain_cache_size(self):
        """维护缓存大小 (LRU策略)"""
        
        while len(self.response_cache) > self.max_cache_size:
            # 移除最老的条目
            oldest_key = next(iter(self.response_cache))
            removed_item = self.response_cache.pop(oldest_key)
            
            print(f"🗑️ 缓存条目已移除: {removed_item['original_input'][:20]}...")
    
    async def start_preloading(self):
        """启动预加载任务"""
        
        print("🔄 开始预加载常见响应...")
        
        # 定义常见的预加载回复
        preload_configs = {
            "greeting": {
                "responses": [
                    "Hi there! How's your day going?",
                    "Hello! Great to see you again!",
                    "Hey! What's on your mind today?"
                ],
                "priority": 1
            },
            "thanks": {
                "responses": [
                    "You're welcome! Happy to help!",
                    "Anytime! That's what I'm here for.",
                    "Of course! Glad I could help."
                ],
                "priority": 1
            },
            "how_are_you": {
                "responses": [
                    "I'm doing well, thanks for asking! How about you?",
                    "I'm here and ready to chat! How are you feeling?",
                    "I'm good! What's been going on with you lately?"
                ],
                "priority": 2
            },
            "goodbye": {
                "responses": [
                    "Take care! I'll be here when you're ready to chat.",
                    "See you later! Hope you have a great day!",
                    "Goodbye! Looking forward to our next conversation."
                ],
                "priority": 2
            }
        }
        
        # 预加载响应
        import random
        for pattern_type, config in preload_configs.items():
            response = random.choice(config["responses"])
            self.preloaded_responses[pattern_type] = {
                "response": response,
                "created_at": datetime.now().isoformat(),
                "priority": config["priority"]
            }
        
        print(f"✅ 预加载完成: {len(self.preloaded_responses)} 个响应")
    
    def get_contextual_cache(self, query: str) -> Optional[str]:
        """获取上下文缓存"""
        
        context_key = hashlib.md5(query.encode()).hexdigest()
        
        if context_key in self.context_cache:
            context_data = self.context_cache[context_key]
            
            # 检查缓存是否过期 (5分钟)
            cached_time = datetime.fromisoformat(context_data["cached_at"])
            if datetime.now() - cached_time < timedelta(minutes=5):
                print(f"📚 上下文缓存命中: {query[:20]}...")
                return context_data["context"]
        
        return None
    
    def cache_context(self, query: str, context: str):
        """缓存上下文"""
        
        context_key = hashlib.md5(query.encode()).hexdigest()
        
        self.context_cache[context_key] = {
            "context": context,
            "cached_at": datetime.now().isoformat(),
            "query": query
        }
        
        # 维护上下文缓存大小
        if len(self.context_cache) > 100:
            oldest_key = next(iter(self.context_cache))
            self.context_cache.pop(oldest_key)
        
        print(f"🗃️ 上下文已缓存: {query[:20]}...")
    
    def record_response_time(self, operation: str, time_taken: float):
        """记录响应时间"""
        
        if operation not in self.response_times:
            self.response_times[operation] = []
        
        self.response_times[operation].append(time_taken)
        
        # 保持最近100条记录
        if len(self.response_times[operation]) > 100:
            self.response_times[operation] = self.response_times[operation][-100:]
    
    def get_cache_statistics(self) -> Dict:
        """获取缓存统计信息"""
        
        total_requests = self.cache_stats["total_requests"]
        if total_requests == 0:
            return {"message": "No cache requests yet"}
        
        hit_rate = (self.cache_stats["hits"] + self.cache_stats["semantic_hits"] + 
                   self.cache_stats["preload_hits"]) / total_requests
        
        avg_times = {}
        for operation, times in self.response_times.items():
            if times:
                avg_times[operation] = f"{(sum(times) / len(times) * 1000):.1f}ms"
        
        return {
            "total_requests": total_requests,
            "cache_hit_rate": f"{hit_rate:.1%}",
            "exact_hits": self.cache_stats["hits"],
            "semantic_hits": self.cache_stats["semantic_hits"],
            "preload_hits": self.cache_stats["preload_hits"],
            "cache_misses": self.cache_stats["misses"],
            "cached_responses": len(self.response_cache),
            "preloaded_responses": len(self.preloaded_responses),
            "context_cache_size": len(self.context_cache),
            "average_response_times": avg_times,
            "top_usage_patterns": dict(sorted(
                self.usage_patterns.items(), 
                key=lambda x: x[1], 
                reverse=True
            )[:5])
        }
    
    def save_to_disk(self, cache_key: str, cache_data: Dict):
        """保存缓存到磁盘"""
        
        try:
            cache_file = os.path.join(self.cache_dir, f"{cache_key}.json")
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存缓存失败: {e}")
    
    def load_persistent_cache(self):
        """加载持久化缓存"""
        
        try:
            if not os.path.exists(self.cache_dir):
                return
            
            cache_files = [f for f in os.listdir(self.cache_dir) if f.endswith('.json')]
            loaded_count = 0
            
            for cache_file in cache_files[:self.max_cache_size]:  # 限制加载数量
                try:
                    cache_path = os.path.join(self.cache_dir, cache_file)
                    with open(cache_path, 'r', encoding='utf-8') as f:
                        cache_data = json.load(f)
                    
                    cache_key = cache_file.replace('.json', '')
                    self.response_cache[cache_key] = cache_data
                    loaded_count += 1
                    
                except Exception as e:
                    print(f"加载缓存文件失败 {cache_file}: {e}")
                    continue
            
            print(f"📂 已加载 {loaded_count} 个持久化缓存条目")
            
        except Exception as e:
            print(f"加载持久化缓存失败: {e}")
    
    async def optimize_cache(self):
        """优化缓存策略"""
        
        print("🔧 开始缓存优化...")
        
        # 1. 清理过期的上下文缓存
        current_time = datetime.now()
        expired_keys = []
        
        for key, data in self.context_cache.items():
            cached_time = datetime.fromisoformat(data["cached_at"])
            if current_time - cached_time > timedelta(hours=1):
                expired_keys.append(key)
        
        for key in expired_keys:
            self.context_cache.pop(key)
        
        # 2. 调整相似度阈值
        semantic_hit_rate = self.cache_stats["semantic_hits"] / max(self.cache_stats["total_requests"], 1)
        if semantic_hit_rate < 0.1:  # 语义匹配率过低
            self.similarity_threshold = max(0.75, self.similarity_threshold - 0.05)
        elif semantic_hit_rate > 0.3:  # 语义匹配率过高
            self.similarity_threshold = min(0.95, self.similarity_threshold + 0.05)
        
        # 3. 更新预加载响应
        await self.update_preloaded_responses()
        
        print(f"🔧 缓存优化完成. 相似度阈值: {self.similarity_threshold:.2f}")
    
    async def update_preloaded_responses(self):
        """更新预加载响应"""
        
        # 基于使用模式更新预加载响应
        popular_patterns = sorted(
            self.usage_patterns.items(), 
            key=lambda x: x[1], 
            reverse=True
        )[:10]
        
        print(f"📊 热门使用模式: {[p[0][:20] for p in popular_patterns[:3]]}")
    
    def clear_cache(self, cache_type: str = "all"):
        """清空缓存"""
        
        if cache_type == "all" or cache_type == "response":
            self.response_cache.clear()
            print("🗑️ 响应缓存已清空")
        
        if cache_type == "all" or cache_type == "context":
            self.context_cache.clear()
            print("🗑️ 上下文缓存已清空")
        
        if cache_type == "all" or cache_type == "preload":
            self.preloaded_responses.clear()
            print("🗑️ 预加载响应已清空")
        
        if cache_type == "all":
            # 清空磁盘缓存
            try:
                import shutil
                if os.path.exists(self.cache_dir):
                    shutil.rmtree(self.cache_dir)
                    os.makedirs(self.cache_dir, exist_ok=True)
                print("🗑️ 磁盘缓存已清空")
            except Exception as e:
                print(f"清空磁盘缓存失败: {e}")


# 全局缓存实例
smart_cache = SmartCacheSystem()

# 导出主要函数
async def get_cached_response(user_input: str, context_hash: str = "") -> Optional[Dict]:
    return await smart_cache.get_cached_response(user_input, context_hash)

async def cache_response(user_input: str, response: str, context_hash: str = "", metadata: Dict = None):
    await smart_cache.cache_response(user_input, response, context_hash, metadata)

def get_cache_stats() -> Dict:
    return smart_cache.get_cache_statistics()

async def optimize_cache():
    await smart_cache.optimize_cache() 