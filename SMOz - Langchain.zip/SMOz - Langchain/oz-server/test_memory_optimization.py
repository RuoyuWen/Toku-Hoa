#!/usr/bin/env python3
"""
记忆系统优化测试脚本
验证三层记忆的正确分工和清理机制
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.memory_system_enhanced import EnhancedMemorySystem
import asyncio


async def test_memory_optimization():
    """测试记忆系统优化功能"""
    
    print("🧪 开始测试优化后的记忆系统...")
    
    # 创建测试用户的记忆系统
    memory_system = EnhancedMemorySystem(
        user_id="test_optimization",
        test_mode=True  # 使用测试模式，不依赖外部API
    )
    
    print("\n" + "="*60)
    print("📝 第一阶段：测试基础对话存储")
    print("="*60)
    
    # 添加一些测试对话
    test_conversations = [
        ("Hi, my name is Alice", "Nice to meet you Alice!"),
        ("I work as a software engineer", "That sounds interesting!"),
        ("I love programming and reading", "Great hobbies!"),
        ("How are you today?", "I'm doing well, thanks!"),
        ("What's the weather like?", "I don't have access to weather data."),
        ("I feel a bit stressed about work", "I understand that can be challenging."),
        ("My birthday is next month", "How exciting! When exactly?"),
        ("I enjoy hiking on weekends", "That's a wonderful way to stay active!"),
        ("Can you help me with coding?", "I'd be happy to help with programming questions!"),
        ("I'm learning Python recently", "Python is a great language to learn!"),
    ]
    
    for i, (user_msg, ai_msg) in enumerate(test_conversations, 1):
        print(f"添加对话 {i}: {user_msg[:30]}...")
        memory_system.add_conversation(user_msg, ai_msg)
        
        # 显示当前记忆状态
        if i % 5 == 0:
            await display_memory_status(memory_system, f"对话 {i} 后")
    
    print("\n" + "="*60)
    print("🔄 第二阶段：测试记忆压缩和清理")
    print("="*60)
    
    # 添加更多对话触发压缩
    additional_conversations = [
        ("I had a great weekend", "That's wonderful to hear!"),
        ("I visited a new restaurant", "What kind of food did they serve?"),
        ("I'm thinking about changing jobs", "That's a big decision!"),
        ("I like to travel", "Where would you like to go next?"),
        ("I have a cat named Whiskers", "Pets can be such great companions!"),
        ("I'm feeling better now", "I'm glad to hear that!"),
        ("What's your favorite book?", "I enjoy many different types of books!"),
        ("I went for a run this morning", "Exercise is great for both body and mind!"),
        ("I'm learning Japanese", "That's an interesting language to study!"),
        ("I love classical music", "Classical music can be very moving!"),
        ("I'm working on a new project", "Tell me more about your project!"),
        ("I made dinner for my friends", "That sounds like a lovely evening!"),
    ]
    
    for i, (user_msg, ai_msg) in enumerate(additional_conversations, 11):
        print(f"添加对话 {i}: {user_msg[:30]}...")
        memory_system.add_conversation(user_msg, ai_msg)
        
        # 在关键点显示记忆状态
        if i in [15, 20, 22]:
            await display_memory_status(memory_system, f"对话 {i} 后")
    
    print("\n" + "="*60)
    print("🔍 第三阶段：测试记忆检索")
    print("="*60)
    
    # 测试不同类型的查询
    test_queries = [
        "What's Alice's name?",
        "What does Alice work as?",
        "What are Alice's hobbies?",
        "Alice's birthday",
        "Alice's pet"
    ]
    
    for query in test_queries:
        print(f"\n查询: {query}")
        results = memory_system.smart_retrieval(query, k=3)
        
        print("检索结果:")
        for i, (doc, score, memory_type) in enumerate(results, 1):
            content_preview = doc.page_content[:100].replace('\n', ' ')
            print(f"  {i}. [{memory_type}] {content_preview}... (相似度: {score:.3f})")
    
    print("\n" + "="*60)
    print("📊 第四阶段：分析记忆分布")
    print("="*60)
    
    await analyze_memory_distribution(memory_system)
    
    print("\n" + "="*60)
    print("✅ 测试完成")
    print("="*60)
    

async def display_memory_status(memory_system, stage):
    """显示记忆系统状态"""
    print(f"\n📊 记忆状态 - {stage}")
    print("-" * 40)
    
    # 短期记忆
    short_count = len(memory_system.current_session)
    print(f"短期记忆: {short_count} 条对话")
    
    # 中期记忆
    try:
        medium_docs = memory_system.medium_term_store.similarity_search("", k=1000)
        medium_count = len(medium_docs)
        print(f"中期记忆: {medium_count} 条重要对话")
    except:
        print(f"中期记忆: 0 条重要对话")
    
    # 长期记忆
    try:
        long_docs = memory_system.long_term_store.similarity_search("", k=1000)
        long_count = len(long_docs)
        
        # 分类长期记忆
        profile_updates = len([doc for doc in long_docs if doc.metadata.get("type") == "user_profile_update"])
        behavioral_insights = len([doc for doc in long_docs if doc.metadata.get("type") == "behavioral_insight"])
        user_profiles = len([doc for doc in long_docs if doc.metadata.get("type") == "user_profile"])
        
        print(f"长期记忆: {long_count} 条档案信息")
        print(f"  - 用户档案更新: {profile_updates} 条")
        print(f"  - 行为洞察: {behavioral_insights} 条") 
        print(f"  - 用户画像: {user_profiles} 条")
    except:
        print(f"长期记忆: 0 条档案信息")


async def analyze_memory_distribution(memory_system):
    """分析记忆分布"""
    print("📈 记忆系统分析报告")
    print("-" * 40)
    
    # 分析短期记忆
    short_conversations = memory_system.current_session
    if short_conversations:
        avg_importance = sum(doc.metadata.get("importance", 0.5) for doc in short_conversations) / len(short_conversations)
        print(f"短期记忆平均重要性: {avg_importance:.3f}")
        
        personal_info_count = sum(1 for doc in short_conversations if doc.metadata.get("user_info"))
        print(f"包含个人信息的对话: {personal_info_count}/{len(short_conversations)}")
    
    # 分析中期记忆
    try:
        medium_docs = memory_system.medium_term_store.similarity_search("", k=1000)
        if medium_docs:
            avg_importance = sum(doc.metadata.get("importance", 0.5) for doc in medium_docs) / len(medium_docs)
            print(f"中期记忆平均重要性: {avg_importance:.3f}")
    except:
        pass
    
    # 分析长期记忆类型分布
    try:
        long_docs = memory_system.long_term_store.similarity_search("", k=1000)
        if long_docs:
            type_distribution = {}
            for doc in long_docs:
                doc_type = doc.metadata.get("type", "unknown")
                type_distribution[doc_type] = type_distribution.get(doc_type, 0) + 1
            
            print("长期记忆类型分布:")
            for doc_type, count in type_distribution.items():
                print(f"  - {doc_type}: {count} 条")
    except:
        pass


if __name__ == "__main__":
    asyncio.run(test_memory_optimization()) 