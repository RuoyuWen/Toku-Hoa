# 功能开关使用说明

## 概述

为了减少延迟并提供更好的用户体验，我们添加了功能开关来控制是否启用某些可选功能。目前支持控制以下功能：

- **detect**: 敏感性检测功能
- **refine**: 消息优化功能  
- **summary**: 对话总结功能

## 当前设置

所有功能目前都设置为**禁用状态**以减少响应延迟，只保留核心的chat功能。

## 配置方式

### 1. 通过配置文件（推荐）

编辑 `src/config.py` 文件中的 `FeatureFlags` 类：

```python
class FeatureFlags:
    ENABLE_DETECT = False   # 设置为 True 启用敏感性检测
    ENABLE_REFINE = False   # 设置为 True 启用消息优化
    ENABLE_SUMMARY = False  # 设置为 True 启用对话总结
```

### 2. 通过API接口（动态修改）

#### 获取当前配置
```bash
GET /feature-flags
```

#### 更新配置
```bash
POST /feature-flags
Content-Type: application/json

{
    "enable_detect": true,
    "enable_refine": false,
    "enable_summary": true
}
```

## 功能说明

### 敏感性检测 (detect)
- **作用**: 分析用户输入的敏感性
- **影响**: 禁用后返回默认值"低敏感"和"检测功能已禁用"
- **性能影响**: 中等，需要调用AI模型

### 消息优化 (refine)  
- **作用**: 对用户输入进行AI优化，使其更清晰、简洁、有同理心
- **影响**: 禁用后直接返回原始用户输入
- **性能影响**: 高，需要额外的AI调用

### 对话总结 (summary)
- **作用**: 自动生成对话总结
- **影响**: 禁用后返回"总结功能已禁用"
- **性能影响**: 高，需要处理整个对话历史

## 性能优化建议

1. **只启用必需功能**: 根据实际需求选择性启用功能
2. **监控响应时间**: 启用功能后监控API响应时间变化
3. **渐进式启用**: 先启用对性能影响较小的功能，再考虑其他功能

## 注意事项

- 修改 `src/config.py` 需要重启服务才能生效
- 通过API修改的配置在服务重启后会重置为配置文件中的值
- 核心的chat功能始终保持启用状态 