# 时间管理系统 (Time Management System)

## 🎯 解决的问题

这个时间管理系统解决了AI聊天系统中的关键时间问题：

1. **静态时间戳问题**：服务器启动时设置的时间一直不变
2. **时区不一致**：Docker容器和宿主机时区可能不同
3. **历史记忆混淆**：AI无法区分当前时间和历史记忆中的时间
4. **跨日期问题**：明天重启服务器仍然显示昨天的日期

## 🏗️ 系统架构

### 核心组件

1. **TimeManager类** (`src/time_utils.py`)
   - 自动时区检测
   - NTP时间同步验证
   - 统一的时间格式化
   - 时间差计算

2. **动态系统提示词** (`src/chat.py`)
   - 每次对话都获取最新时间
   - 包含详细的时区信息
   - 明确区分当前时间和历史记忆

3. **环境变量配置** (`docker-compose.yml`)
   - 时区设置
   - 时间同步配置

## 🔧 配置方法

### 1. 时区配置

在 `docker-compose.yml` 中设置时区：

```yaml
environment:
  - TZ=Asia/Shanghai          # 系统时区
  - APP_TIMEZONE=Asia/Shanghai # 应用时区
```

支持的时区格式：
- `Asia/Shanghai` (中国标准时间)
- `America/New_York` (美国东部时间)
- `Europe/London` (英国时间)
- `UTC` (协调世界时)

### 2. 时间同步配置

```yaml
environment:
  - TIME_SYNC_ENABLED=true    # 启用时间同步检查
  - NTP_SERVER=pool.ntp.org   # NTP服务器
```

### 3. 环境变量优先级

1. `APP_TIMEZONE` - 应用专用时区设置
2. `TZ` - 系统时区设置
3. 自动检测 - 从系统文件或网络API获取
4. 默认UTC - 如果以上都失败

## 🚀 使用方法

### 基础使用

```python
from src.time_utils import get_time_manager, get_current_time_info

# 获取时间管理器
tm = get_time_manager()

# 获取当前时间信息
time_info = get_current_time_info()
print(f"当前时间: {time_info['readable_time']}")
print(f"时区: {time_info['timezone_name']}")
```

### AI提示词集成

```python
from src.chat import get_system1

# 获取包含最新时间的系统提示词
prompt = get_system1()
# 提示词会自动包含当前准确时间
```

### 时间差计算

```python
tm = get_time_manager()

# 检查是否是今天
is_today = tm.is_same_day("2025-05-27T12:00:00")

# 获取时间差描述
time_diff = tm.get_time_diff_description("2025-05-26T23:49:57")
# 返回: "yesterday" 或 "2 days ago" 等
```

## 🧪 测试

运行完整测试：

```bash
cd oz-server
python test_time_system.py
```

测试内容：
- 时间管理器初始化
- 时区检测和设置
- 时间同步验证
- 系统提示词生成
- 时间一致性检查
- 时间戳解析

## 📊 功能特性

### 1. 自动时区检测

优先级顺序：
1. 环境变量 (`APP_TIMEZONE`, `TZ`)
2. 系统时区文件 (`/etc/timezone`)
3. 网络API检测 (worldtimeapi.org)
4. 默认UTC

### 2. 时间同步验证

- 与NTP服务器对比时间
- 检测时间偏差
- 在日志中显示同步状态

### 3. 智能时间差计算

- "just now" (刚刚)
- "5 minutes ago" (5分钟前)
- "2 hours ago" (2小时前)
- "yesterday" (昨天)
- "3 days ago" (3天前)
- "2 weeks ago" (2周前)
- "1 month ago" (1个月前)

### 4. 记忆时间分组

- **今天的记忆**: 当前日期的对话
- **历史记忆**: 过去的对话，带时间差标注

## 🔍 故障排除

### 常见问题

1. **时区显示不正确**
   ```bash
   # 检查Docker容器时区
   docker exec -it <container> date
   
   # 检查环境变量
   docker exec -it <container> env | grep TZ
   ```

2. **时间同步失败**
   ```bash
   # 检查网络连接
   docker exec -it <container> ping pool.ntp.org
   
   # 手动测试时间API
   curl http://worldtimeapi.org/api/ip
   ```

3. **时间管理器初始化失败**
   ```python
   # 检查依赖
   import pytz
   import requests
   
   # 手动测试
   from src.time_utils import get_time_manager
   tm = get_time_manager('UTC')  # 强制使用UTC
   ```

### 调试模式

启用详细日志：

```python
import logging
logging.basicConfig(level=logging.DEBUG)

from src.time_utils import get_time_manager
tm = get_time_manager()
```

## 🔄 升级指南

### 从旧系统升级

1. **备份现有记忆文件**
   ```bash
   cp -r sm-docker-local/data/memory sm-docker-local/data/memory_backup
   ```

2. **更新Docker配置**
   - 添加时区环境变量到 `docker-compose.yml`

3. **重启服务**
   ```bash
   docker-compose down
   docker-compose up --build
   ```

4. **验证时间**
   ```bash
   python test_time_system.py
   ```

### 迁移记忆数据

系统会自动升级旧的记忆文件，添加缺失的时间字段：
- `readable_time`: 可读时间格式
- `date`: 日期
- `weekday`: 星期几
- `timezone`: 时区信息

## 📈 性能优化

### 缓存策略

- 时间管理器使用单例模式
- 时区信息在初始化时确定
- NTP同步检查有超时限制

### 网络优化

- NTP检查设置2秒超时
- 网络API检测设置5秒超时
- 失败时自动回退到本地时间

## 🛡️ 安全考虑

1. **网络请求限制**
   - 仅访问可信的时间服务器
   - 设置合理的超时时间
   - 失败时不影响核心功能

2. **时区验证**
   - 验证时区名称有效性
   - 防止恶意时区设置

3. **错误处理**
   - 所有时间操作都有异常处理
   - 失败时回退到安全默认值

## 📝 更新日志

### v1.0.0 (2025-05-27)
- 初始版本发布
- 支持自动时区检测
- 集成NTP时间同步
- 动态系统提示词生成
- 完整的测试套件

## 🤝 贡献指南

1. Fork项目
2. 创建功能分支
3. 添加测试用例
4. 提交Pull Request

## �� 许可证

MIT License 