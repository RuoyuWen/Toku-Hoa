#!/usr/bin/env python3
"""
记忆文档优化脚本
根据新的三层记忆分工标准，重新整理现有的记忆文档
"""

import sys
import os
import json
import glob
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional
from collections import defaultdict, Counter

# 添加src目录到路径
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

def get_memory_root_dir():
    """获取记忆数据根目录"""
    current_dir = os.path.dirname(__file__)
    project_root = os.path.dirname(current_dir)
    return os.path.join(project_root, "sm-docker-local", "data", "memory")

def load_existing_memories(user_id: str = "default_user"):
    """加载现有的记忆文档"""
    user_dir = os.path.join(get_memory_root_dir(), user_id)
    
    memories = {
        "short_term": [],
        "medium_term": [],
        "long_term": [],
        "metadata": None
    }
    
    # 加载用户元数据
    metadata_file = os.path.join(user_dir, "metadata", "user_metadata.json")
    if os.path.exists(metadata_file):
        with open(metadata_file, 'r', encoding='utf-8') as f:
            memories["metadata"] = json.load(f)
    
    # 加载短期记忆（所有会话文件）
    short_term_dir = os.path.join(user_dir, "short_term")
    if os.path.exists(short_term_dir):
        for session_file in glob.glob(os.path.join(short_term_dir, "session_*.json")):
            with open(session_file, 'r', encoding='utf-8') as f:
                session_data = json.load(f)
                memories["short_term"].extend(session_data)
    
    # 加载中期记忆
    medium_file = os.path.join(user_dir, "medium_term", "important_memories.json")
    if os.path.exists(medium_file):
        with open(medium_file, 'r', encoding='utf-8') as f:
            memories["medium_term"] = json.load(f)
    
    # 加载长期记忆
    long_file = os.path.join(user_dir, "long_term", "insights_and_summaries.json")
    if os.path.exists(long_file):
        with open(long_file, 'r', encoding='utf-8') as f:
            memories["long_term"] = json.load(f)
    
    return memories

def extract_user_profile_from_conversation(conversation_data: Dict) -> Optional[Dict]:
    """从对话中提取用户档案信息"""
    metadata = conversation_data.get("metadata", {})
    user_message = metadata.get("user_message", "")
    topics = metadata.get("topics", [])
    emotions = metadata.get("emotions", [])
    user_info = metadata.get("user_info")
    importance = metadata.get("importance", 0.0)
    
    # 构建档案信息
    profile_content = ""
    
    if user_info:
        profile_content += f"个人信息: {user_info}\n"
    
    if topics and topics != ["问候", "general"]:  # 排除通用话题
        profile_content += f"兴趣话题: {', '.join(topics)}\n"
        
    if emotions and emotions != ["友好", "neutral"]:  # 排除通用情绪
        profile_content += f"情感倾向: {', '.join(emotions)}\n"
    
    # 从对话中提取个人特征
    personal_insights = extract_personal_insights_from_text(user_message)
    if personal_insights:
        profile_content += f"个人特征: {personal_insights}\n"
    
    if not profile_content.strip():
        return None
    
    # 生成档案文档
    now = datetime.now()
    original_time = metadata.get("readable_time", now.strftime("%Y-%m-%d %H:%M:%S"))
    
    return {
        "content": f"[用户档案更新 - {original_time}]\n{profile_content.strip()}",
        "metadata": {
            "type": "user_profile_update",
            "timestamp": now.isoformat(),
            "readable_time": now.strftime("%Y-%m-%d %H:%M:%S"),
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M:%S"),
            "weekday": now.strftime("%A"),
            "session_id": metadata.get("session_id", "unknown"),
            "importance": 0.85,
            "user_id": metadata.get("user_id", "default_user"),
            "source_conversation_time": original_time,
            "profile_category": "personal_info" if user_info else "behavioral_pattern"
        }
    }

def extract_personal_insights_from_text(text: str) -> str:
    """从文本中提取个人洞察"""
    insights = []
    text_lower = text.lower()
    
    if any(keyword in text_lower for keyword in ["my name", "i'm", "我叫", "我是"]):
        insights.append("提及个人身份信息")
        
    if any(keyword in text_lower for keyword in ["work", "job", "office", "工作", "上班"]):
        insights.append("讨论工作相关话题")
        
    if any(keyword in text_lower for keyword in ["feel", "feeling", "happy", "sad", "感觉", "心情"]):
        insights.append("分享情感状态")
        
    if any(keyword in text_lower for keyword in ["like", "love", "enjoy", "喜欢", "爱好"]):
        insights.append("表达个人偏好")
        
    if any(keyword in text_lower for keyword in ["birthday", "age", "born", "生日", "年龄"]):
        insights.append("涉及个人基本信息")
    
    return "; ".join(insights) if insights else ""

def analyze_conversation_patterns(conversations: List[Dict]) -> Dict:
    """分析对话模式"""
    all_topics = []
    all_emotions = []
    personal_info_count = 0
    total_importance = 0
    
    for conv in conversations:
        metadata = conv.get("metadata", {})
        all_topics.extend(metadata.get("topics", []))
        all_emotions.extend(metadata.get("emotions", []))
        if metadata.get("user_info"):
            personal_info_count += 1
        total_importance += metadata.get("importance", 0.0)
    
    topic_counter = Counter(all_topics)
    emotion_counter = Counter(all_emotions)
    
    return {
        "top_topics": topic_counter.most_common(5),
        "top_emotions": emotion_counter.most_common(3),
        "personal_info_sharing_rate": personal_info_count / len(conversations) if conversations else 0,
        "average_importance": total_importance / len(conversations) if conversations else 0,
        "total_conversations": len(conversations)
    }

def create_behavioral_insight(conversations: List[Dict], analysis: Dict) -> Dict:
    """创建行为洞察文档"""
    now = datetime.now()
    
    # 分析用户行为模式
    behavior_patterns = []
    
    if analysis["top_topics"]:
        top_topics_str = ", ".join([f"{topic}" for topic, count in analysis["top_topics"]])
        behavior_patterns.append(f"偏好话题: {top_topics_str}")
    
    if analysis["top_emotions"]:
        top_emotions_str = ", ".join([f"{emotion}" for emotion, count in analysis["top_emotions"]])
        behavior_patterns.append(f"情感特征: {top_emotions_str}")
    
    if analysis["personal_info_sharing_rate"] > 0.3:
        behavior_patterns.append("主动分享型用户")
    elif analysis["personal_info_sharing_rate"] > 0:
        behavior_patterns.append("谨慎分享型用户")
    else:
        behavior_patterns.append("保守交流型用户")
    
    # 判断关系发展阶段
    total_conversations = analysis["total_conversations"]
    if total_conversations <= 3:
        relationship_stage = "初次接触阶段"
    elif total_conversations <= 10:
        relationship_stage = "建立信任阶段"
    elif total_conversations <= 25:
        relationship_stage = "深度交流阶段"
    else:
        relationship_stage = "长期陪伴关系"
    
    # 构建洞察内容
    insight_content = f"""[综合用户行为分析 - {now.strftime("%Y-%m-%d %H:%M:%S")}]
基于 {total_conversations} 次交互的分析:

行为模式: {'; '.join(behavior_patterns)}
关系发展: {relationship_stage}
平均重要性: {analysis['average_importance']:.3f}
信息分享倾向: {analysis['personal_info_sharing_rate']:.1%}
活跃程度: {'高度活跃' if total_conversations > 10 else '正常互动'}"""
    
    return {
        "content": insight_content,
        "metadata": {
            "type": "behavioral_insight",
            "timestamp": now.isoformat(),
            "readable_time": now.strftime("%Y-%m-%d %H:%M:%S"),
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M:%S"),
            "weekday": now.strftime("%A"),
            "session_id": "optimization_analysis",
            "importance": 0.9,
            "user_id": "default_user",
            "analysis_type": "comprehensive_behavior",
            "conversation_count": total_conversations
        }
    }

def create_comprehensive_user_profile(profile_updates: List[Dict], behavioral_insights: List[Dict]) -> Dict:
    """创建综合用户档案"""
    now = datetime.now()
    
    # 合并档案信息
    profile_info_list = []
    for update in profile_updates[-5:]:  # 最近5条更新
        content = update.get("content", "")
        if content:
            profile_info_list.append(content)
    
    # 合并行为洞察
    behavior_info_list = []
    for insight in behavioral_insights[-3:]:  # 最近3条洞察
        content = insight.get("content", "")
        if content:
            behavior_info_list.append(content)
    
    comprehensive_content = f"""[综合用户档案 - {now.strftime("%Y-%m-%d %H:%M:%S")}]
基于历史交互的综合分析

用户档案信息:
{chr(10).join(profile_info_list) if profile_info_list else "档案信息收集中..."}

行为模式分析:
{chr(10).join(behavior_info_list) if behavior_info_list else "行为分析中..."}

档案生成时间: {now.strftime("%Y-%m-%d %H:%M:%S")}
数据来源: {len(profile_updates)} 条档案更新 + {len(behavioral_insights)} 条行为分析"""
    
    return {
        "content": comprehensive_content,
        "metadata": {
            "type": "comprehensive_user_profile",
            "timestamp": now.isoformat(),
            "readable_time": now.strftime("%Y-%m-%d %H:%M:%S"),
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M:%S"),
            "weekday": now.strftime("%A"),
            "session_id": "optimization_summary",
            "importance": 0.98,
            "user_id": "default_user",
            "profile_sources": len(profile_updates),
            "behavioral_sources": len(behavioral_insights)
        }
    }

def reorganize_memories(memories: Dict) -> Dict:
    """重新组织记忆结构"""
    
    print("🔄 开始重新组织记忆结构...")
    
    optimized_memories = {
        "short_term": [],      # 最近的对话
        "medium_term": [],     # 重要的完整对话
        "long_term": [],       # 用户档案和分析
        "metadata": memories.get("metadata", {})
    }
    
    # 1. 处理所有对话记录
    all_conversations = memories["short_term"] + memories["medium_term"]
    
    print(f"📊 找到 {len(all_conversations)} 条历史对话")
    
    # 2. 按重要性和时间分类
    important_conversations = []  # 中期记忆候选
    profile_updates = []          # 长期记忆候选
    recent_conversations = []     # 短期记忆候选
    
    for conv in all_conversations:
        metadata = conv.get("metadata", {})
        importance = metadata.get("importance", 0.0)
        user_message = metadata.get("user_message", "")
        
        # 短期记忆：最近的对话（保留最新的5条）
        recent_conversations.append(conv)
        
        # 中期记忆：重要对话（重要性>0.5或包含个人信息）
        if importance > 0.5 or contains_personal_info(user_message):
            important_conversations.append(conv)
        
        # 长期记忆：提取用户档案信息
        profile_info = extract_user_profile_from_conversation(conv)
        if profile_info:
            profile_updates.append(profile_info)
    
    # 3. 整理短期记忆：只保留最近的几条
    optimized_memories["short_term"] = recent_conversations[-5:] if recent_conversations else []
    
    # 4. 整理中期记忆：保存重要的完整对话
    optimized_memories["medium_term"] = important_conversations
    
    # 5. 整理长期记忆：用户档案 + 行为分析 + 现有洞察
    long_term_docs = []
    
    # 添加现有的长期记忆（如first_impression等）
    existing_long_term = memories.get("long_term", [])
    for doc in existing_long_term:
        if doc.get("metadata", {}).get("type") in ["first_impression", "user_profile", "deep_insight"]:
            long_term_docs.append(doc)
    
    # 添加提取的用户档案更新
    long_term_docs.extend(profile_updates)
    
    # 创建综合行为分析
    if all_conversations:
        analysis = analyze_conversation_patterns(all_conversations)
        behavioral_insight = create_behavioral_insight(all_conversations, analysis)
        long_term_docs.append(behavioral_insight)
    
    # 创建综合用户档案
    if profile_updates:
        comprehensive_profile = create_comprehensive_user_profile(profile_updates, [behavioral_insight] if 'behavioral_insight' in locals() else [])
        long_term_docs.append(comprehensive_profile)
    
    optimized_memories["long_term"] = long_term_docs
    
    return optimized_memories

def contains_personal_info(text: str) -> bool:
    """检查文本是否包含个人信息"""
    personal_keywords = [
        "name", "age", "work", "job", "feel", "love", "like", "hate", 
        "family", "friend", "hobby", "live", "study", "school",
        "birthday", "birth", "born", "celebrate", "party",
        "名字", "年龄", "工作", "感觉", "喜欢", "讨厌", "家庭", "朋友",
        "生日", "出生", "庆祝", "派对", "我叫", "我是"
    ]
    text_lower = text.lower()
    return any(keyword in text_lower for keyword in personal_keywords)

def save_optimized_memories(optimized_memories: Dict, user_id: str = "default_user"):
    """保存优化后的记忆文档"""
    
    print("💾 开始保存优化后的记忆文档...")
    
    user_dir = os.path.join(get_memory_root_dir(), user_id)
    
    # 创建备份目录
    backup_dir = os.path.join(user_dir, f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    os.makedirs(backup_dir, exist_ok=True)
    
    # 备份现有文件
    for subdir in ["short_term", "medium_term", "long_term", "metadata"]:
        src_dir = os.path.join(user_dir, subdir)
        if os.path.exists(src_dir):
            dst_dir = os.path.join(backup_dir, subdir)
            os.makedirs(dst_dir, exist_ok=True)
            for file in glob.glob(os.path.join(src_dir, "*")):
                if os.path.isfile(file):
                    import shutil
                    shutil.copy2(file, dst_dir)
    
    print(f"📦 已创建备份: {backup_dir}")
    
    # 保存优化后的中期记忆
    if optimized_memories["medium_term"]:
        medium_file = os.path.join(user_dir, "medium_term", "important_memories.json")
        with open(medium_file, 'w', encoding='utf-8') as f:
            json.dump(optimized_memories["medium_term"], f, ensure_ascii=False, indent=2)
        print(f"📦 保存中期记忆: {len(optimized_memories['medium_term'])} 条")
    
    # 保存优化后的长期记忆
    if optimized_memories["long_term"]:
        long_file = os.path.join(user_dir, "long_term", "insights_and_summaries.json")
        with open(long_file, 'w', encoding='utf-8') as f:
            json.dump(optimized_memories["long_term"], f, ensure_ascii=False, indent=2)
        print(f"💡 保存长期记忆: {len(optimized_memories['long_term'])} 条")
    
    # 保存最新的短期记忆
    if optimized_memories["short_term"]:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        short_file = os.path.join(user_dir, "short_term", f"session_optimized_{timestamp}.json")
        with open(short_file, 'w', encoding='utf-8') as f:
            json.dump(optimized_memories["short_term"], f, ensure_ascii=False, indent=2)
        print(f"📝 保存短期记忆: {len(optimized_memories['short_term'])} 条")
    
    # 更新元数据
    if optimized_memories["metadata"]:
        metadata = optimized_memories["metadata"].copy()
        metadata["last_optimization"] = datetime.now().isoformat()
        metadata["optimization_version"] = "three_tier_v1.0"
        
        metadata_file = os.path.join(user_dir, "metadata", "user_metadata.json")
        with open(metadata_file, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
        print(f"📊 更新元数据")

def print_optimization_summary(original_memories: Dict, optimized_memories: Dict):
    """打印优化总结"""
    
    print("\n" + "="*60)
    print("📊 记忆优化总结报告")
    print("="*60)
    
    # 原始状态
    orig_short = len(original_memories.get("short_term", []))
    orig_medium = len(original_memories.get("medium_term", []))
    orig_long = len(original_memories.get("long_term", []))
    
    # 优化后状态
    opt_short = len(optimized_memories.get("short_term", []))
    opt_medium = len(optimized_memories.get("medium_term", []))
    opt_long = len(optimized_memories.get("long_term", []))
    
    print(f"短期记忆: {orig_short} → {opt_short} 条")
    print(f"中期记忆: {orig_medium} → {opt_medium} 条")
    print(f"长期记忆: {orig_long} → {opt_long} 条")
    
    print("\n📋 优化详情:")
    print("✅ 短期记忆：保留最近的重要对话")
    print("✅ 中期记忆：整理重要的完整对话记录")
    print("✅ 长期记忆：提取用户档案信息和行为分析")
    print("✅ 创建了综合用户档案和行为洞察")
    print("✅ 备份了原始记忆文档")
    
    # 分析长期记忆类型分布
    long_term_types = {}
    for doc in optimized_memories.get("long_term", []):
        doc_type = doc.get("metadata", {}).get("type", "unknown")
        long_term_types[doc_type] = long_term_types.get(doc_type, 0) + 1
    
    if long_term_types:
        print("\n📈 长期记忆类型分布:")
        for doc_type, count in long_term_types.items():
            print(f"  - {doc_type}: {count} 条")
    
    print("\n✅ 记忆优化完成！")

def main():
    """主函数"""
    
    print("🚀 开始记忆文档优化...")
    print("根据新的三层记忆分工标准重新整理现有记忆")
    
    # 1. 加载现有记忆
    print("\n📚 加载现有记忆文档...")
    original_memories = load_existing_memories()
    
    # 2. 重新组织记忆
    print("\n🔄 重新组织记忆结构...")
    optimized_memories = reorganize_memories(original_memories)
    
    # 3. 保存优化后的记忆
    print("\n💾 保存优化后的记忆...")
    save_optimized_memories(optimized_memories)
    
    # 4. 打印总结
    print_optimization_summary(original_memories, optimized_memories)
    
    print(f"\n🎉 记忆优化完成！备份已保存，新的记忆结构已生效。")

if __name__ == "__main__":
    main() 