# SMOz - Advanced AI Assistant with Memory System

SMOz is a sophisticated AI assistant platform built with Langchain, featuring advanced memory management, multi-user support, and real-time conversation capabilities.

## 🚀 Features

- **Advanced Memory System**: Long-term, medium-term, and short-term memory management
- **Multi-User Support**: Isolated user sessions and personalized experiences
- **Real-time Chat**: Web-based chat interface with streaming responses
- **Avatar Integration**: Visual avatar system with emotion recognition
- **Docker Support**: Containerized deployment for easy setup
- **Time Management**: Intelligent time parsing and scheduling
- **Memory Optimization**: Efficient memory storage and retrieval

## 📁 Project Structure

```
SMOz - Langchain/
├── oz-server/           # Main AI server with memory system
├── sm-avatar-web/       # React-based avatar web interface
├── sm-orchestration/    # Orchestration service
├── sm-token-server/     # Token management service
├── sm-docker-local/     # Local Docker setup
└── docker-compose.yml   # Main Docker composition
```

## 🛠️ Quick Start

### Prerequisites
- Docker and Docker Compose
- Python 3.8+
- Node.js 16+

### Local Development
1. Clone the repository
2. Navigate to the project directory
3. Run `docker-compose up` to start all services
4. Access the web interface at `http://localhost:3000`

## 🔧 Configuration

The system uses environment variables for configuration. See individual service directories for specific setup instructions.

## 📚 Documentation

- [Memory System Design](SMOz记忆系统设计说明.txt)
- [Multi-User Implementation](oz-server/MULTIUSER_IMPLEMENTATION.md)
- [Memory Optimization](oz-server/README_MEMORY_OPTIMIZATION.md)

## 🤝 Contributing

This project is part of the AI of Oz initiative. For contributions, please follow the established coding standards and testing procedures.

## 📄 License

This project is proprietary software developed for AI of Oz. 