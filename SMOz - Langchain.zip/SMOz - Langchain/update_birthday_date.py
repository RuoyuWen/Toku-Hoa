#!/usr/bin/env python3
"""
更新用户生日信息脚本
将相对时间描述"昨天"转换为具体日期
"""

import json
import os
from datetime import datetime, timedelta
from pathlib import Path

def update_birthday_to_absolute_date():
    """更新生日信息为绝对日期"""
    
    # 定位用户档案文件
    user_profile_path = Path("sm-docker-local/data/memory/default_user/long_term/user_profile.json")
    
    if not user_profile_path.exists():
        print(f"❌ 用户档案文件不存在: {user_profile_path}")
        return
    
    # 读取现有数据
    with open(user_profile_path, 'r', encoding='utf-8') as f:
        user_profile = json.load(f)
    
    print("📖 当前用户档案：")
    personal_details = user_profile.get("personal_details", {})
    print(f"  姓名: {personal_details.get('name', 'Unknown')}")
    print(f"  生日: {personal_details.get('birthday', 'Unknown')}")
    
    # 检查是否需要更新生日
    current_birthday = personal_details.get("birthday", "")
    if current_birthday in ["昨天", "yesterday"]:
        # 计算昨天的日期
        yesterday = datetime.now() - timedelta(days=1)
        new_birthday = yesterday.strftime("%Y-%m-%d")
        
        # 更新生日信息
        user_profile["personal_details"]["birthday"] = new_birthday
        
        # 创建备份
        backup_path = user_profile_path.with_suffix('.backup.json')
        with open(backup_path, 'w', encoding='utf-8') as f:
            json.dump(user_profile, f, ensure_ascii=False, indent=2)
        print(f"📦 已创建备份: {backup_path}")
        
        # 保存更新后的数据
        with open(user_profile_path, 'w', encoding='utf-8') as f:
            json.dump(user_profile, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 生日已更新: '{current_birthday}' -> '{new_birthday}'")
        print(f"📅 具体日期: {yesterday.strftime('%Y年%m月%d日 %A')}")
        
    else:
        print("ℹ️ 生日信息已经是绝对日期，无需更新")

if __name__ == "__main__":
    print("🔄 开始更新生日信息...")
    update_birthday_to_absolute_date()
    print("✅ 更新完成！") 