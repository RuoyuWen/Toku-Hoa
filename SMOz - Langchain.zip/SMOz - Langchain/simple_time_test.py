#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.join('oz-server', 'src'))

from memory_system_v2 import SMOzMemorySystem

def main():
    print("🧠 简化记忆系统时间处理测试")
    
    # 创建记忆系统
    memory = SMOzMemorySystem(user_id='time_test_user_simple')
    
    # 测试时间相关对话
    test_cases = [
        ('My birthday is tomorrow', 'Happy early birthday!'),
        ('I have a meeting next Friday', 'I will remember that.'),
        ('Let me schedule lunch for 明天', 'Sounds great!'),
    ]
    
    for user_msg, ai_msg in test_cases:
        print(f"💬 用户: {user_msg}")
        memory.add_conversation(user_msg, ai_msg)
    
    # 检查结果
    profile = memory.get_user_profile()
    print('\n📊 结果:')
    print('个人信息:', profile.get('personal_details', {}))
    
    temporal_info = profile.get('temporal_information', {})
    if temporal_info:
        print('时间信息结构:', list(temporal_info.keys()))
        upcoming = temporal_info.get('upcoming_events', [])
        if upcoming:
            print('即将到来的事件:')
            for event in upcoming:
                print(f"  - {event['type']}: {event['parsed_date']}")
    
    # 保存
    memory.save_all_memories()
    print('\n✅ 测试完成')

if __name__ == "__main__":
    main() 